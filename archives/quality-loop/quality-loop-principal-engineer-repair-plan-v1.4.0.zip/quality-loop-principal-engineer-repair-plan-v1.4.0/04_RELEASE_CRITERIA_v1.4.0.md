# Release Criteria v1.4.0

## QA-IND-001

- [ ] Owner rework + unresolved High → submit-plan
- [ ] returned handoffでsubmit-plan成功
- [ ] review-planへ進む
- [ ] Low/non-plan-required rework → submit-response
- [ ] deadlockなし

## QA-IND-002

- [ ] partial verificationでopen Findingが残ればOwnerへ進まない
- [ ] pending High → submit-plan
- [ ] pending Low/simple Medium → submit-response
- [ ] all material resolvedのみOwner adjudication

## QA-IND-003

- [ ] FUNCTIONAL_SPEC verification routing一致
- [ ] FUNCTIONAL_SPEC Owner rework routing一致

## Regression

- [ ] 109 baseline tests維持
- [ ] new targeted tests green
- [ ] compileall success
- [ ] examples/schema green
- [ ] Role Firewall green
- [ ] atomic write green
- [ ] idempotency green
- [ ] Final Risk coverage green

## Efficiency

- [ ] Human gate追加なし
- [ ] Human identifier手入力追加なし
- [ ] Skill Context増加なし
- [ ] 第3 Skillなし
- [ ] 新stateなし

## FIX

すべて満たしたら:
- v1.x architectureをFIX候補とする
- 実運用へ移行
- speculative improvementを停止
