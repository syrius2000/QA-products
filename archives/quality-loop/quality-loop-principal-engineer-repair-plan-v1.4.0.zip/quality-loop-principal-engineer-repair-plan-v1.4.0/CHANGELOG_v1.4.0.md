# Repair Plan Changelog v1.4.0

## Basis

Independent blind-first QA of:
- `quality-loop/`
- implementation plan 014
- implementation plan 015

## Confirmed baseline

The intended Plan-015 verification rework routing was confirmed.

Additional independent testing found:

### QA-IND-001 High
Owner rework-requested path has the same class of Plan-required deadlock.

### QA-IND-002 Medium
Partial verification can prematurely route the case to Owner.

### QA-IND-003 Medium
FUNCTIONAL_SPEC state machine is stale.

## v1.4.0 Goal

Repair only these defects.

No architectural expansion.
