# Implementer Handoff Prompt v1.4.0

```text
あなたはQuality Loopの実装担当Principal-level Engineerです。

独立QAでCONFIRMEDされた以下3 Findingだけを最小差分で修復してください。

QA-IND-001 High:
Owner rework-requested後、plan-required Findingがsubmit-responseへ送られ、
plan-approval-required / state-transition-not-allowedでdeadlockする。

QA-IND-002 Medium:
verify()が今回のverification payloadだけでall_resolvedを判定するため、
別のmaterial FindingがopenでもOwner adjudicationへ進む。

QA-IND-003 Medium:
FUNCTIONAL_SPECのstate machineが実装済みPlan rerouteと一致していない。

必須設計:
- verify後はcanonical QA Case全体のmaterial unresolved Findingで判定
- unresolved + pending Plan-required → implementer-plan / submit-plan
- unresolved + no pending Plan-required → implementer-action / submit-response
- all material resolved → owner-adjudication
- cycle limit/early risk → reviewer-final-assessment
- Owner reworkも同じpending Plan-required routingを使う

新しいstate/Role/Skill/QMS phaseを追加しないでください。
Human操作を増やさないでください。
Skill本文を長くしないでください。

最初に:
01_BASELINE_AND_CRITICAL_FIXES_v1.4.0.md
02_TARGET_OPERATING_MODEL_v1.4.0.md
03_IMPLEMENTATION_INSTRUCTIONS_v1.4.0.md
05_TODO_v1.4.0.md
06_ACCEPTANCE_TEST_PLAN_v1.4.0.md
を読んでください。

05_TODOを進捗正本として更新してください。

修正後は:
- baseline 109 tests
- targeted regression tests
- compileall
- examples/schema
- Plan Gate
- Final Risk coverage
- Role Firewall
- atomic write
- idempotency
を独立実行し、結果を記録してください。
```
