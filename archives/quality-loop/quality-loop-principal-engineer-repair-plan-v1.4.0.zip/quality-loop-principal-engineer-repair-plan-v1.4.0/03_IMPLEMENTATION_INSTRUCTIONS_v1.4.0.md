# Implementation Instructions v1.4.0

## 原則

最小diffを優先する。

主対象:

```text
quality_loop/engine.py
FUNCTIONAL_SPEC.md
tests/
```

必要ならhelper/modelへ小変更は許可。

Skill本文は原則変更しない。

---

# Phase 1 — 共通routing helperを設計

## Goal

Verification後とOwner rework後で、
同じpending Plan-required判定を使う。

### 推奨helper案

```python
def _pending_required_plan_finding_ids(case: dict) -> set[str]:
    return (
        _required_plan_finding_ids(case)
        - _approved_plan_finding_ids(case)
    )
```

必要なら:

```python
def _route_unresolved_to_implementer(case):
    pending = ...
    if pending:
        return implementer-plan / submit-plan
    return implementer-action / submit-response
```

既存コード構造に合う名前でよい。

---

# Phase 2 — verify()を案件全体判定へ修正

現在のpayload-localな`all_resolved`を削除/置換。

### 順序

1. Verificationをcanonical Findingへ反映
2. new Findingsを追加
3. updated caseを基準にmaterial unresolved算出
4. cycle/early-risk判定
5. routing

### Routing order

Pseudo:

```python
material_unresolved = self._material_unresolved_finding_ids(updated)
all_resolved = not material_unresolved

if not all_resolved and (cycle_count >= cycle_limit or early_risk):
    route final risk
elif all_resolved:
    route owner
else:
    route implementer according to pending plan-required
```

### 注意

early riskのCritical guardは維持。

---

# Phase 3 — adjudicate(rework-requested) routing修正

現行:

```python
rework-requested
→ implementer-action / submit-response
```

を置換。

Pseudo:

```python
if decision == "rework-requested":
    pending = pending_required_plan_finding_ids(updated)

    if pending:
        route implementer-plan / submit-plan
    else:
        route implementer-action / submit-response
```

### Handoff

`open_items`にはcanonical unresolved Findingを使う。

Plan routingの場合expected outputは:

```text
Response Plan
```

Response routingの場合:

```text
Finding別回答
変更Evidence
```

---

# Phase 4 — FUNCTIONAL_SPEC同期

State machineを実装と同じに更新。

必須:

### reviewer-verification

```text
-> implementer-plan
   [Unresolved Plan-required / cycle < limit]
-> implementer-action
   [Unresolved non-Plan-required / cycle < limit]
-> reviewer-final-assessment
   [Cycle limit / early risk]
-> owner-adjudication
   [All material resolved]
```

### owner-adjudication

```text
-> implementer-plan
   [rework-requested + pending Plan-required]
-> implementer-action
   [rework-requested + no pending Plan-required]
```

---

# Phase 5 — Targeted tests

既存109 testsを壊さず、最低以下を追加。

1. `test_owner_rework_high_routes_to_submit_plan`
2. `test_owner_rework_handoff_allows_next_submit_plan`
3. `test_owner_rework_low_routes_to_submit_response`
4. `test_partial_verification_does_not_route_owner`
5. `test_partial_verification_high_pending_routes_plan`
6. `test_partial_verification_low_pending_routes_response`
7. `test_new_high_on_verify_still_routes_plan`（既存なら再利用）
8. `test_all_material_resolved_routes_owner`

---

# Phase 6 — Regression

必須再確認:

- Plan Gate
- plan status `not-started`
- Final Risk coverage
- Role Firewall
- Evidence boundary
- atomic write
- idempotency
- stale revision/handoff
- adaptive Medium
- finding withdrawal
- early Final Risk
- Owner final decision
- examples/schema
- compileall

---

# Phase 7 — Optional stale Template cleanup

実施する場合のみ:

1. reference search
2. README/Skill/test非参照確認
3. obsolete template削除
4. test

今回のCore repairを遅らせるなら実施しない。
