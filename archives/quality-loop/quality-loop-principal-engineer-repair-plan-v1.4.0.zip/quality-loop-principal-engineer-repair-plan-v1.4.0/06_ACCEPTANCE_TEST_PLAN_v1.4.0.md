# Acceptance Test Plan v1.4.0

## A. Owner Rework + High

### A-01

Flow:

```text
review High
submit-plan
review-plan accepted
submit-response
verify not-remediated
assess-risk
owner rework-requested
```

Expect:

```text
next_role   = implementer
next_action = submit-plan
state       = implementer-plan
```

---

### A-02

Use the exact returned handoff/revision.

Call `submit-plan`.

Expect:

```text
accepted
next_role   = reviewer
next_action = review-plan
```

No `state-transition-not-allowed`.

---

### A-03 Owner Rework + Low

Residual Low/non-plan-required.

Expect:

```text
submit-response
```

Do not add unnecessary Plan Gate.

---

## B. Partial Verification

### B-01 Two Low

F1 and F2 open.

Verify F1 as remediated only.

Expect:
- F2 remains open
- not Owner
- implementer-action / submit-response

---

### B-02 High pending

F1 remediated.
F2 High unresolved.

Expect:
- implementer-plan / submit-plan

---

### B-03 All resolved

All material Finding resolved.

Expect:
- owner-adjudication

---

## C. New High During Verification

Add new High Finding during verification.

Expect:
- implementer-plan
- no direct submit-response

This is a mandatory regression.

---

## D. Existing Core Contracts

Must remain green:

- High Plan Gate
- `implementation_status=not-started`
- Final Risk full coverage
- severity/status consistency
- Role Firewall
- Evidence outside-case rejection
- unauthorized change rejection
- atomic write rollback
- duplicate operation idempotency
- stale revision
- stale handoff
- Early Final Risk rationale
- finding withdrawal
- adaptive Medium

---

## E. Full Build

Run independently:

```bash
python3 -B -m pytest -q
python3 -m compileall -q quality_loop
```

Run official Draft 2020-12 Schema validation if available.

Expected:
- all tests pass
- examples pass schema
- no packaging artifacts

---

## F. Human Efficiency

Acceptance failure if this repair causes:
- Human to choose Plan vs Response manually
- new approval step
- new Skill
- extra case/revision/Finding ID input
- longer default Skill prompt

The Core must make routing deterministic.
