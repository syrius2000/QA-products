# Target Operating Model v1.4.0

## 1. State machineの目標

Architectureを増やさず、routingを一貫させる。

---

## 2. Reviewer Verification後

```text
verify
  ↓
canonical Finding statuses update
  ↓
material unresolved setを案件全体で再計算
  ↓
┌──────────────────────────────────────────┐
│ all material findings resolved           │
└──────────────────────────────────────────┘
  ↓
Owner adjudication

┌──────────────────────────────────────────┐
│ unresolved + cycle cap / early risk       │
└──────────────────────────────────────────┘
  ↓
Final Risk Assessment

┌──────────────────────────────────────────┐
│ unresolved + pending Plan-required        │
└──────────────────────────────────────────┘
  ↓
implementer-plan / submit-plan

┌──────────────────────────────────────────┐
│ unresolved + no pending Plan-required     │
└──────────────────────────────────────────┘
  ↓
implementer-action / submit-response
```

---

## 3. Owner rework後

`rework-requested` は「必ずsubmit-response」ではない。

Ownerは品質上:

> 追加改善が必要

と判断しただけであり、
次の技術的actionはFinding状態からCoreが決定する。

```text
Owner rework
  ↓
material unresolved
  ↓
pending Plan-required?
  ├─ Yes → submit-plan
  └─ No  → submit-response
```

Humanに選ばせない。

---

## 4. Plan approvalの意味

重要Findingが`not-remediated`になった後は、
既存policyに従い必要なPlan Gateを再評価する。

今回、新しいPlan validity modelを発明しない。

現行の:

- required plan finding IDs
- approved plan finding IDs
- Finding status

を利用する。

必要ならhelperの責務だけ整理する。

---

## 5. all_resolvedの意味

禁止:

```text
all_resolved = 今回提出されたverificationが全部resolved
```

正しい意味:

```text
all_resolved = canonical QA Caseにmaterial unresolved Findingが0
```

これはOwner介在を最小化するためにも重要。

---

## 6. Quality priority

Routingの優先順位:

1. canonical Finding状態
2. cycle limit / early risk
3. Plan Gate requirement
4. direct response
5. Human Owner

Human Ownerは**決定が必要な時だけ**呼ぶ。

---

## 7. No new complexity

今回の修復後も:

- 2 Skillsのまま
- 既存state namesのまま
- Existing Handoff contractのまま
- Existing Final Risk contractのまま

とする。

---

## 8. Documentation contract

`FUNCTIONAL_SPEC.md` は将来のAI-1/AI-2が読む契約。

したがってコードと同じroutingを記述する。

> Spec driftは将来のregression sourceである。

---

## 9. Human UX

修復後もユーザー操作は変えない。

```text
quality-review で再点検して
quality-response でhandoffを確認して対応して
quality-review で再点検して
```

内部でPlanが必要ならSkill/Coreが判断する。

---

## 10. FIX後

この3 Finding解消後はarchitecture reviewを停止し、
実運用dogfoodへ移る。

次の改善は実案件で反復して発生した摩擦だけを根拠とする。
