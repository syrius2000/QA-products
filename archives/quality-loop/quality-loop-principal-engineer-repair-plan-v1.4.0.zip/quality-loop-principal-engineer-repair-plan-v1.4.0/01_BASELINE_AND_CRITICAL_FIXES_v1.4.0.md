# Baseline & Critical Fixes v1.4.0

# QA-IND-001 — Owner reworkでplan-required Findingがdeadlock

**Severity:** High  
**Category:** state-transition / Plan Gate / rework deadlock  
**Status:** CONFIRMED

---

## 1. 再現経路

```text
High Finding
→ submit-plan
→ review-plan: accepted
→ submit-response
→ verify: not-remediated
→ Final Risk Assessment
→ Owner adjudicate: rework-requested
```

Owner rework後、現行Coreは:

```text
next_role   = implementer
next_action = submit-response
state       = implementer-action
```

を返す。

しかしHigh Findingは`not-remediated`であり、
現行Plan approval判定上、再度Planが必要となる。

そのため:

```text
submit-response
→ plan-approval-required
```

一方:

```text
submit-plan
→ state-transition-not-allowed
```

となる。

結果:

```text
Core自身がsubmit-responseを要求
↓
submit-responseはCore自身に拒否される
↓
submit-planにも遷移できない
```

完全なdeadlock。

---

## 2. 修正要求

`adjudicate(decision="rework-requested")` 後に、
Verification後と同じ「pending Plan-required判定」を実施する。

概念:

```python
pending_plan_required = (
    required_plan_finding_ids(updated)
    - valid_approved_plan_finding_ids(updated)
)
```

### pendingあり

```text
next_role   = implementer
next_action = submit-plan
state       = implementer-plan
```

### pendingなし

```text
next_role   = implementer
next_action = submit-response
state       = implementer-action
```

---

## 3. 実装方針

### 推奨

同じroutingロジックを複数箇所へコピーしない。

例えばprivate helper:

```python
def _route_implementer_rework(case):
    ...
```

または既存helperの再利用。

### 禁止

- Owner rework専用の新stateを作らない
- Plan Gateを緩めない
- Highだけ特例でPlan承認を流用しない
- Humanに「PlanかResponseか」を選ばせない

---

## 4. Acceptance

以下が成立すること。

```text
Owner rework
+ unresolved High / plan-required
→ implementer-plan / submit-plan
```

そのhandoffで`submit-plan`が成功し:

```text
→ reviewer-plan-review / review-plan
```

へ進む。

---

# QA-IND-002 — partial Verificationが案件全体解決として扱われる

**Severity:** Medium  
**Category:** state-transition / incomplete coverage / Human burden  
**Status:** CONFIRMED

---

## 1. 再現

```text
F1 Low
F2 Low
```

AI-1がF1だけResponse。

AI-2がF1だけ:

```text
remediated
```

とVerify。

F2は:

```text
open
```

のまま。

しかし現行Coreは:

```text
next_role   = owner
next_action = adjudicate
state       = owner-adjudication
```

へ進む。

---

## 2. 根本原因

現行`verify()`の`all_resolved`が、
今回の`verifications` payloadだけを評価している。

概念的に:

```python
all(
    submitted_verification.result in RESOLVED
)
and not new_findings
```

となっている。

これは:

> 今回確認した項目が全部解決したか

であって、

> QA Case全体のmaterial Findingが全部解決したか

ではない。

---

## 3. 修正要求

Verification結果をcanonical Findingへ反映した**後**に、
案件全体のmaterial unresolved Findingを計算する。

既存の:

```python
_material_unresolved_finding_ids(updated)
```

または同等helperを再利用すること。

推奨:

```python
all_resolved = not self._material_unresolved_finding_ids(updated)
```

ただし`improvement-proposal`等の既存除外policyは維持する。

---

## 4. Routing

### material unresolvedなし

```text
owner / adjudicate
```

### material unresolvedあり + cycle limit未到達

さらにPlan-required残件を判定:

```text
pending Plan-required
→ implementer / submit-plan / implementer-plan

それ以外
→ implementer / submit-response / implementer-action
```

### cycle limit/early risk

既存Final Risk routingを維持。

---

## 5. Human負担上の意味

Ownerのacceptedは未解決Finding guardで拒否されるため、
誤受入そのものは防止されている。

しかしOwnerを早すぎる段階で呼ぶため:

```text
AI → Owner → rework → AI
```

という無駄な介在が発生する。

今回の修正はHuman gateを増やすのではなく、
**不要なHuman gateを減らす修正**である。

---

# QA-IND-003 — FUNCTIONAL_SPEC state drift

**Severity:** Medium  
**Category:** spec-drift  
**Status:** CONFLICT

現行specは概ね:

```text
reviewer-verification
  -> implementer-action [Unresolved / cycle < limit]
```

だが実装済みCoreには:

```text
reviewer-verification
  -> implementer-plan
```

が存在する。

---

## 修正要求

最低限:

```text
reviewer-verification
  -> implementer-plan
       [unresolved Plan-required / cycle < limit]
  -> implementer-action
       [unresolved non-Plan-required / cycle < limit]
  -> reviewer-final-assessment
       [cycle limit / early risk]
  -> owner-adjudication
       [all material findings resolved]
```

へ同期する。

Owner adjudication側も:

```text
owner-adjudication
  -> implementer-plan
       [rework-requested + pending Plan-required]
  -> implementer-action
       [rework-requested + no pending Plan-required]
```

を記述する。

---

# Non-blocking cleanup

旧Template群:

```text
templates/create_case.json
templates/review.json
templates/submit_response.json
templates/verify.json
```

等が現行README契約外で、古いQuality Intentを含む可能性がある。

今回は正式FIX blockerではない。

ただし**明らかにunusedなら削除**してよい。

条件:
- 現行README/Skill/testから参照されていないこと
- Runtime Context contaminationを減らすこと
- 新Template追加はしないこと
