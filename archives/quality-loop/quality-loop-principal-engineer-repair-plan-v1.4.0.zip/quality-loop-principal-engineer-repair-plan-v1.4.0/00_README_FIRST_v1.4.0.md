# Quality Loop Principal Engineer Repair Plan v1.4.0

created: 2026-08-31 (JST)  
role: Principal Engineer / Independent QA Reviewer  
target: current `quality-loop/` implementation after Plan 014 / Plan 015  
profile: strict  
purpose: Codexが一度の実装ラウンドで残存Core contract defectを修復するための指示書

---

## 1. 今回の位置づけ

今回の独立QAでは、Plan 014 / 015 が狙った主要修正は確認できた。

### CONFIRMED

- High Finding:
  `review → submit-plan → review-plan → submit-response → verify(not-remediated)`
- cycle limit未到達時:
  `next_role=implementer`
  `next_action=submit-plan`
  `state=implementer-plan`
- そのhandoffから次の`submit-plan`が成功
- Verification時の新High FindingもPlanへ戻る
- Low/simple Mediumのdirect response維持
- Plan Gate
- `implementation_status=not-started`
- Final Risk coverage
- Role Firewall
- Evidence boundary
- atomic write
- idempotency
- 109 tests
- compileall
- examples/schema

ただしblind-first QAで、正式FIXを妨げる残存Findingを3件確認した。

---

## 2. 今回修正するFinding

### QA-IND-001 — High
Owner `rework-requested` 後のHigh/plan-required Findingがdeadlockする。

### QA-IND-002 — Medium
Verificationで一部Findingだけ解消した場合、案件全体にopen Findingが残っていてもOwner adjudicationへ進む。

### QA-IND-003 — Medium
`FUNCTIONAL_SPEC.md` のstate machineが実装済みの `reviewer-verification → implementer-plan` 経路を表していない。

---

## 3. 今回修正しないもの

以下は今回追加・変更しない。

- 第3 Skill
- 新Role
- 新しいQMS phase
- Risk matrix
- Finding scoring
- CAPA
- Human approval point
- Skill本文の長文化
- Quality Intent哲学の再設計
- Plan Gate policyの再設計
- Final Risk modelの再設計

> **今回はarchitecture changeではなく、既存state machine contractの修復である。**

---

## 4. 最重要原則

1. `case.json` canonical stateを維持
2. Role Firewallを弱めない
3. CAS / handoff / revisionを弱めない
4. Plan-required Findingは修正前にPlan承認必須
5. QA自己訂正を維持
6. Human Ownerへの不要なhandoffを減らす
7. 新しい人間操作を追加しない
8. Runtime Contextを増やさない

---

## 5. 推奨読み順

1. `01_BASELINE_AND_CRITICAL_FIXES_v1.4.0.md`
2. `02_TARGET_OPERATING_MODEL_v1.4.0.md`
3. `03_IMPLEMENTATION_INSTRUCTIONS_v1.4.0.md`
4. `05_TODO_v1.4.0.md`
5. `06_ACCEPTANCE_TEST_PLAN_v1.4.0.md`

---

## 6. Done

以下をすべて満たしたら修復完了。

- Owner reworkでHigh Findingがdeadlockしない
- Owner rework時に必要なら`submit-plan`へ戻る
- Verification後、案件全体にmaterial unresolved Findingが残る限りOwnerへ誤送信しない
- `FUNCTIONAL_SPEC.md` とCore routingが一致
- 既存109 tests維持
- 新規targeted regression tests成功
- compileall成功
- examples/schema成功
- Human操作数増加なし
- Skill Context増加なし

> Fix only what independent QA proved defective.
