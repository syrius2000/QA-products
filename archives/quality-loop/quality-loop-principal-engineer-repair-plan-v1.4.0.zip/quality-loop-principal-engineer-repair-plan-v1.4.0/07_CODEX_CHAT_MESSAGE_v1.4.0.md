# Short Chat Message for Codex

以下を `quality-loop-principal-engineer-repair-plan-v1.4.0.zip` と対象リポジトリと一緒にCodexへ渡してください。

---

今回の独立QAで残った3 Findingだけを修復してください。  
新機能やQMS拡張は不要です。

最初に `00_README_FIRST_v1.4.0.md` を読み、特に  
`01_BASELINE_AND_CRITICAL_FIXES_v1.4.0.md`、  
`02_TARGET_OPERATING_MODEL_v1.4.0.md`、  
`05_TODO_v1.4.0.md`  
を実装契約として扱ってください。

最重要は次の3点です。

1. Owner `rework-requested` 後、未解決High/plan-required Findingがあれば `submit-plan / implementer-plan` へ戻す。
2. `verify()` のall-resolved判定を今回のpayloadではなくQA Case全体のmaterial unresolved Findingで行う。
3. `FUNCTIONAL_SPEC.md` のstate machineを実装と一致させる。

Core routingとtargeted regression testsだけを最小差分で修正し、Role Firewall、Plan Gate、Final Risk coverage、Evidence境界、atomic write、idempotencyを弱めないでください。

修正後は109 baseline tests、追加E2E、compileall、examples/schemaを再実行し、`05_TODO_v1.4.0.md` に結果を記録してください。
