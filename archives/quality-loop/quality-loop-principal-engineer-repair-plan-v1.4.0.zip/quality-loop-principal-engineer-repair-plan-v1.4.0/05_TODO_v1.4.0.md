# TODO — Principal Engineer Repair v1.4.0

> Codexはこのファイルを進捗正本として更新すること。

---

# Phase 0 — Baseline

- [ ] current archive / git revision記録
- [ ] full tests実行
- [ ] `109 tests` baseline確認
- [ ] compileall確認
- [ ] examples/schema確認
- [ ] target files hash記録

### Log

```text
Date:
Agent:
Revision:
Tests:
Notes:
```

---

# Phase 1 — Shared Routing Logic

- [ ] required Plan Finding helper確認
- [ ] approved Plan Finding helper確認
- [ ] pending Plan Finding helper作成/整理
- [ ] duplicate routing logicを増やさない
- [ ] unit test helper logic

### Checkpoint

- [ ] unresolved caseからsubmit-plan/submit-responseを決定可能

---

# Phase 2 — verify() 全体解決判定

- [ ] payload-local `all_resolved`を除去
- [ ] canonical updated findingsでmaterial unresolved算出
- [ ] all resolved → owner
- [ ] cycle limit/early risk → final assessment
- [ ] pending Plan-required → submit-plan
- [ ] no pending Plan-required → submit-response
- [ ] new High routing維持
- [ ] Critical early risk guard維持

### Tests

- [ ] F1 resolved / F2 open → Ownerへ行かない
- [ ] F2 High → submit-plan
- [ ] F2 Low → submit-response
- [ ] F1/F2 resolved → Owner

---

# Phase 3 — Owner Rework Routing

- [ ] `rework-requested`無条件submit-responseを削除
- [ ] pending Plan-required判定
- [ ] High residual → submit-plan
- [ ] Low residual → submit-response
- [ ] returned handoff open_items確認
- [ ] submit-planを実行して成功
- [ ] review-planへ進む

### Deadlock reproduction

- [ ] 修正前reproduction testを追加
- [ ] 修正後PASS

---

# Phase 4 — FUNCTIONAL_SPEC

- [ ] reviewer-verification → implementer-plan記載
- [ ] reviewer-verification → implementer-action条件記載
- [ ] all material resolved → owner記載
- [ ] owner rework → implementer-plan条件記載
- [ ] owner rework → implementer-action条件記載
- [ ] stale state description 0

---

# Phase 5 — Regression

- [ ] Plan Gate
- [ ] implementation_status
- [ ] Final Risk coverage
- [ ] Role Firewall
- [ ] Evidence boundary
- [ ] atomic write
- [ ] idempotency
- [ ] CAS/stale handoff
- [ ] adaptive Medium
- [ ] finding withdrawal
- [ ] early Final Risk
- [ ] Owner adjudication
- [ ] schema/examples
- [ ] compileall

---

# Phase 6 — Optional Cleanup

- [ ] old templates reference search
- [ ] unusedなら削除
- [ ] usedなら変更しない
- [ ] cleanupがCore repairを遅らせていない

---

# FINAL CHECKPOINT

- [ ] QA-IND-001 closed
- [ ] QA-IND-002 closed
- [ ] QA-IND-003 closed
- [ ] High deadlock 0
- [ ] premature Owner handoff 0
- [ ] Human負担増加 0
- [ ] Skill Context増加 0
- [ ] new architecture 0
- [ ] formal FIX candidate
