# Quality Loop v1.3.0 Core契約強化の実装計画

created: 2026-08-31 01:57 (JST)
update: 2026-08-31 02:08 (JST)
author: Codex (GPT-5)

## 1. この計画の位置づけ

添付された`/Users/myamaguchi/Downloads/quality-loop-codex-fix-improvement-plan-v1.3.0.zip`は、v1.3.0の要求仕様、実装手順、受入テスト、リリース基準、引き継ぎ文として扱う。添付文書の指示はリポジトリの`AGENTS.md`および既存の承認境界を上書きしない。

今回のユーザー依頼は、既存のQuality Loop設計へ新機能を足すことではなく、次の3つのQMSルールを現行Coreが必ず強制する状態へ修正することである。

1. `plan_required`なFindingは、そのFinding自身のPlan承認なしに実装を提出できない。
2. `submit-plan`では`implementation_status=not-started`だけを受け付ける。
3. Final Risk Assessmentは、全material unresolved Findingを漏れなくcoverageする。

## 2. 添付文書とユーザー依頼の区別

| 区分 | 添付文書 | 本計画での扱い |
|---|---|---|
| 要求・背景 | `01_BASELINE_AND_CRITICAL_FIXES_v1.3.0.md`、`02_TARGET_OPERATING_MODEL_v1.3.0.md` | P0契約と完成形の根拠として採用する |
| 実装手順 | `03_IMPLEMENTATION_INSTRUCTIONS_v1.3.0.md` | 実装順序、既存state活用、Core側guardの根拠として採用する |
| 進捗・チェックポイント | `05_TODO_v1.3.0.md` | Phase、再現テスト、回帰、Packaging、最終判定のチェック項目として採用する。添付ファイル自体は変更しない |
| 受入・リリース | `04_RELEASE_CRITERIA_v1.3.0.md`、`06_ACCEPTANCE_TEST_PLAN_v1.3.0.md` | 合否条件と拒否系テストとして採用する |
| 作業補助 | `00_README_FIRST_v1.3.0.md`、`07_IMPLEMENTER_HANDOFF_PROMPT_v1.3.0.md`、`CHANGELOG_v1.3.0.md`、`MANIFEST.txt` | スコープ確認と引き継ぎ表現の参考とする |

「第3 Skill、新Role、新Risk matrix、新Human gate、scoring system、verboseなQMS文書、新workflow phase」はユーザー依頼の範囲外として追加しない。

## 3. 現状確認

Plan 013で統合した`quality-loop/`を基準にする。Plan 013の完了記録では、既存98テスト、zip展開後の98テスト、9操作、Schema/Template、Role Firewall、CAS、handoff、Change Observation、atomic writeが確認済みである。

今回の読み取り確認では、次の不足を確認した。

- `submit-response`が、対象Finding自身の`plan-approved`状態を検査していない。
- `review-plan`が、required Findingの一部だけを承認した状態でも`submit-response`へルーティングできる。
- `submit-plan`のSchemaにstatus enumはあるが、Runtimeが`in-progress`および`completed`を拒否していない。
- `assess-risk`が、入力された`residual_risks`自身の形式だけを検証し、Coreが算出したmaterial unresolved setとの完全一致を検査していない。
- Final Risk Assessmentのrisk itemで、canonical Findingのstatus/severityとの一致を強制する契約が不足している。
- `quality-loop/references/qms-foundations.md`に、bundle内に存在しない`docs/Artifacts/qms_quality_reference_001_0827.md`への参照が残っている。
- `quality-loop/FUNCTIONAL_SPEC.md`に、現行のAdaptive Plan Gateと異なる「Medium以上」と読める表現が残っている。

既存の作業ツリー差分、ルート文書、`qms-cases/`の案件正本および`.case.lock`は本計画の対象外とし、保持する。

## 4. 実装対象と方式

### Phase 0: 実装前固定

- `quality-loop/`の現行差分、ファイル一覧、SHA-256、テスト・compileall・Schema・Packagingの基準を記録する。
- v1.2.0統合済みの既存差分と、本ラウンドで追加する差分を分離して確認する。
- 実装前の変更範囲を`quality-loop/`、必要なテスト、Schema、Template、README、FUNCTIONAL_SPEC、qms-foundationsのみに固定する。

### Phase 1: Finding単位のPlan Gate

- `plan_required`な未解決Findingの集合をCore側で算出する。
- approvedなPlanのFinding ID集合を、PlanとPlan Reviewの対応およびFinding状態から算出する。
- partial Plan submissionは許容する。ただし、全required FindingのPlan承認が揃うまでは、globalな`submit-response` phaseへ遷移させない。
- `submit-response`ではhandoffの`next_action`だけに依存せず、implementation-bearing disposition（少なくとも`fix-submitted`）ごとに対象Finding自身のPlan承認を検査する。別FindingのPlan承認は流用不可とする。
- Low Findingのdirect responseと、AdaptiveなMedium Findingの既存挙動は維持する。
- 高リスクの`plan_required=false`によるdown-levelをCoreで許可しない。Critical/HighはCore導出の必須Planを維持し、Mediumは既存のrisk/context判定を維持する。
- pending Finding IDはhandoff/resumeから自動提示し、HumanがFinding IDを手で照合する新作業は追加しない。

### Phase 2: Planの未来形固定

- `submit-plan.schema.json`の`implementation_status`を`const: not-started`へ変更する。
- Runtimeでもdefense-in-depthとして`not-started`以外を拒否し、`in-progress`、`completed`、`fixed`相当をPlanとして受け付けない。
- 拒否は`state_changed: false`、安定したerror code、具体的remediationを返し、case正本を変更しない。
- 実装後の状態・結果はAuthor Response、Evidence、Verificationで扱う。

### Phase 3: Final Risk Assessmentの完全coverage

- `material_unresolved_finding_ids(case)`相当のCore helperを追加し、現行canonical Finding stateから期待集合を算出する。
- `verified`、`remediated`、`finding-withdrawn`、`converted-to-suggestion`、`not-applicable`を除外し、`improvement-proposal`を除外する。`partially-remediated`、`not-remediated`、`unverified`、`open`等のmaterialな未解決Findingは含める。
- `submitted residual_risk IDs == expected material unresolved IDs`を検査し、欠落を`residual-risk-coverage-incomplete`相当で拒否する。重複、未知ID、不要なmaterial扱いも拒否する。
- 各risk itemの`current_status`と`severity`をcanonical Findingと照合する。mismatchは推測で補正せず拒否し、正本を変更しない。
- Schema、Runtime、Final Risk Markdownのすべてで、期待集合の全件表示を確認する。
- Early Final Risk Assessmentを含む既存経路を壊さず、withdrawn/suggestionを過剰にHuman裁定へ昇格させない。

### Phase 4: 最小限の文書整理

- bundle内にないQMS referenceへのリンクを`quality-loop/references/qms-foundations.md`から削除する。
- `quality-loop/FUNCTIONAL_SPEC.md`のPlan Gate表現を、Critical/High原則必須、Medium adaptive、Low direct response原則へ統一する。
- Skill本文を長文化せず、必要な説明は既存の仕様・テスト・短い参照に限定する。

## 5. テストと検証

既存テストを弱めず、次の拒否系・正常系を追加する。

1. High + LowでLowのPlan承認後にHighの`fix-submitted`を試みると拒否される。
2. 2件のHighで1件だけPlan承認しても、未承認Findingは実装提出できない。
3. Lowのdirect responseは成功する。
4. `submit-plan`の`not-started`は成功し、`in-progress`と`completed`は拒否される。
5. unresolved F1/F2でF1だけのFinal Risk Assessmentは拒否される。
6. F1をwithdrawn、F2を未解決とした場合はF2のみで成功する。
7. suggestionおよびimprovement proposalはmaterial residualに強制しない。
8. canonical status mismatchとseverity mismatchは拒否される。
9. Role Firewall、CAS、stale handoff/revision、atomic write、idempotency、Change Observation、Adaptive Medium、QA withdrawal、Early Risk、Owner-only adjudication、active case resolution、Schemaを回帰する。

実装後は次を実行する。

```text
cd quality-loop
PYTHONDONTWRITEBYTECODE=1 python -B -m unittest discover -s tests -v
python -B -m compileall -q quality_loop tests
```

加えて、real jsonschema検証、`git diff --check`、標準ライブラリのみの展開後テスト、`._*`・`__pycache__`・`.pytest_cache`・`*.pyc`混入確認を行う。未取得の外部LLM/APIや本番Runtime Evidenceは完了扱いにしない。

## 6. Packaging

実装と全検証が成功した場合のみ、既存の`/tmp/Codex-fix.zip`を上書きせず、新規の`/tmp/Codex-fix-v1.3.0.zip`を作成する。zipには`quality-loop/`だけを含め、`unzip -tq`、展開後テスト、ファイル一覧、SHA-256を確認する。

外部Skill環境への配置、旧版削除、commit、push、deployment、`qms-cases/`変更は実施しない。

## 7. 完了判定

次の全条件を満たした場合に限り、v1.3.0を「技術的FIX候補」と報告する。

- Plan-required FindingのFinding単位Plan approvalをCoreが強制する。
- partial Planは許容しても、全required approval前のimplementation-bearing actionを拒否する。
- `submit-plan`で実装済み状態を偽装できない。
- Final Risk Summaryからmaterial unresolved Findingを欠落させられない。
- withdrawn/suggestion/improvement proposalを不必要にmaterial riskへ昇格させない。
- 既存98 testsと既存25 subtestsを含む回帰が成功する。
- 新規contract tests、compileall、Schema、Packaging hygiene、archive integrityが成功する。
- Human操作数、Runtime Context、Skill数、Role数、workflow phase数が増えていない。

技術的FIX候補であることは、独立QA、Owner受入、外部配置、commit、push、production deploymentの完了を意味しない。

## 8. 承認境界

このArtifactの作成、添付文書の読取り、現状確認は承認前に実施できる。以下はユーザーの明示承認後に開始する。

- Core、model、transitions、Schema、Template、testsの変更
- README、FUNCTIONAL_SPEC、referenceの変更
- regression、E2E、compileall、jsonschema、Packagingの実行
- `/tmp/Codex-fix-v1.3.0.zip`の作成

本計画に含まれない対象範囲、特に既存ルート文書の復元・削除、案件正本の変更、外部Skill配置、commit、pushを行う場合は、別計画と再承認を必要とする。

## 9. 実装・検証完了記録

- Plan 014の明示承認後、P0-1〜P0-3とP1文書整理を実装した。
- Finding単位Plan Gate、partial Plan時の未承認Finding再handoff、CoreによるCritical/High Plan要否の下げ止め、初回Finding statusの`open` canonicalizationを反映した。
- `submit-plan`は`implementation_status=not-started`だけを受理し、`in-progress`と`completed`を`invalid-plan-status`で拒否する。
- Final Risk Assessmentはmaterial unresolved Findingの完全coverage、canonical status、canonical severityを検証し、欠落を`residual-risk-coverage-incomplete`で拒否する。
- withdrawn、converted-to-suggestion、not-applicable、improvement-proposalはmaterial residualの期待集合から除外する。
- 既存98テストを含む全106テストが成功した。追加テストはPlan Gate、status lock、Risk coverage、withdrawal、status/severity mismatch、status偽装拒否を含む。
- compileall成功、stale reference 0、`git diff --check`成功、workspace内のcache/pyc 0を確認した。
- `/tmp/Codex-fix-v1.3.0.zip`を新規作成し、`unzip -tq`成功、展開後106テスト成功、96エントリ、禁止ファイル0を確認した。
- v1.3.0 zip SHA-256: `c7da197b711c7c05feb810643ff9ba031c41f055fecaf3c6a4c2750e879c1d39`
- 既存`/tmp/Codex-fix.zip`は上書きせず、SHA-256 `3ca2849ff51d8239813f440d433b346d60f2d7d19db479e6efba4754179c6993`を維持した。
- 実装前バックアップは`/private/tmp/quality-loop-v1.3-backup.1rioFm/quality-loop`に保存した。
- 外部Skill配置、旧版削除、`qms-cases/`変更、commit、push、deploymentは実施していない。
- 本結果はローカル技術検証済みのFIX候補であり、独立QAおよびOwner最終裁定を完了扱いにしない。
