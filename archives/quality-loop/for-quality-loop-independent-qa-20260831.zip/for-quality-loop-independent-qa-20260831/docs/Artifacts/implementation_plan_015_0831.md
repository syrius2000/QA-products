# Quality Loop v1.3.0再作業routing修正計画

created: 2026-08-31 06:59 (JST)
update: 2026-08-31 07:04 (JST)
author: Codex (GPT-5)

## 1. 計画の位置付け

本計画は、Plan 014（v1.3.0）の独立検証で発見された、Plan-required Findingの再作業時に発生する状態遷移deadlockを修正するための追加計画である。

ユーザーが提示した独立検証結果と修正提案を、本計画の対象範囲と受入条件の入力として扱う。添付されたv1.3.0文書群は、Plan Gate、Finding単位のPlan承認、Final Riskの完全coverage、Human負担を増やさないという設計背景および既存契約の参照資料として扱い、その文書自体を今回の実装対象にはしない。

既存のv1.3.0実装、テスト、Artifact、作業ツリー上のユーザー変更は保持する。既存の`/tmp/Codex-fix-v1.3.0.zip`は上書きしない。外部Skill配置、旧版削除、commit、pushも本計画の対象外とする。

## 2. 独立検証で確認された不具合

次のライフサイクルでdeadlockを再現済みである。

```text
High Finding
  ↓
Response Plan
  ↓
Reviewer Plan Accepted
  ↓
Implementer Response
  ↓
Reviewer Verification = not-remediated
```

cycle limit到達前にもかかわらず、Coreは`next_action=submit-response`を返す。しかしVerificationによりFindingの現在statusが`not-remediated`へ更新されるため、現在のPlan承認判定（`finding.status == "plan-approved"`）では過去の承認Planが見えなくなる。

その結果、次の操作は以下の双方が拒否される。

```text
submit-response → plan-approval-required
submit-plan     → state-transition-not-allowed
```

再現ハーネスでも、`submit-response / implementer-action / not-remediated`、続いて同じ拒否結果を確認した。原因は、Verification後のroutingがpending Plan-required Findingを判定せず、Plan承認の状態を現在statusだけから再評価していることである。

## 3. 修正方針

### 3.1 Core routingの最小修正

`quality-loop/quality_loop/engine.py`のVerification後routingだけを修正する。既存のヘルパーを再利用し、Schema、イベント形式、ロール、Skill本文、共有Contextを拡張しない。

Verification後の更新済みFindingから、次を算出する。

```text
pending_plan_required
= unresolved plan_required Finding IDs
  - valid Plan approval済みFinding IDs
```

既存のcycle limitおよびearly riskによるFinal Risk routingの優先順位、全Finding解決時のOwner adjudicationを維持した上で、通常の`submit-response`分岐の前に次を追加する。

```text
pending_plan_required が存在
  → next_role=implementer
  → next_action=submit-plan
  → state=implementer-plan
pending_plan_required が空
  → 従来どおり submit-response
```

`submit-plan`へ戻す場合のhandoffの`open_items`には、pendingとなったFinding IDを設定する。既存のFinding単位Plan承認をそのまま利用し、別FindingのPlan流用を再導入しない。

この判定により、次を同じ規則で扱う。

- 既承認Planの対象High/Critical（またはPlan-required相当）が`not-remediated`になった場合
- 再Verificationで新たに追加されたHigh/Critical Findingに有効なPlan承認がない場合
- Lowまたはsimple Mediumでpending Plan-required Findingがない場合

高リスクFindingの再作業では、最初の修正が不十分だった場合に次の修正内容を再度Planで確認する。Low/simple Mediumの従来の直接再修正経路は維持する。

### 3.2 文書の版表記

`quality-loop/FUNCTIONAL_SPEC.md`のタイトルだけを`Quality Loop 機能仕様 (v1.3.0)`へ更新し、本文の契約内容や構成は変更しない。

## 4. テスト計画

### 4.1 追加する回帰テスト

既存のテスト群を壊さず、Quality Loopの実際のengine lifecycleを通すE2E回帰テストを追加する。

1. High FindingについてPlan提出、Reviewer Plan Accepted、Response提出、Verification=`not-remediated`を順に実行する。
2. cycle limit未到達でVerification結果が`implementer-plan / submit-plan`になることを確認する。
3. 返されたhandoffの対象Findingについて、次の`submit-plan`が状態遷移拒否にならず受理されることを確認する。
4. その後に承認されたPlanに基づくResponse経路へ進めることを確認し、deadlockがないことを検証する。
5. 再Verificationで新High Findingを追加した場合も、Planなしの`submit-response`へ進まず`submit-plan`へroutingされることを確認する。
6. Lowまたはsimple Mediumのみの未解決Findingでは、既存どおり`submit-response`になることを確認する。

### 4.2 既存回帰と静的確認

- Quality Loop全テストを`python -B -m unittest discover -s tests -v`で実行する。
- 追加E2Eを含む全テストが成功することを確認する。
- `python -B -m compileall -q quality_loop tests`を実行する。
- `FUNCTIONAL_SPEC.md`の版表記を確認する。
- `qms-cases/`、既存package、外部Skill配置に変更がないことを確認する。

## 5. 受入条件

次のすべてを満たした場合に、実装を「deadlock修正済み候補」と判定する。

- High/Criticalの再作業Verification後、Plan承認が必要な状態で`implementer-plan / submit-plan`へ到達する。
- その状態で`submit-plan`が`state-transition-not-allowed`にならない。
- 再QAで追加されたPlan-required Findingも同じroutingで保護される。
- Low/simple Mediumの既存routingが変わらない。
- 既存テストおよび追加E2Eがすべて成功する。
- compileallが成功する。
- `FUNCTIONAL_SPEC.md`のタイトルがv1.3.0と一致する。
- 未解決の新規Finding、既存Planの流用、Skill本文の肥大化、外部配置、commit、pushが発生していない。

実装成功は正式FIXの独立QAを意味しない。実装後は、今回の独立検証と同じ再作業シナリオを別Invocationで再実行し、Ownerが最終判定する。

## 6. 実施境界と承認

承認後に変更してよい対象は、次の3点に限定する。

- `quality-loop/quality_loop/engine.py`のVerification後routing
- deadlockおよび新High Finding routingを検証するQuality LoopのE2E回帰テスト
- `quality-loop/FUNCTIONAL_SPEC.md`のタイトル版表記

承認前は、計画作成、読み取り専用調査、再現確認、差分確認のみを実施する。依存関係変更、データ変更、外部書込み、package生成、旧版削除、commit、pushは行わない。

## 7. 実装・検証記録

Plan 015の承認後、次を実装した。

- `engine.py`のVerification後にpending Plan-required Findingを算出し、該当時は`implementer-plan / submit-plan`へroutingする処理を追加した。
- `submit-plan`へ戻るhandoffの`open_items`をpending Finding IDに限定した。
- 既存のFinal Risk routing優先順位、全件解決時のOwner裁定、Low/simple Mediumの直接Response経路は維持した。
- High Findingの再作業、新High Finding追加、Low Finding再作業を通すE2E回帰テストを3件追加した。
- 既存の回帰シナリオにある新High regressionの期待状態を、新契約の`implementer-plan / submit-plan`へ更新した。
- `FUNCTIONAL_SPEC.md`のタイトルをv1.3.0へ更新した。

検証結果:

- `python -B -m unittest discover -s tests -v`: 109 tests passed
- `python -B -m compileall -q quality_loop tests`: 成功
- AppleDouble（`._*`、`.DS_Store`）: 0件
- package再生成、外部配置、旧版削除、commit、push: 未実施

実装候補としてのローカル検証は完了したが、正式FIXの判定には今回のdeadlockシナリオを用いた別Invocationの独立QAとOwner裁定が残る。
