# Acceptance Test Plan v1.2.0

## A. CLI / Resume

### A-01

Generate `resume.md`.

Copy suggested command exactly.

Expect:
- parser accepts
- referenced input file exists
- operation succeeds or reaches expected business validation

### A-02

All README/FUNCTIONAL_SPEC command examples are parseable.

---

## B. Traffic Light

### B-01
new case, not reviewed -> not Green

### B-02
accepted terminal, cycle=limit -> Green

### B-03
accepted-with-risk -> Yellow

### B-04
rejected -> Red

### B-05
non-terminal cycle limit reached -> appropriate escalation, not fake terminal success

---

## C. Schema Contract

For every operation:

```text
create-case
review
submit-plan
review-plan
submit-response
verify
assess-risk
adjudicate
```

Expect:
- resulting canonical `case.json` validates against real JSON Schema

### C-02
Every shipped example validates.

### C-03
Every shipped template validates against intake/input schema.

---

## D. Final Risk Human View

Given a material residual finding with:

- controls
- assumptions
- alternatives
- proportionality
- recommendation
- reassessment triggers

Expect all appear in final human summary.

Human does not need to inspect case.json.

---

## E. Early Risk Rationale

### E-01
cycle 1, no Critical, proportional residual -> assess-risk allowed with rationale.

### E-02
same but empty rationale -> reject.

### E-03
Critical unresolved -> reject early path.

### E-04
“verification is difficult” only -> remain unverified/evidence gap, not auto risk acceptance.

---

## F. Packaging

Expect:

```text
._*              0
__pycache__       0
.pytest_cache     0
*.pyc             0
```

Then:

```bash
python -m compileall -q quality_loop
pytest -q
```

success.

---

## G. Regression

Must preserve:

- Role Firewall
- separate invocation rule
- CAS
- stale revision
- stale handoff
- atomic write
- duplicate operation protection
- unauthorized change detection
- undeclared change detection
- Adaptive Plan Gate
- finding-withdrawn
- active case resolution
- Owner-only adjudication

---

## H. Human Efficiency

Dogfood metrics:

| Metric | Low-risk | Higher-risk |
|---|---:|---:|
| AI handoffs | | |
| Human interventions | | |
| Plan Gates | | |
| Cycles | | |
| Owner files read | | |
| QA withdrawals | | |

Success:
- low-risk remains lightweight
- higher-risk remains strict where needed
- Owner typically reads only final summary
