# Implementation Instructions v1.2.0

## Phase 1 — Human-facing correctness

### 1. resume CLI

- generated commandの入力方式を実CLIと統一
- 推奨: JSON file path
- README/FUNCTIONAL_SPEC/examplesも同じ方式
- generated command execution test追加

### 2. terminal traffic light

traffic light evaluatorの優先順位を修正。

Pseudo:

```python
if terminal_owner_decision:
    return terminal_signal()

if not_reviewed:
    return NOT_EVALUATED

if active_blocking:
    return RED

if residual_risk_or_gap:
    return YELLOW

if verified_complete:
    return GREEN
```

cycle limitをterminal decisionより先に判定しない。

---

## Phase 2 — Real Schema Contract

### 1. dependency

`jsonschema` をdevelopment/test dependencyとして使用してよい。
Runtime dependencyへ追加する必要がなければ追加しない。

### 2. test helper

例:

```python
def assert_case_schema_valid(case):
    jsonschema.validate(case, CASE_SCHEMA)
```

### 3. operation-by-operation

各operation保存後にvalidation。

### 4. examples

全exampleへvalidation。

example生成は可能な限りengine経由。

---

## Phase 3 — Final Risk Human View

`final-risk-assessment.md` rendererを改善。

各material issueについて:

```text
Residual Risk
Implemented Controls
Acceptance Assumptions
Alternatives
Proportionality
QA Recommendation
Reassessment Triggers
```

を出す。

### Human readability

- JSON dump禁止
- raw internal enumだけにしない
- 1 issueごとに短いsection
- full evidence logはlink/referenceのみ

---

## Phase 4 — Packaging hygiene

archive作成前にcleanup。

必須check:

```bash
find . -name '._*'
find . -name '__pycache__'
find . -name '.pytest_cache'
find . -name '*.pyc'
```

すべて0。

その後:

```bash
python -m compileall -q quality_loop
pytest -q
```

---

## Phase 5 — Early Risk rationale

Coreへ最小限追加。

例:

```json
{
  "early_risk_assessment": true,
  "early_risk_rationale": "..."
}
```

rationaleが空ならreject。

### Do not add

- numeric risk formula
- complex matrix
- extra approval
- extra role

---

## Phase 6 — Regression

既存82 testを維持し、
追加するのは高ROI contract tests中心。

必須:

1. generated CLI executable
2. terminal traffic light
3. real JSON Schema per operation
4. all examples schema valid
5. final risk human summary completeness
6. packaging hygiene
7. early risk rationale negative test

---

## Phase 7 — Dogfood

2案件だけ実施。

### Case A: low-risk

見ること:

- unnecessary Plan Gateがない
- human round trip少ない
- QAが過剰要求しない

### Case B: higher-risk

見ること:

- Plan Gateが必要時に発火
- Evidence boundary保持
- Final Risk Summaryが十分
- Ownerがsummaryだけで判断可能

---

## 実装担当への重要指示

今回の作業で新しいarchitectureを作らないこと。

最優先は:

> **現行architectureを矛盾なく仕上げること。**

変更が大きくなり始めたら、
その変更がP0/P1のどの具体的問題を解くか説明する。
説明できない変更は入れない。
