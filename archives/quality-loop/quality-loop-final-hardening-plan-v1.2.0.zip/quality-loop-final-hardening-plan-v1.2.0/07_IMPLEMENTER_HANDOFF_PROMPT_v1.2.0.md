# Implementer Handoff Prompt v1.2.0

```text
現行 quality-loop v1.1.0 completed版を基盤として、
Final Hardening Plan v1.2.0 に従ってRC→FIXへ仕上げてください。

今回の目的は新機能追加ではありません。

最優先:
1. resume-generated CLIを実CLIと完全一致
2. terminal Owner decision後のtraffic lightを正しくする
3. 各canonical stateを本当のJSON Schema validationへ通す
4. stale exampleをengine生成ベースへ直す
5. Final Risk SummaryだけでOwnerが判断可能にする
6. macOS `._*` / cache / pycを配布物から除去
7. Early Final Risk Assessmentに短いrationaleを必須化

絶対に弱めない:
- case.json canonical state
- Role Firewall
- CAS/revision/handoff
- Evidence integrity
- unauthorized/undeclared change detection
- Adaptive Plan Gate
- QA self-correction
- Owner-only final adjudication

追加しない:
- 第3 Skill
- 新Role
- 複雑なRisk matrix
- Human approval point
- verbose QMS docs
- scoring system

読む順序:
01_BASELINE_AND_CRITICAL_FIXES_v1.2.0.md
02_TARGET_OPERATING_MODEL_v1.2.0.md
03_IMPLEMENTATION_INSTRUCTIONS_v1.2.0.md
05_TODO_v1.2.0.md
06_ACCEPTANCE_TEST_PLAN_v1.2.0.md

05_TODOを進捗正本として更新してください。

各Phase後に:
- changed files
- test result
- contract impact
- human burden impact
- runtime context impact
- remaining risk
を記録してください。

すべてのRelease Gateを満たしたら、そこで一旦v1.xをFIXしてください。
机上の追加改善を続けず、以後は実運用feedbackのみを次版の根拠としてください。
```
