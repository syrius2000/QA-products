# Completion Plan Changelog v1.2.0

## v1.1.0 → v1.2.0

v1.1.0で主に改善されたもの:

- Quality Intent
- Adaptive Plan Gate
- QA self-correction
- Early Final Risk Assessment
- active case resolution
- current Functional Spec
- runtime context cleanup

v1.2.0はRC hardeningへ焦点を移す。

### New P0 focus

- resume CLI / actual CLI contract
- terminal traffic light semantics
- real JSON Schema contract testing
- stale example elimination
- complete Human Final Risk Summary
- macOS AppleDouble/cache packaging cleanup

### Small P1 refinement

- Early Final Risk Assessment rationale required

### Explicit stop rule

v1.2.0完了後は、
real-world evidenceがない限りarchitecture featureを追加しない。
