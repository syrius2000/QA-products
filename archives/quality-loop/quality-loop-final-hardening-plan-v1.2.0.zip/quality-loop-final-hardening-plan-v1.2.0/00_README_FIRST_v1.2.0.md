# Quality Loop Final Hardening Plan v1.2.0 — START HERE

created: 2026-08-30 (JST)  
status: Release-candidate hardening plan  
target: `quality-loop-v1.1.0-completed-20260830_225303.tar.gz`

---

## 1. このv1.2.0の目的

v1.1.0で、Quality Loopの主要設計はほぼ完成した。

- Role Firewall
- `case.json` canonical state
- Quality Intent
- Adaptive Plan Gate
- QA self-correction
- Early Final Risk Assessment
- Human/Owner adjudication
- Short-context Skill design

今回のv1.2.0は、これ以上機能を増やすための計画ではない。

> **Release CandidateをFIX可能な状態へ持っていくための、最終契約整合・表示整合・Human UX・Packaging hardening計画**

である。

---

## 2. 今回の優先順位

1. Humanへ誤解を与える表示をゼロにする
2. Schema / engine / examples / CLI / resumeを完全一致させる
3. Humanが最終Risk判断に必要な情報を1枚で読めるようにする
4. Packaging hygieneを整える
5. 既存の軽量性を壊さない
6. 新しいQMS機能は追加しない

---

## 3. 今回は「直して終える」

以下は今回追加しない。

- 第3 Skill
- 新しいRole
- 新しいRisk matrix
- CAPA
- education/training records
- new scoring system
- AI評価スコア
- mandatory Human approval point
- verbose QMS documentation

今回の完成条件は、

> **もっと高機能になることではなく、今ある設計が一貫し、短い指示で、誤解なく、軽く動くこと**

である。

---

## 4. 実装担当AIへの読み順

1. `01_BASELINE_AND_CRITICAL_FIXES_v1.2.0.md`
2. `02_TARGET_OPERATING_MODEL_v1.2.0.md`
3. `03_IMPLEMENTATION_INSTRUCTIONS_v1.2.0.md`
4. `05_TODO_v1.2.0.md`
5. `06_ACCEPTANCE_TEST_PLAN_v1.2.0.md`

---

## 5. Doneの定義

以下を満たしたら、いったんv1.xをFIXし、運用フェーズへ移る。

- すべてのhuman-facing CLI例が実際に実行可能
- terminal owner decision後のtraffic lightが正しい
- 全canonical caseが実JSON Schemaに適合
- 全exampleが現行Schemaに適合
- Final Risk SummaryだけでOwner判断可能
- `._*`, `__pycache__`, `.pytest_cache`, `*.pyc` が配布物にない
- 既存82 tests + 新しいcontract testsがすべて成功
- Skill本文・QMS foundationが大幅に肥大化していない
- 通常Human操作数が増えていない

> **Done means coherent, usable, and fit for intended use — not maximally elaborate.**
