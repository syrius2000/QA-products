# TODO — Quality Loop Final Hardening v1.2.0

> このTODOを実装進捗正本として使う。  
> 各Phase後に `変更 / test / human burden / context impact / residual risk` を記録する。

---

# Phase 0 — Freeze

- [ ] source archive SHA-256記録
- [ ] file inventory保存
- [ ] baseline full test実行
- [ ] `82 passed`確認
- [ ] current Skill行数記録
- [ ] current schema hash記録
- [ ] current examples inventory記録

### Checkpoint

- [ ] baselineへ復元可能

### Log

```text
Date:
Agent:
Baseline tests:
Notes:
```

---

# Phase 1 — Resume / CLI Contract

- [ ] resume-generated CLI棚卸し
- [ ] actual argparse/interface棚卸し
- [ ] input方式をfile-basedへ統一
- [ ] README更新
- [ ] FUNCTIONAL_SPEC更新
- [ ] examples更新
- [ ] generated command execution test追加

### Checkpoint

- [ ] resumeのcommandをcopy-pasteして実行可能

### Log

```text
Changed:
Tests:
Human burden impact:
Context impact:
```

---

# Phase 2 — Traffic Light Terminal Semantics

- [ ] terminal owner decisionを最優先
- [ ] accepted -> Green
- [ ] accepted-with-risk -> Yellow
- [ ] rejected -> Red
- [ ] held/deferred -> Yellow
- [ ] cycle limitをterminal decisionより後へ
- [ ] unreviewed state regression維持
- [ ] tests追加

### Checkpoint

- [ ] cycle_limit reachedでもacceptedがRedにならない
- [ ] 未レビューがGreenにならない

---

# Phase 3 — Real JSON Schema Contract

- [ ] `jsonschema` test dependency確認
- [ ] case schema validation helper
- [ ] create-case output validation
- [ ] review output validation
- [ ] submit-plan output validation
- [ ] review-plan output validation
- [ ] submit-response output validation
- [ ] verify output validation
- [ ] assess-risk output validation
- [ ] adjudicate output validation
- [ ] all examples validation
- [ ] all templates validation

### Checkpoint

- [ ] saved canonical state 100% schema valid

---

# Phase 4 — Example Drift Elimination

- [ ] example generation strategy決定
- [ ] standard cycle regenerate
- [ ] evidence rebuttal regenerate
- [ ] regression regenerate
- [ ] accepted-with-risk regenerate
- [ ] Plan Gate example regenerate
- [ ] early-risk example regenerate
- [ ] finding-withdrawn example確認
- [ ] revision monotonic確認
- [ ] obsolete enum/status 0

### Checkpoint

- [ ] examples are executable specifications

---

# Phase 5 — Final Risk Human Summary

- [ ] residual risk表示
- [ ] implemented controls表示
- [ ] acceptance assumptions表示
- [ ] alternatives表示
- [ ] proportionality表示
- [ ] QA recommendation表示
- [ ] reassessment triggers表示
- [ ] confidence必要時表示
- [ ] raw event log default非表示
- [ ] full hash default非表示

### Human check

- [ ] Ownerが`case.json`を読まず判断可能
- [ ] 過去cycle全文を読まず判断可能

---

# Phase 6 — Early Final Risk Rationale

- [ ] `early_risk_rationale`追加
- [ ] non-empty validation
- [ ] unresolved Critical guard維持
- [ ] residual risk existence check
- [ ] positive E2E
- [ ] empty rationale negative test
- [ ] “verification difficult only” misuse test

### Checkpoint

- [ ] early risk is proportionality escape, not shortcut

---

# Phase 7 — Packaging Hygiene

- [ ] `._*`削除
- [ ] `__pycache__`削除
- [ ] `.pytest_cache`削除
- [ ] `*.pyc`削除
- [ ] temp cases削除
- [ ] runtime logs削除
- [ ] secrets check
- [ ] `python -m compileall -q quality_loop`
- [ ] archive integrity check

### Checkpoint

```text
find . -name '._*'          => 0
find . -name '__pycache__' => 0
find . -name '.pytest_cache' => 0
find . -name '*.pyc'       => 0
```

---

# Phase 8 — Full Regression

- [ ] previous 82 tests green
- [ ] new CLI contract tests green
- [ ] terminal traffic tests green
- [ ] real Schema contract tests green
- [ ] example tests green
- [ ] risk summary tests green
- [ ] packaging test green
- [ ] Role Firewall regression green
- [ ] CAS regression green
- [ ] stale handoff regression green
- [ ] duplicate op regression green
- [ ] unauthorized change regression green
- [ ] finding-withdrawn regression green
- [ ] adaptive Medium Plan Gate regression green
- [ ] early Final Risk regression green

---

# Phase 9 — Dogfood

## Low-risk case

- [ ] unnecessary Plan Gate count記録
- [ ] AI handoff count記録
- [ ] Human intervention count記録
- [ ] false positive/over-QA確認

## Higher-risk case

- [ ] Plan Gate必要時に発火
- [ ] Evidence integrity確認
- [ ] Final Risk Summary確認
- [ ] Owner summary-only decision確認

### Checkpoint

- [ ] quality increased or maintained
- [ ] normal human burden not increased
- [ ] runtime context not materially increased

---

# Phase 10 — Release

- [ ] version update
- [ ] CHANGELOG
- [ ] README final
- [ ] FUNCTIONAL_SPEC final
- [ ] archive built
- [ ] archive SHA-256
- [ ] release note作成

---

# FINAL CHECKPOINT

- [ ] CLI/resume mismatch = 0
- [ ] terminal traffic mismatch = 0
- [ ] schema drift = 0
- [ ] example drift = 0
- [ ] packaging artifacts = 0
- [ ] Human risk summary complete
- [ ] normal Human operations増加なし
- [ ] Skill context大幅増加なし
- [ ] no new Skill
- [ ] no unnecessary QMS ceremony
- [ ] v1.x FIX candidateとして承認可能

> **Stop improving the architecture here unless real operational evidence demands it.**
