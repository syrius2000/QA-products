# Target Operating Model v1.2.0

## 1. 完成後の姿

今回の改修で状態機械そのものを大きく増やさない。

```text
Human Owner
   │
   ├─ Quality Intent
   └─ Final Risk Decision

AI-2 Reviewer
   │
   ├─ Review
   ├─ Plan Review when needed
   ├─ Verification
   ├─ Self-correction
   └─ Final Risk Assessment

AI-1 Implementer
   │
   ├─ Response Plan when needed
   ├─ Authorized Fix
   └─ Evidence Submission

Quality Loop Core
   │
   ├─ canonical case.json
   ├─ Role Firewall
   ├─ handoff / CAS
   ├─ evidence integrity
   ├─ deterministic next_action
   └─ human-facing derived views
```

---

## 2. 通常フロー

### Low / simple Medium

```text
Review
  ↓
Response/Fix
  ↓
Verification
  ↓
Close / Risk / Next cycle
```

### High / Critical / complex Medium

```text
Review
  ↓
Response Plan
  ↓
Plan Review
  ↓
Authorized Fix
  ↓
Verification
```

Plan GateはSeverity Ceremonyではない。

> **wrong-fixを防ぐ必要があるときだけ使用する。**

---

## 3. QA自己訂正

QA Findingは絶対的真理ではない。

合法なOutcome:

- remediated
- partially-remediated
- not-remediated
- unverified
- finding-withdrawn
- converted-to-suggestion
- not-applicable

Reviewerが間違っていた場合、
Findingを撤回することは成功Outcomeである。

---

## 4. cycle limit

```text
cycle_limit = automatic negotiation safety cap
```

であり、

```text
minimum required iterations
```

ではない。

### early final risk

次を満たす場合、Reviewerはcycle limit前でもFinal Risk Assessmentへ進める。

- Critical unresolved = 0
- residual riskとして評価可能
- additional remediationの限界便益が小さい
- Quality Intentに照らしてOwner判断が合理的
- rationaleが記録される

---

## 5. Human terminal state

Human Owner裁定後は、
traffic lightもOwner decisionを最優先する。

```text
accepted
→ Green

accepted-with-risk
→ Yellow

rejected
→ Red

deferred/held
→ Yellow
```

cycle countは履歴情報。

Owner decisionを上書きするsignalにしない。

---

## 6. Human final summary

Humanが読むのは原則1枚。

例:

```text
Final QA Risk & Adjudication Summary

Resolved
- C-01 fixed-and-verified
- F02 finding-withdrawn

Residual
- F05 High partially-remediated

Risk Acceptance Basis
- residual risk
- implemented controls
- assumptions
- alternatives
- proportionality
- QA recommendation
- reassessment triggers

Owner Decision
[ ] Accept
[ ] Accept with conditions
[ ] Additional remediation
[ ] Defer
```

Humanは通常、
過去3cycleの全文を読む必要はない。

---

## 7. CLI/Resume contract

`resume.md` は説明文ではなく、
**次Actionの実行可能ビュー**である。

したがって:

```text
generated command
=
actual CLI contract
```

でなければならない。

推奨はfile-based JSON inputへ統一。

---

## 8. Schema Contract

以下は同じシステム契約を表現する。

```text
engine model
case.schema.json
intake.schema.json
templates
examples
FUNCTIONAL_SPEC
README
resume.md
final-risk-assessment.md
```

1つでも意味が違えばdrift。

testで検出する。

---

## 9. Runtime Context

Runtime時に通常読むもの:

- quality-review/SKILL.md
- quality-response/SKILL.md
- qms-foundations.md（必要時）
- active handoff/resume/case-derived view

通常読まないもの:

- completion plans
- docs/Feedback
- old examples
- historical discussion
- tests
- development roadmap

---

## 10. Human UX

通常Humanは:

```text
quality-review でXXをQAして
quality-response でhandoffを確認して対応して
quality-review で再点検して
```

程度。

内部identifierはCore/Skillが解決。

このUXを壊す追加機能は原則入れない。

---

## 11. FIX後の方針

v1.2 hardening後は、
設計改善を一旦停止してdogfoodへ移行する。

次のversionで改修するのは:

- 実案件で発生した具体的摩擦
- repeated false positive
- repeated human burden
- evidence integrity issue
- state ambiguity

だけ。

机上の“もっと良いQMS”を理由に機能追加しない。
