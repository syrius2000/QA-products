# Release Criteria v1.2.0

## Release Candidate → FIX gate

### Contract

- [ ] actual CLI == resume-generated CLI
- [ ] engine outputs == JSON Schema
- [ ] templates == Schema
- [ ] examples == current model
- [ ] FUNCTIONAL_SPEC == current operations
- [ ] README == actual UX

### Human Signal

- [ ] unreviewed != Green
- [ ] accepted terminal == Green
- [ ] accepted-with-risk == Yellow
- [ ] rejected == Red
- [ ] cycle limit does not override terminal decision

### Risk Summary

- [ ] Controls visible
- [ ] Assumptions visible
- [ ] Alternatives visible
- [ ] Proportionality visible
- [ ] QA Recommendation visible
- [ ] Reassessment triggers visible

### Packaging

- [ ] `._*` = 0
- [ ] `__pycache__` = 0
- [ ] `.pytest_cache` = 0
- [ ] `*.pyc` = 0
- [ ] compileall success
- [ ] archive integrity success
- [ ] SHA-256 recorded

### Quality/Efficiency

- [ ] no new Skill
- [ ] no new mandatory Human gate
- [ ] no new complex risk matrix
- [ ] normal Skill context materially unchanged
- [ ] simple Medium remains direct-response capable
- [ ] early Final Risk Assessment still available
- [ ] early Final Risk requires rationale

### Tests

- [ ] previous 82 tests remain green
- [ ] new contract tests green
- [ ] E2E low-risk green
- [ ] E2E higher-risk green

---

## FIX decision

すべて満たしたら:

> **v1.x設計を一度FIXし、実運用feedback中心の保守フェーズへ移る。**

未達なら新機能を足さず、
未達項目だけ修正する。
