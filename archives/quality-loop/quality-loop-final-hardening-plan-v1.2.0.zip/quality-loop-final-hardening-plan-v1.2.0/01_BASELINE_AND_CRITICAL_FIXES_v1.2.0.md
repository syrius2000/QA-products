# Baseline & Critical Fixes v1.2.0

## 1. Baseline

対象RCでは以下を確認済み。

```text
82 tests / 82 passed
```

また以下の設計改善も確認済み。

- Quality Intent
- Adaptive Medium Plan Gate
- `finding-withdrawn`
- Early Final Risk Assessment
- active case auto-resolution
- Role Firewall / revision / CAS
- compact Skill context

したがって、本計画では設計を作り直さない。

---

# P0-1: `resume.md` が提示するCLIをそのまま実行できない

## 現象

`resume.md` が次のような例を生成する。

```bash
quality-loop adjudicate --input '{"decision":"accepted", ...}'
```

しかし実CLIは `--input` をJSONファイルパスとして扱うため、
inline JSONをファイル名として解釈し `input-not-found` になる。

## なぜ重要か

`resume.md` はHuman/AIの「次の一手」を圧縮する主UIである。

ここに実行不能なcommandが出ると、

- HumanがCLI仕様を調べる
- AIが勝手に修正文を推測する
- context/操作が増える

ため、短いUX設計が崩れる。

## 推奨FIX

**ファイル入力方式へ統一**する。

例:

```bash
quality-loop adjudicate --input /tmp/quality-loop-adjudicate.json
```

inline JSON supportを新機能として追加する必要はない。

## Acceptance

- resume-generated commandを実際のCLI parserへ渡して成功
- README/FUNCTIONAL_SPEC/examplesも同じ入力方式
- command contract testを追加

---

# P0-2: terminal Owner decision後もcycle limitでRedになる

## 現象

例:

```text
status = accepted
cycle_count = 3
cycle_limit = 3
```

でもtraffic lightがRedになる。

## 問題

`cycle_limit` は「品質Failure」ではない。

これは自動AI反復の上限である。

Ownerが最終的にacceptedと裁定した後も、
過去に3 cycles使ったという理由でRedを維持するのは、
状態表示として誤っている。

## 推奨priority

```text
terminal owner decision
    ↓
accepted              -> Green
accepted-with-risk    -> Yellow
rejected              -> Red
held/deferred         -> Yellow

non-terminal only:
    cycle-limit / open finding / evidence gap を評価
```

## Acceptance

- accepted terminal = Green
- accepted-with-risk = Yellow
- rejected = Red
- cycle countは補助情報として表示
- cycle limit自体を品質判定にしない

---

# P0-3: “Schema test” を本当のJSON Schema validationへ変更

## 現象

現行testはtop-level key整合を見るが、
実際のJSON Schema validatorで各canonical stateを完全検証していない。

独立validationではexampleの一部が現行 `case.schema.json` に適合しない状態が残っていた。

## 必須FIX

`jsonschema.validate()` 等を使い、
**実Schema validationを契約テスト化**する。

### 必須対象

各operation後:

```text
create-case
review
submit-plan
review-plan
submit-response
verify
assess-risk
adjudicate
```

### 全example

- standard cycle
- evidence rebuttal
- regression
- accepted-with-risk
- plan gate
- early risk
- withdrawal

## Acceptance

- every canonical case validates
- every example validates
- revision monotonic
- obsolete vocabularyなし

---

# P0-4: Example driftを完全に止める

## 原則

exampleのcanonical `case.json` を手で保守しない。

推奨:

```text
fixture / scenario definition
    ↓
engine operations
    ↓
generated case.json
    ↓
schema validation
    ↓
generated resume/risk summary
```

これにより、
Schema/state vocabularyの更新時にexampleだけ古くなることを防ぐ。

---

# P0-5: Final Risk SummaryがHuman decisionに必要な情報を出し切っていない

## 現状

内部データには以下が存在する。

- implemented controls
- assumptions supporting acceptance
- alternatives
- proportionality assessment
- reassessment triggers

しかしHuman向け文書に十分表示されない。

## 問題

Ownerが最終裁定のために `case.json` を読む必要が出る。

これは「Human介在最小化」に反する。

## 必須表示

各material residual findingについて:

```text
Finding
Residual Risk
Implemented Controls
Assumptions Supporting Acceptance
Alternatives
Proportionality
QA Recommendation
Reassessment Triggers
```

必要ならConfidenceも表示。

## 表示しない

default human viewへ以下は不要。

- full event history
- all hashes
- raw CLI JSON
- all prior responses
- all verification transcript

---

# P0-6: macOS AppleDouble `._*` を配布物から除去

## 現象

macOS由来の `._*` ファイルが多数混入すると、
`compileall` 等がnull byte errorを起こす可能性がある。

## FIX

packaging前に:

```bash
find . -name '._*' -delete
find . -name '__pycache__' -type d -prune -exec rm -rf {} +
find . -name '.pytest_cache' -type d -prune -exec rm -rf {} +
find . -name '*.pyc' -delete
```

またはmacOS archive時:

```bash
COPYFILE_DISABLE=1
```

を利用。

## Acceptance

- `find . -name '._*'` = 0
- `python -m compileall` success
- archive integrity success

---

# P1-1: Early Final Risk Assessmentには短いrationaleを必須化

## 現状

早期Risk移行自体は良い。

ただしCore guardが軽すぎると、
Reviewerが単に `early_risk_assessment=true` とするだけで
“面倒だからRisk Acceptanceへ”進む余地がある。

## 推奨

次を必須にする。

```json
{
  "early_risk_assessment": true,
  "early_risk_rationale": "追加改修によるリスク低減が限定的で、現Quality IntentではOwner裁定が合理的"
}
```

## Guard

- unresolved Critical = 0
- rationale non-empty
- residual issue exists
- owner-readable risk assessmentを生成可能

Risk matrix追加は不要。

---

# P1-2: Skill/contextをこれ以上増やさない

現状のSkill/Referenceは十分軽い。

今回の修正を説明するために、
SKILL.mdへ長いQMS説明を追加しない。

Core/test/document consistencyで解決する。

---

# P0 Checkpoint

以下が全部trueになるまでRelease FIXしない。

- [ ] resume CLI executable
- [ ] terminal traffic light correct
- [ ] full JSON Schema validation green
- [ ] all examples schema valid
- [ ] Human final risk summary complete
- [ ] AppleDouble/cache removed
