# Quality Loop Completion Plan v1.1.0 — START HERE

created: 2026-08-30 (JST)  
status: Completion / hardening instruction package  
source package: `quality-loop-sola-completed-20260830_204733.zip`  
source SHA-256: `c0b30dd137765c65426331528d4383d634bc63f7436b8c19f6f6922721b9c131`  
baseline automated test: `78 passed`

---

## 1. このv1.1.0の位置づけ

前回の `quality-loop-completion-plan-v1.0` は、旧 `spec-driven-qa-*` から新しい `quality-loop` 基盤へ移行し、
以下を実装するための「構造完成計画」だった。

- Role Firewall
- `case.json` 単一正本
- Handoff / revision / CAS
- Plan Before Fix
- QA自己訂正
- Final Risk Assessment
- Quality Intent

今回の **v1.1.0** は、その構造を増築する計画ではない。

> **現行 `quality-loop` を、日常運用で軽く・速く・誤解なく使えるFIX候補へ仕上げるための最終ハードニング計画**

である。

今回の優先順位は次の順とする。

1. **誤った表示・Schema契約不整合をゼロにする**
2. **QA品質を落とさずAI往復回数を減らす**
3. **Human Ownerが読む・判断する量を減らす**
4. **Skill prompt / contextを肥大させない**
5. **新しい機能・Role・Skillを安易に追加しない**

---

## 2. 今回維持する設計原則

以下は原則として変更しない。

- `case.json` が唯一のcanonical state
- `resume.md` / risk summary は派生ビュー
- Owner / Reviewer / Implementer のRole Firewall
- stale revision / stale handoff / duplicate operationの拒否
- atomic write / backup / CAS
- Evidence integrity
- ReviewerとImplementerの別Invocation
- AI-1は品質基準を自己決定しない
- AI-2は完全性を品質基準として押し付けない
- Human Ownerが Quality Intent と最終Risk Acceptanceを所有する
- QA Findingは撤回可能
- `fix-submitted` は `verified` ではない
- Final Risk AssessmentはHuman判断を代行しない

---

## 3. v1.1.0で最重要な考え方

### 3.1 Strict when needed, light when not needed

QMSは厳格であること自体を目的にしない。

```text
必要なときだけ厳格
不要なときは軽量
```

を実装レベルで実現する。

### 3.2 Plan Before Fixは「儀式」ではない

Plan Gateの目的は、AI-1がFindingを誤解して無駄な修正をすることを防ぐことである。

したがって、

- Critical / High: 原則Plan必須
- Low: 原則直接Response/Fix
- Medium: **context/riskベースでPlan要否を判定**

とする。

### 3.3 3 cyclesは最低実施回数ではない

`cycle_limit=3` は、

> 3回やらなければ終われない

という意味ではない。

これは自動AI交渉の**上限**である。

追加修正の限界便益が小さく、Critical未解決がない場合は、Reviewerが理由付きで早期に `Final Risk Assessment` へ移行できる設計を認める。

### 3.4 Humanには「議論」ではなく「決定材料」を渡す

Human Ownerは、原則として全Finding履歴・全Cycleログ・全CLI JSONを読む必要はない。

最終的に必要なのは、

- 何が解決したか
- 何が残ったか
- 残余リスク
- 実施済みControl
- 受容を支持する仮定
- Alternative
- QA Recommendation
- 再評価Trigger

である。

---

## 4. 実装担当AIが最初に守ること

### MUST

- 現行 `quality-loop` を正本として改修する
- v1.0で得たRole Firewall / CAS / atomic writeを弱めない
- P0を先に直し、その後P1へ進む
- 各Phase後に生成物をSchema検証する
- `05_TODO_v1.1.0.md` を更新する
- 変更理由を「品質」「効率」「人負担」のどれに効くか記録する

### MUST NOT

- 第3のQMS Skillを追加する
- Risk scoring matrixを複雑化する
- Human承認ポイントを増やす
- ISO/GxP解説をSkill本文へ大量追加する
- Legacy説明を積み上げてRuntime Contextを肥大化する
- 既知の不整合を「テストが通るから」と放置する

---

## 5. 推奨読み順

1. `01_BASELINE_AND_CRITICAL_FIXES_v1.1.0.md`
2. `02_TARGET_OPERATING_MODEL_v1.1.0.md`
3. `03_IMPLEMENTATION_INSTRUCTIONS_v1.1.0.md`
4. `04_EFFICIENCY_QUALITY_PLAN_v1.1.0.md`
5. `05_TODO_v1.1.0.md`
6. `06_ACCEPTANCE_TEST_PLAN_v1.1.0.md`
7. `07_RELEASE_AND_PACKAGING_v1.1.0.md`
8. 必要時のみ `08_IMPLEMENTER_HANDOFF_PROMPT_v1.1.0.md`

---

## 6. 完成後のHuman UX

通常ケースでは人間は次の程度でよい。

```text
#1 quality-review で XX計画書の実装をQAレビューして
#2 quality-response で handoffを確認して対応して
#3 quality-review で再点検して
```

内部の

- case ID
- revision
- cycle
- Finding ID
- next_action
- Role
- CLI contract

は可能な限りSkill/Coreが処理する。

例外時だけHumanへ聞く。

---

## 7. v1.1.0 Definition of Done

この計画のDoneは「機能を全部増やした」ではない。

以下を満たしたときDoneとする。

- canonical caseが常にSchema valid
- templateもSchema valid
- 未レビュー案件をGreen表示しない
- docs / CLI / generated resumeが一致
- Medium Findingで不要なPlan往復が減る
- cycle limit前でも合理的にRisk Assessmentへ進める
- Humanが最終summaryだけで裁定可能
- Skill本文・referenceのRuntime Contextが増えすぎない
- usual pathでHumanの操作回数が増えない
- 全automated test + E2Eが成功
