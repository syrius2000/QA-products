# Baseline & Critical Fixes v1.1.0

## 1. Baseline summary

評価対象は `quality-loop-sola-completed-20260830_204733.zip`。

確認時点の自動テスト:

```text
78 passed
```

これは重要な成果である。ただし、**test pass = contract consistency** ではない。
以下のP0項目はFIX前に解消する。

---

# P0-1: 未レビュー案件が「緑・検証完了・安全」と表示される

## 現象

新規case作成直後、まだReviewerが `review` を実施していない状態でも、
`resume.md` のtraffic lightが緑へ落ちる可能性がある。

状態は実際には:

```text
status = reviewer-action
next_action = review
```

である。

しかしFindingが0件、gapが0件であるため、
traffic light判定が最終defaultのGreenへ進む。

## リスク

これは単なるUI誤表示ではない。

> 未評価 = 安全

という誤ったQuality signalをHumanへ与える。

## 必須修正

Greenの成立条件を明示する。

推奨状態:

- ⚪ 未評価
- 🔵 評価中
- 🟡 条件付き / Evidence gap / residual risk
- 🔴 要対応
- 🟢 検証完了

少なくとも:

```text
Green is allowed only after reviewer evidence evaluation has occurred
AND no unresolved blocking condition exists.
```

をtestで固定する。

## Acceptance

- create-case直後はGreenでない
- review途中はGreenでない
- verified terminal / human-ready stateのみGreen候補
- risk付きはYellowまたは明示的risk state

---

# P0-2: `case.schema.json` とengine生成正本の不一致

## 現象

engineは現在、少なくとも以下をcanonical caseへ記録する。

- `plans`
- `plan_reviews`
- `final_risk_assessments`

一方、`case.schema.json` はこれらをpropertiesへ定義していない。
かつ `additionalProperties: false` である。

## 必須修正

`case.schema.json` を現行canonical modelへ追随させる。

### 必須テスト

各主要state transition後:

```text
create-case
review
submit-plan
review-plan
submit-response
verify
assess-risk
adjudicate
```

で保存された `case.json` をSchema validationする。

これを1本のE2E contract testとして固定する。

---

# P0-3: Quality IntentがSchemaでは必須、engine/templateでは不統一

## 現象

`intake.schema.json` はbaselineに:

- `intended_use`
- `risk_context`

を必須としている。

しかし同梱 `templates/intake.json` はこれらを欠く。

さらにengine validationがSchemaと完全一致していない場合、
「Schemaでは不正・engineでは作成可能」という二重契約になる。

## 決定

v1.1.0では最低Quality Intentを次で固定する。

### Required

- `purpose`
- `intended_use`
- `risk_context`
- `requirements`
- `acceptance_criteria`
- `targets`
- `target_revision`

### Optional

- `constraints`
- `applicable_obligations`
- `unacceptable_failures`
- `exclusions`

## Acceptance

- templateはそのままSchema valid
- engine accepted inputはSchema valid
- Schema valid inputはengineが同じ意味でaccept
- required項目の欠落は両方でreject

---

# P0-4: `FUNCTIONAL_SPEC.md` が現行実装より古い

## 現象

現行文書には:

- 4段階
- CLI 6操作

と記載される。

しかし実装は少なくとも:

- `create-case`
- `review`
- `submit-plan`
- `review-plan`
- `submit-response`
- `verify`
- `assess-risk`
- `adjudicate`
- `status`

を持つ。

またPlan Before Fix / Finding withdrawal / Final Risk Assessmentが十分に反映されていない。

## 必須修正

`FUNCTIONAL_SPEC.md` を現行canonical behaviorへ更新する。

旧version説明を同じRuntime文書へ併記しない。
履歴が必要ならCHANGELOGへ移す。

---

# P0-5: example driftを防ぐ

## 現象

exampleがengineのcanonical modelや新Outcomeと一致しなくなると、
AIに古い語彙を学習させるContext contaminationになる。

## 必須修正

examplesを**手書きcanonical stateとして管理しない**。

推奨:

```text
tests / generation script
  -> engine operations
  -> generated case.json
  -> generated resume.md
  -> schema validation
```

特にEvidence rebuttal例では、
反証が成立した場合は `finding-withdrawn` 等の現行語彙を使う。

---

# P0-6: generated resume / docs / CLIの一致

## 必須原則

Human向けに表示するCLI例は、実CLI parserで必ず実行可能でなければならない。

### Contract test

- resumeに生成されたcommandをparse
- CLIが受理
- inline JSON / file input policyと一致
- `--input` と文書例を一本化

---

# P0-7: P0を終えるまで新しいQMS機能を追加しない

P0は「つまらない整合性修正」に見えるが、
QMSとしてはこちらの方が新機能より重要である。

**P0 checkpoint:**

> 保存される正本、Schema、Template、Skill、Functional Spec、Example、Resumeが同じ契約を語っている。
