# Target Operating Model v1.1.0

## 1. 最上位設計

```text
Human Owner
  ├─ Quality Intent
  └─ Final Risk Decision

AI-2 Reviewer
  ├─ Review
  ├─ Plan Review (必要時)
  ├─ Independent Verification
  ├─ Finding Self-Correction
  └─ Final Risk Assessment

AI-1 Implementer
  ├─ Response Plan (必要時)
  ├─ Authorized Implementation
  └─ Evidence Submission

Quality Loop Core
  ├─ case.json canonical state
  ├─ Role Firewall
  ├─ Handoff / CAS
  ├─ atomic persistence
  ├─ evidence/change boundary
  └─ deterministic next_action
```

AIは品質のOwnerではない。

---

# 2. Target state machine

## 2.1 通常経路

```text
reviewer-action / review
        ↓
  ┌─────┴──────────────┐
  │                    │
plan required       plan not required
  │                    │
  ↓                    ↓
implementer-plan    implementer-action
  ↓                    │
reviewer-plan-review   │
  ↓                    │
implementer-action ←───┘
        ↓
reviewer-verification
        ↓
  ├─ resolved → final/owner-ready
  ├─ rework justified → next cycle
  └─ further rework disproportionate → final-risk-assessment
```

## 2.2 Final

```text
reviewer-final-assessment
        ↓
owner-adjudication
        ↓
accepted
accepted-with-risk
held
rejected
rework-requested
```

---

# 3. Adaptive Plan Gate

Plan Before Fixは残す。ただしSeverityだけでMediumを機械的に重くしない。

## Critical

Default:

```text
plan_required = true
```

例外は原則Owner overrideのみ。

## High

Default:

```text
plan_required = true
```

## Low

Default:

```text
plan_required = false
```

## Medium

次のrisk/context flagを評価して決める。

### Plan required conditions

少なくとも1つ該当すればPlan Gate候補:

- Findingの解釈が曖昧
- 複数の合理的 remediation option がある
- 複数file/moduleへ波及
- destructive / irreversible
- external system / production / deviceへ変更
- security boundaryへ影響
- data integrityへ影響
- baseline / intended use解釈へ影響
- ReviewerとImplementerの理解差が生じやすい
- remediation costが中〜高
- rollbackが容易でない

それ以外の単純なMedium:

```text
Finding → submit-response → verify
```

でよい。

## 重要原則

> Plan GateはQuality ceremonyではない。Wrong Fixを防ぐためのrisk controlである。

---

# 4. Reviewer Self-Correction

Reviewer Findingはimmutable historyとして保存するが、
Reviewerの最終解釈は変化できる。

正式Outcomeとして最低限:

- `remediated`
- `partially-remediated`
- `not-remediated`
- `unverified`
- `finding-withdrawn`
- `converted-to-suggestion`
- `not-applicable`

を区別する。

### `finding-withdrawn`

使用条件:

- original Findingの前提がEvidenceで崩れた
- baseline解釈が誤っていた
- reviewerの観測誤りが確認された

必須:

- rationale
- evidence refs
- original Findingを削除しない

**WithdrawalはQA失敗ではなく、QA自己訂正のEvidenceである。**

---

# 5. Early Final Risk Assessment

## 5.1 cycle_limitの意味

`cycle_limit` は最大自動反復回数。

最低反復回数ではない。

## 5.2 早期移行条件

Reviewerはcycle limit未到達でも、
以下を満たせば `assess-risk` へ進める。

- unresolved Critical = 0
- remaining issueが実装不能ではなくresidual riskとして評価可能
- 追加remediationのrisk reductionが限定的
- 追加remediation cost / complexity / operational burdenが不釣り合い
- Quality Intentに照らしOwner判断へ渡す方が合理的
- rationaleが記録される

## 5.3 禁止

早期Risk Assessmentを:

- 面倒だから
- testが難しいから
- AI同士で意見が割れたから

だけで使用しない。

Evidence gapはEvidence gapとして残す。

---

# 6. Final Risk Assessment contract

Humanへ渡す各残余Findingについて最低限:

- finding ID
- residual risk description
- severity / impact
- likelihood
- confidence
- implemented controls
- assumptions supporting acceptance
- alternatives
- proportionality assessment
- QA recommendation
- reassessment triggers

QA recommendation:

- `no-further-action-recommended`
- `accept-with-conditions-recommended`
- `additional-remediation-recommended`
- `defer-recommended`

等の**Recommendation**であり、
Owner decisionではない。

---

# 7. Human workload policy

通常のHuman操作は増やさない。

## Normal path

```text
review依頼
response依頼
re-review依頼
```

のみ。

## Human interrupt conditions

Humanへ追加判断を求めるのは:

- multiple active cases ambiguity
- Quality Intent不足
- baseline change
- destructive authorization
- unresolved Critical
- material risk acceptance
- cycle cap / early final risk requiring Owner
- conflicting obligations

だけ。

---

# 8. Active case resolution

Humanが毎回case IDを入力しないため:

```text
active case = 1
→ auto select

active cases > 1
→ case name/IDだけHumanに選択させる

active case = 0
→ bootstrap/create-caseへ誘導
```

新しい第3 Skillは作らない。

---

# 9. Runtime Context budget

Skill本文をQMS教科書にしない。

推奨:

- `quality-review/SKILL.md`: current程度を上限目安
- `quality-response/SKILL.md`: current程度を上限目安
- `qms-foundations.md`: 判断に迷うときのみ読む
- development plan / Feedback: runtime search pathから外す

哲学を追加する場合はCore ruleへ変換できるものを優先し、
自然言語説明の重複を避ける。
