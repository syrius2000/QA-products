# Release & Packaging Guide v1.1.0

## 1. Goal

Runtime package should contain what AI/Core need to operate,
not the full history of how the design was debated.

---

## 2. Recommended package separation

### Runtime / install-relevant

Keep:

```text
quality_loop/
schemas/
templates/
skills/
references/qms-foundations.md
README.md
FUNCTIONAL_SPEC.md
```

Add only genuinely required runtime files.

### Development / source

May keep in source repository:

```text
tests/
examples/
evals/
docs/Feedback/
completion plans/
```

But Skill should not normally load these into context.

---

## 3. Context contamination prevention

Do not leave mutually inconsistent:

- old workflow
- old status vocabulary
- old CLI examples
- obsolete Finding semantics

in files easily retrieved by agent.

Historical docs should be:

- archived outside runtime search path, or
- clearly versioned and not referenced by Skill

---

## 4. Versioning

Recommended resulting software release:

```text
quality-loop v1.1.x
```

This instruction package itself is:

```text
quality-loop-completion-plan-v1.1.0
```

If implementation changes public schema/state semantics,
update schema/version field deliberately.

Do not silently change `schema_version` without migration/compatibility decision.

---

## 5. Changelog must mention

- traffic light fix
- canonical schema alignment
- Quality Intent intake alignment
- adaptive Plan Gate
- early Final Risk Assessment
- enhanced Human risk summary
- active case resolution
- stale docs/example cleanup
- regression preservation

---

## 6. Release QA commands

At minimum:

```bash
python3 -B -m pytest -q
python3 -m compileall -q quality_loop
```

Plus project-specific schema/example validation commands.

ZIP:

```bash
unzip -t <release.zip>
shasum -a 256 <release.zip>
```

---

## 7. Packaging hygiene

Before zip:

- no `__pycache__`
- no `.pytest_cache`
- no `*.pyc`
- no temp case
- no local secrets
- no runtime logs
- no stale generated examples
- no prior plan accidentally bundled under Runtime

---

## 8. Release note should stay short

Human operator needs:

- what changed
- what breaks
- install/update instructions
- 3-command UX
- known limitations

Do not ship a long QMS essay as the default README.

---

## 9. Final release question

Before FIX:

> Does this release improve the probability of reasonable, evidence-based resolution **without increasing normal human burden or AI ritual**?

If no, do not add the feature.
