# Completion Plan Changelog v1.1.0

## From v1.0 → v1.1.0

v1.0は主に以下を追加する計画だった。

- Quality Intent
- Plan Before Fix
- QA self-correction
- Final Risk Assessment
- short UX

対象ソフトウェアはそれらの多くを実装した。

v1.1.0は、実装後の批判的評価を受けて次へ焦点を移す。

### Correctness hardening

- 未レビューGreen問題
- case schema / engine drift
- intake schema / template / engine drift
- Functional Spec stale
- example drift
- generated CLI/document consistency

### Efficiency refinement

- Medium一律Plan Gateをやめる
- cycle_limit前のearly Final Risk Assessment
- active case auto-resolution
- Human final risk summaryの情報集約

### Context / maintenance refinement

- RuntimeへFeedback/旧計画を混在させない
- stale wordingを削除
- 第3Skillを追加しない
- QMS説明をSkillへ積み増さない

---

## Philosophy unchanged

> Quality is not maximum process.

> AI-1 does not define the quality threshold.

> AI-2 does not replace the quality threshold with theoretical perfection.

> Human Quality Intent defines what “good enough” means, with applicable obligations and risk context.

> QA should enable reasonable resolution, including self-correction and proportionate risk acceptance.
