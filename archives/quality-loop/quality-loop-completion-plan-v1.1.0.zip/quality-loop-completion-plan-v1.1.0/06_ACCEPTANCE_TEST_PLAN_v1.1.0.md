# Acceptance Test Plan v1.1.0

## A. Contract Tests [P0]

### A-01 New case is not Green

**Given**
- case created
- no review performed

**Expect**
- status indicates reviewer action / unreviewed
- resume is not Green
- no wording equivalent to “verified safe”

---

### A-02 Canonical schema after every operation

For:

```text
create-case
review
submit-plan
review-plan
submit-response
verify
assess-risk
adjudicate
```

**Expect**
- saved `case.json` validates against `case.schema.json`

---

### A-03 Intake triad consistency

Test the same payload against:

1. JSON Schema
2. engine validator
3. template

**Expect**
- same required semantics
- `intended_use` required
- `risk_context` required

---

### A-04 Generated CLI contract

**Given**
- `resume.md` outputs a suggested CLI command

**Expect**
- command can be parsed/executed by current CLI
- input policy matches docs

---

### A-05 Examples are generated and valid

**Expect**
- all example case JSON schema valid
- revisions monotonic
- lifecycle states current
- evidence rebuttal uses withdrawal semantics when appropriate

---

## B. Adaptive Plan Gate

### B-01 Critical

Finding: Critical security/data integrity.

Expect:

```text
plan_required=true
submit-plan
review-plan
```

---

### B-02 High

Expect default Plan Gate.

---

### B-03 Medium simple

Example:
- isolated deterministic one-line validation fix
- reversible
- no security/data integrity impact
- one obvious remediation

Expect:

```text
plan_required=false
submit-response
```

No unnecessary plan round trip.

---

### B-04 Medium ambiguous

Example:
- two reasonable architectural options
- intended use interpretation matters

Expect Plan Gate.

---

### B-05 Low

Expect direct response by default.

---

## C. Reviewer self-correction

### C-01 Evidence rebuttal

Reviewer asserts failure based on assumption.

Implementer provides independent evidence invalidating assumption.

Expect:

```text
finding-withdrawn
```

or other explicitly justified self-correction.

Original finding remains in history.

---

### C-02 Suggestion conversion

Technically possible improvement but no material Quality Intent threat.

Expect:

```text
converted-to-suggestion
```

No forced remediation.

---

## D. Early Final Risk Assessment

### D-01 Early proportionality path

Cycle=1.

Residual Medium issue:
- controls implemented
- remaining likelihood low
- further remediation cost high
- intended use low criticality
- Critical=0

Expect:
- reviewer may route to assess-risk
- rationale stored
- Owner receives risk summary

---

### D-02 Critical blocks early exit

Residual Critical.

Expect:
- early assess-risk route rejected or not offered
- remediation/human escalation policy followed

---

### D-03 No “too hard” shortcut

Evidence unavailable.

Expect:
- `unverified` / evidence gap
- not converted to risk acceptance merely because verification is difficult

---

## E. Human Final Summary

### E-01 Summary completeness

For each residual material issue, generated human view contains:

- residual risk
- implemented controls
- assumptions
- alternatives
- proportionality
- QA recommendation
- reassessment triggers

---

### E-02 Summary compression

Human view should not require:
- event log reading
- raw CLI JSON
- every prior cycle response
- all evidence hashes

These remain accessible but not default.

---

## F. Short UX

### F-01 Single active case

User:

```text
quality-review で再点検して
```

Expect:
- one active case auto-selected
- no case ID question

---

### F-02 Multiple active cases

Expect:
- ask only which case
- do not ask revision/cycle/finding IDs manually

---

### F-03 Zero active case

Expect:
- bootstrap/create-case path
- no fabricated handoff

---

## G. Regression

Must remain green:

- Role Firewall
- same Invocation separation
- CAS
- stale handoff rejection
- stale revision rejection
- duplicate operation idempotency
- atomic write
- backup behavior
- unauthorized target change
- undeclared change
- Evidence path/hash rules
- Owner-only final decision

---

## H. Efficiency Acceptance

Dogfood two cases and record:

| Metric | Low-risk | Higher-risk |
|---|---:|---:|
| Findings | | |
| Plan Gates | | |
| AI handoffs | | |
| Human interventions | | |
| Cycles | | |
| QA withdrawals | | |
| Final risk items | | |

Acceptance is qualitative, but failure signals include:

- all Medium automatically enter Plan Gate
- Human repeatedly types identifiers
- cycle_limit behaves as mandatory iterations
- final summary still requires reading case.json
- runtime Skill context grows materially without clear quality benefit

---

## I. Release criterion

Release candidate is acceptable when:

1. P0 contract tests all pass
2. full regression passes
3. low-risk case stays lightweight
4. higher-risk case remains appropriately strict
5. Human Owner can judge final residual risk from compressed summary
