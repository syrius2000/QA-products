# Implementer Handoff Prompt v1.1.0

以下は、この改善計画と現行 `quality-loop-sola-completed-20260830_204733.zip` を別AIへ渡して実装させる場合の推奨指示。

---

```text
現行 quality-loop を基盤として、Completion Plan v1.1.0 に従って完成度を上げてください。

最重要目標は新機能追加ではなく、
1) 契約不整合をゼロにする、
2) QA品質を維持/向上しながらAI往復を減らす、
3) Human Ownerの操作・読解負担を増やさない、
4) Skill/Runtime Contextを肥大化させない、
ことです。

最初に以下を順番に読んでください。

00_README_FIRST_v1.1.0.md
01_BASELINE_AND_CRITICAL_FIXES_v1.1.0.md
02_TARGET_OPERATING_MODEL_v1.1.0.md
03_IMPLEMENTATION_INSTRUCTIONS_v1.1.0.md
05_TODO_v1.1.0.md
06_ACCEPTANCE_TEST_PLAN_v1.1.0.md

実装中は05_TODOを更新してください。

絶対に弱めないもの:
- case.json canonical state
- Owner/Reviewer/Implementer Role Firewall
- handoff/revision CAS
- atomic write
- Evidence integrity
- unauthorized / undeclared change detection
- AI-1自己クローズ禁止
- AI-2最終Risk Acceptance禁止

今回の設計上の重要変更:
- 未レビューをGreen表示しない
- Schema/template/engine/docs/examplesを完全整合
- MediumのPlan Gateはrisk/contextで選択
- cycle_limitは最低回数ではなく上限
- 条件を満たせばReviewerは早期Final Risk Assessmentへ移行可能
- Human向け最終Risk SummaryをControls/Assumptions/Alternatives/Reassessment Triggerまで含める
- active caseが1件なら短い指示から自動解決
- 第3Skillは作らない

新しい複雑性を追加したくなった場合、
Quality Risk ReductionがHuman/AI/Contextコストを上回ることを説明してください。
説明できない変更は入れないでください。

各Phase末に:
- changed files
- test commands/results
- contract impact
- human burden impact
- context impact
- remaining risks
を記録してください。

P0が全件greenになる前にP2や追加機能へ進まないでください。
```
