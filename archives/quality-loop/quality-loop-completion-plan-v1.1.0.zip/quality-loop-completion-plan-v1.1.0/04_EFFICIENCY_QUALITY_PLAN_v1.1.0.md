# Efficiency & Quality Improvement Plan v1.1.0

## 1. 成功指標

今回の改善では「機能数」をKPIにしない。

見るべきは:

### Quality

- false Green = 0
- schema/canonical drift = 0
- wrong-fixをPlan Gateで抑制
- reviewer self-correction可能
- risk acceptance reasoningの可視性

### Efficiency

- trivial FindingのAI往復増加を防止
- Mediumで不要なPlan Gateを減らす
- cycle capまで無意味に回さない
- Humanがcase ID/revision/Finding IDを手入力しない
- Humanが最終判断のため全ログを読まない

### Context

- Skill本文を現行規模から大幅増加させない
- RuntimeにFeedback/旧計画を混ぜない
- 同じQMS哲学を複数ファイルへ重複記載しない

---

# 2. Priority

## P0 — Correctness / Contract

1. traffic light
2. case schema
3. intake schema/template/runtime
4. functional spec
5. example generation
6. CLI/resume docs consistency

P0終了前にP2機能追加禁止。

## P1 — Quality × Efficiency

1. adaptive Medium Plan Gate
2. early Final Risk Assessment
3. complete Human risk summary
4. active case auto-resolution

## P2 — Cleanup

1. Runtime packaging cleanup
2. old doc removal/isolation
3. duplication reduction
4. optional developer tooling

---

# 3. Human burden budget

通常1サイクルでHumanが必要な操作数の目安:

### Simple issue

```text
review
response
re-review
```

3 handoffs程度。

### Plan-required issue

```text
review
response-plan
plan-review
response/fix
verify
```

増えるがCritical/High等に限定する。

### 最終risk

Humanは最後のsummary + decisionだけ。

## Guardrail

Mediumが多い案件で全件Plan Gateとなり、
人間がAI切替を大量に行う状態はFailureとみなす。

---

# 4. AI round-trip budget

### Low

1 remediation loopを目標。

### Medium simple

1 remediation loopを目標。

### Medium complex / High / Critical

Plan reviewを許容。

### Residual risk

「あと1回直せるから」という理由で追加cycleしない。

---

# 5. Quality vs perfection guard

ReviewerはFinding作成時に問う:

```text
Does this materially threaten Quality Intent?
```

回答できないものは:

- improvement-proposal
- suggestion
- no-action

候補。

同時に、安易なrisk acceptanceを防ぐため:

```text
Is there an applicable obligation / unacceptable failure / serious integrity impact?
```

も確認する。

---

# 6. What NOT to add in v1.1.0

- 第3 Skill
- 5段階以上のrisk score matrix
- weighted finding score
- AI reviewer performance score
- mandatory Human approval at every phase
- CAPA system
- training records
- supplier QA
- audit schedule
- CI/CD mandatory integration
- verbose chain-of-thought style logs
- duplicated Quality Intent documents

---

# 7. Decision rule for additional complexity

追加complexityは次式の考え方で判断する。

```text
Net Value =
  Quality Risk Reduction
+ Human Decision Clarity
- AI Round Trips
- Human Operations
- Runtime Context
- Maintenance Burden
```

厳密な数値化はしない。

しかし、追加案を採用する前にこの6項目を文章で評価する。

---

# 8. Release recommendation

v1.1.0 completion packageの実装後、
まず2種類だけdogfoodする。

### Low-risk

家庭内/個人用の小規模システム。

目的:
- over-QAしないか
- Plan Gateが重くないか

### Higher-risk

data integrity/security/regulated-likeな要素を含む案件。

目的:
- 必要なときに厳格さが維持されるか

両方で同じSkillが比例的に振る舞えば成功。
