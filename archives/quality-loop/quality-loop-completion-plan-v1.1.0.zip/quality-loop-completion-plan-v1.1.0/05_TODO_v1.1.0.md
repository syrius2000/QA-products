# TODO — Quality Loop Completion v1.1.0

> 実装担当はこのファイルを進捗正本として使用する。  
> 各Phase終了時に **変更 / test / 残存risk / 人負担への影響** を記録する。

---

# Phase 0 — Freeze

- [ ] source package SHA-256を記録
- [ ] current file inventory保存
- [ ] current full test実行
- [ ] `78 passed` baseline確認
- [ ] core/schema/skills hash保存
- [ ] current generated example inventory保存

### Checkpoint

- [ ] 元状態へ戻せる

### Log

```text
Date:
Agent:
Commands:
Result:
Notes:
```

---

# Phase 1 — P0 Contract Repair

## Traffic light

- [ ] create-case直後をGreenにしない
- [ ] review未実施状態を明示
- [ ] in-progress状態を明示
- [ ] terminal/risk状態の表示規則定義
- [ ] regression test追加

## Case schema

- [ ] canonical top-level keys棚卸し
- [ ] `plans` schema追加
- [ ] `plan_reviews` schema追加
- [ ] `final_risk_assessments` schema追加
- [ ] その他engine生成fieldを照合
- [ ] every-operation schema validation test追加

## Intake / Quality Intent

- [ ] required Quality Intentを正式確定
- [ ] intake schema更新
- [ ] intake template更新
- [ ] engine validation同期
- [ ] missing intended_use reject
- [ ] missing risk_context reject
- [ ] template schema validation test追加

## Docs / CLI

- [ ] FUNCTIONAL_SPEC現行化
- [ ] 9 operations確認
- [ ] current state machine反映
- [ ] CLI input policy統一
- [ ] resume生成commandをCLI test
- [ ] README例を実CLIと照合

## Examples

- [ ] examples自動生成helper/test
- [ ] standard direct-fix
- [ ] Plan Gate
- [ ] evidence rebuttal → withdrawn
- [ ] early risk
- [ ] accepted-with-risk
- [ ] regression
- [ ] 全example schema valid

### P0 Checkpoint

- [ ] canonical/schema/template/docs/example drift = 0
- [ ] full tests green

### Log

```text
Changes:
Tests:
Remaining:
Human burden impact:
Context impact:
```

---

# Phase 2 — Adaptive Plan Gate

- [ ] Critical default plan required
- [ ] High default plan required
- [ ] Low default direct response
- [ ] Medium decision criteria実装
- [ ] `plan_gate_reason`等を記録
- [ ] Medium simple E2E
- [ ] Medium ambiguous E2E
- [ ] Medium destructive E2E
- [ ] HumanへPlan要否を毎回質問しない
- [ ] quality-review Skill文面を最小限修正
- [ ] quality-response Skill文面を最小限修正

### Checkpoint

- [ ] simple Mediumが余計な2往復を発生させない
- [ ] risky MediumではPlan Gateが働く

### Log

```text
Rule chosen:
Why:
Tests:
Round-trip comparison:
```

---

# Phase 3 — Early Final Risk Assessment

- [ ] cycle_limit = maximumであることを仕様化
- [ ] reviewer early assess-risk path追加
- [ ] unresolved Critical guard
- [ ] rationale required
- [ ] proportionality condition
- [ ] cycle 1 early-risk E2E
- [ ] early-risk misuse negative test
- [ ] Owner roleへ正しくhandoff

### Checkpoint

- [ ] 無意味なcycleを回さずHuman Risk Decisionへ進める
- [ ] 重大問題の逃げ道になっていない

---

# Phase 4 — Human Risk Summary

- [ ] Controls表示
- [ ] Assumptions表示
- [ ] Alternatives表示
- [ ] Proportionality表示
- [ ] QA Recommendation表示
- [ ] Reassessment Trigger表示
- [ ] raw eventsをdefault表示しない
- [ ] case.jsonを開かずOwner判断できるか確認

### Checkpoint

- [ ] Human summary単体でdecision材料が揃う

---

# Phase 5 — Short UX / Active Case

- [ ] active case discovery
- [ ] active=1 auto-select
- [ ] active>1 caseだけ問い合わせ
- [ ] active=0 bootstrap案内
- [ ] case ID手入力不要
- [ ] revision手入力不要
- [ ] cycle手入力不要
- [ ] Finding ID列挙不要
- [ ] third Skillを追加していない

### Checkpoint

以下の会話で通常フロー可能:

```text
quality-review で XX計画書の実装をQAレビューして
quality-response でhandoffを確認して対応して
quality-review で再点検して
```

---

# Phase 6 — Context / Runtime Cleanup

- [ ] `docs/Feedback` をRuntime参照対象外へ
- [ ] obsolete plan/docのRuntime link除去
- [ ] qms-foundations重複整理
- [ ] old example wording除去
- [ ] Skill本文行数比較
- [ ] Skill本文が大幅増加していない
- [ ] Runtime file setを記録

### Checkpoint

- [ ] QMS哲学を保ちつつPrompt Contextが肥大化していない

---

# Phase 7 — Acceptance

## Automated

- [ ] `pytest -q`
- [ ] Python compile
- [ ] schema all templates
- [ ] schema every operation output
- [ ] example regeneration
- [ ] generated CLI command execution
- [ ] Role Firewall regression
- [ ] stale handoff/revision regression
- [ ] duplicate operation regression
- [ ] atomic write regression
- [ ] unauthorized change regression
- [ ] undeclared change regression
- [ ] adaptive plan gate E2E
- [ ] finding withdrawal E2E
- [ ] early final risk E2E
- [ ] final risk summary E2E
- [ ] short UX routing eval

## Dogfood

- [ ] low-risk case
- [ ] higher-risk case
- [ ] separate AI-1 / AI-2
- [ ] unnecessary Plan Gate count記録
- [ ] total AI round trips記録
- [ ] Human interventions記録
- [ ] withdrawn QA Findingの挙動確認
- [ ] Ownerがsummaryだけで判断可能か確認

---

# Phase 8 — Release

- [ ] version更新
- [ ] CHANGELOG
- [ ] FUNCTIONAL_SPEC final
- [ ] README final
- [ ] stale docs 0
- [ ] `__pycache__` 0
- [ ] `.pytest_cache` 0
- [ ] `*.pyc` 0
- [ ] ZIP integrity
- [ ] SHA-256
- [ ] source/development materialとruntime materialの境界確認

---

# FINAL CHECKPOINT

- [ ] false Green 0
- [ ] Schema drift 0
- [ ] unnecessary Medium Plan loops減少
- [ ] cycle 3までの強制反復なし
- [ ] Human full-log review不要
- [ ] Human normal operations増加なし
- [ ] Skill Context大幅増加なし
- [ ] Role Firewall/CAS/Evidence integrity維持
- [ ] Quality Intentに対して合理的に十分

> **Done means fit for intended use, not maximum process.**
