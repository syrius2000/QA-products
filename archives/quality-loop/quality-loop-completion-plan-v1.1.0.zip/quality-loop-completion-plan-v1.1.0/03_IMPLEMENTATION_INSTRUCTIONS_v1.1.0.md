# Implementation Instructions v1.1.0

## 0. 実装戦略

今回の改修は **repair → simplify → validate** の順で行う。

大規模refactorは禁止しないが、P0解決に不要なら行わない。

---

# Phase 1 — Contract Repair [P0]

## 1.1 Traffic light修正

対象候補:

```text
quality_loop/markdown_report.py
tests/test_markdown_report.py
tests/test_acceptance*.py
```

### 実装要求

traffic light判定へQA lifecycle状態を入力する。

少なくとも:

```text
not-reviewed
in-review
verified
human-decision-required
terminal
```

を区別できること。

Finding件数が0であることだけをGreen条件にしない。

### Test

- create-case immediately: not Green
- after initial review with no findings: verified/appropriate Green only if review actually completed
- unresolved finding: Red/Yellow
- evidence-gap only: Yellow
- accepted-with-risk: terminal risk label, not deceptive “safe”

---

## 1.2 Canonical schema repair

対象:

```text
schemas/case.schema.json
quality_loop/engine.py
quality_loop/model.py
tests/test_schemas.py
```

### 必須properties

現行engineがcanonical caseへ保存する全top-level fieldをSchemaへ定義する。

例:

- plans
- plan_reviews
- final_risk_assessments

実際のengine modelをsource of truthとして一度棚卸しする。

### Contract test

各operation後にcase schema validation。

---

## 1.3 Intake contract alignment

対象:

```text
schemas/intake.schema.json
templates/intake.json
quality_loop/engine.py
tests/test_schemas.py
tests/test_quality_loop.py
```

### Required minimum

- purpose
- intended_use
- risk_context
- requirements
- acceptance_criteria
- targets
- target_revision

### Implementation

Schema / template / runtime validatorのrequired listを共通化する。
可能なら定数またはsingle validation helperでdriftを減らす。

---

## 1.4 Functional Spec refresh

現行状態機械と操作一覧へ全面更新。

必ず反映:

- submit-plan
- review-plan
- assess-risk
- QA self-correction
- adaptive Plan Gate
- Final Risk Assessment
- Quality Intent
- current CLI contract

古い仕様説明を同じページに残さない。

---

## 1.5 Example regeneration

手書きexample更新ではなく、
engine/CLIからcanonical exampleを生成するtest/helperを作る。

必須example:

1. standard direct-fix cycle
2. Plan Gate cycle
3. evidence rebuttal → finding-withdrawn
4. early Final Risk Assessment
5. accepted-with-risk
6. regression/undeclared change

---

# Phase 2 — Adaptive Plan Gate [P1]

## 2.1 データモデル

Findingへ次を持たせる方法を検討:

```json
{
  "plan_required": true,
  "plan_gate_reason": [
    "security-impact",
    "multiple-remediation-options"
  ]
}
```

reasonはmachine-readable enum + optional rationaleが望ましい。

## 2.2 Reviewer logic

Critical/High default true。

Low default false。

MediumはReviewerがQuality Intentとrisk/contextから判定。

### Anti-pattern

```text
severity == medium therefore plan_required = true
```

だけにしない。

## 2.3 Implementer Skill

`next_action=submit-plan` のときだけPlanを提出。

`next_action=submit-response` なら不要なPlan文書を生成しない。

HumanへPlan Gate判定を毎回聞かない。

---

# Phase 3 — Early Final Risk Assessment [P1]

## 3.1 State transition

Reviewer VerificationのOutcomeから、
cycle limit未到達でも `assess-risk` をnext_actionにできる明示seamを追加。

例:

```json
{
  "next_step_recommendation": "assess-risk",
  "reason": "further-remediation-disproportionate"
}
```

命名は現行modelに合わせてよい。

## 3.2 Guard

- unresolved Criticalがある場合は原則不可
- rationale必須
- residual findingが存在する
- Owner decisionへ渡す情報が生成可能

## 3.3 Test

cycle 1で:

```text
Medium residual
risk low/contained
additional fix burden high
→ reviewer assess-risk
```

が可能。

---

# Phase 4 — Human Risk Summary [P1]

対象:

```text
quality_loop/markdown_report.py
assess-risk schema/model
tests/test_markdown_report.py
```

## 表示すべき項目

Human向け文書ではcase.jsonを読まなくてもよいようにする。

各residual finding:

```text
Issue
Residual Risk
Controls
Assumptions
Alternative
Proportionality
QA Recommendation
Reassessment Trigger
```

## 表示しないもの

通常Human viewへ:

- 全CLI payload
- 全events
- 全Evidence hash
- 全iteration transcript

を出さない。

必要時に参照可能であればよい。

---

# Phase 5 — Active Case UX [P1]

## 5.1 Goal

短い自然言語:

```text
quality-review で再点検して
```

で対象を復元できる。

## 5.2 Resolution

- 1 active case → auto
- >1 → case selectorのみ
- 0 → bootstrap instruction

## 5.3 禁止

新しいOrchestrator Skillを作らない。
現在の2 Skillまたはcore helperの範囲で実現する。

---

# Phase 6 — Context / Packaging cleanup [P2]

Runtime利用に不要な:

```text
docs/Feedback/
old implementation plans
stale examples
development-only commentary
```

を `.agent/skills/` の通常Contextから隔離する。

削除できない場合は少なくともSkillから参照しない。

---

# Phase 7 — Regression & Release

必須:

```text
pytest -q
schema contract E2E
example regeneration
CLI/resume command contract
Role Firewall
CAS
atomic write
change authorization
Plan Gate
finding withdrawal
early final risk
human summary
```

P0/P1以外のrefactorをした場合は、その必要性をTODO logへ記載する。

---

# 変更時の判断ルール

新しい機能を追加したくなった場合:

1. 現在のQuality Problemは何か
2. Core/state machineで解けるか
3. 人間操作が増えるか
4. AI round tripが増えるか
5. Runtime contextが増えるか
6. Evidence/Role securityを実際に上げるか

3〜5だけ増え、6が増えないなら原則追加しない。
