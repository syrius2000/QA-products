from __future__ import annotations

import hashlib
import os
import subprocess
from copy import deepcopy
from pathlib import Path
from typing import Dict, List, Set, Tuple

from .errors import QualityLoopError


def compute_file_manifest(scope_paths: list[str]) -> dict[str, str]:
    manifest: dict[str, str] = {}
    for path_str in sorted(set(scope_paths)):
        path = Path(path_str)
        if path.is_file():
            try:
                manifest[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
            except OSError:
                manifest[str(path)] = "unreadable"
    return manifest


def detect_manifest_changes(
    before_manifest: dict[str, str],
    after_manifest: dict[str, str],
) -> tuple[list[str], list[str], list[str]]:
    before_keys = set(before_manifest.keys())
    after_keys = set(after_manifest.keys())

    added = sorted(after_keys - before_keys)
    removed = sorted(before_keys - after_keys)
    common = before_keys & after_keys

    changed = sorted([k for k in common if before_manifest[k] != after_manifest[k]])
    return changed, added, removed


def observe_git_changes(
    repo_root: Path,
    base_ref: str | None = None,
) -> tuple[list[str], list[str], list[str]]:
    """Gitリポジトリの変更を自動観測する。
    Returns: (modified_or_staged, untracked, deleted)
    """
    root = Path(repo_root).resolve()
    if not (root / ".git").exists():
        raise QualityLoopError(
            "git-not-available",
            f"ディレクトリ {root} はGitリポジトリではありません。",
            remediation="有限ファイルリスト（finite-manifest）観測方式を使用してください。",
        )

    try:
        if base_ref:
            # Diff against base_ref
            res = subprocess.run(
                ["git", "diff", "--name-only", base_ref],
                cwd=str(root),
                capture_output=True,
                text=True,
                check=False,
            )
            if res.returncode != 0:
                raise QualityLoopError(
                    "git-diff-failed",
                    f"git diff {base_ref} の実行に失敗しました: {res.stderr.strip()}",
                )
            changed = [line.strip() for line in res.stdout.splitlines() if line.strip()]
            return sorted(set(changed)), [], []

        # Observe working tree & staged status via porcelain
        res = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(root),
            capture_output=True,
            text=True,
            check=False,
        )
        if res.returncode != 0:
            raise QualityLoopError(
                "git-status-failed",
                f"git status の実行に失敗しました: {res.stderr.strip()}",
            )

        modified: list[str] = []
        untracked: list[str] = []
        deleted: list[str] = []

        for line in res.stdout.splitlines():
            if not line or len(line) < 4:
                continue
            code = line[:2]
            file_path = line[3:].strip()
            if " -> " in file_path:
                file_path = file_path.split(" -> ")[1].strip()

            if "??" in code:
                untracked.append(file_path)
            elif "D" in code:
                deleted.append(file_path)
            else:
                modified.append(file_path)

        return sorted(set(modified)), sorted(set(untracked)), sorted(set(deleted))
    except (OSError, subprocess.SubprocessError) as exc:
        raise QualityLoopError(
            "git-execution-error",
            f"Gitコマンドの実行中にエラーが発生しました: {exc}",
            exit_code=4,
        ) from exc


def validate_change_observation(
    observation: dict | None,
    declared_changed_targets: set[str],
    allowed_targets: set[str],
    available_evidence_ids: set[str],
) -> dict:
    if observation is None:
        if declared_changed_targets:
            raise QualityLoopError(
                "change-observation-required",
                "変更提出のverifyには独立change_observationが必要です。",
                remediation="Reviewerは独立した変更観測結果を登録してください。",
            )
        return {}

    if not isinstance(observation, dict):
        raise QualityLoopError("invalid-change-observation", "change_observationはobjectで指定してください。")

    required = (
        "method",
        "scope",
        "before_evidence_id",
        "after_evidence_id",
        "observed_changed_targets",
        "limitations",
    )
    missing = [field for field in required if field not in observation]
    if missing:
        raise QualityLoopError(
            "invalid-change-observation",
            f"change_observation必須項目が不足しています: {', '.join(missing)}",
        )

    obs_refs = {observation["before_evidence_id"], observation["after_evidence_id"]}
    if not obs_refs.issubset(available_evidence_ids):
        missing_ev = sorted(obs_refs - available_evidence_ids)
        raise QualityLoopError(
            "unknown-evidence-id",
            f"変更観測のEvidenceを確認できません: {', '.join(missing_ev)}",
        )

    observed = set(observation.get("observed_changed_targets", []))

    # 1. Check for undeclared changes
    undeclared = sorted(observed - declared_changed_targets)
    if undeclared:
        raise QualityLoopError(
            "undeclared-change-detected",
            f"申告外変更を検出しました: {', '.join(undeclared)}",
            remediation="申告外変更を戻すか、Implementer提出を訂正してください。",
        )

    # 2. Check for unauthorized changes
    unauthorized = sorted(observed - allowed_targets)
    if unauthorized:
        raise QualityLoopError(
            "unauthorized-change-detected",
            f"許可外変更を検出しました: {', '.join(unauthorized)}",
            remediation="許可されていないファイルの変更を戻してください。",
        )

    # 3. Check for unobserved declared changes
    unobserved = sorted(declared_changed_targets - observed)
    if unobserved:
        raise QualityLoopError(
            "change-observation-incomplete",
            f"申告された変更を観測できません: {', '.join(unobserved)}",
            remediation="観測範囲を補完するかunverifiedとして再提出してください。",
        )

    return deepcopy(observation)
