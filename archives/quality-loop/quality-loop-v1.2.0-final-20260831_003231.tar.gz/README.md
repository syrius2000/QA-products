# Quality Loop

人間Owner、Reviewer、Implementerが、FindingとEvidenceを使って改善を前進させる最小QMS協働ループです。

## 公開操作

1. `create-case` (Owner): 案件初期化とQuality Intent設定
2. `review` (Reviewer): 初回QAレビュー・Proportionality評価
3. `submit-plan` (Implementer): Response Planの提出 (Plan Before Fix)
4. `review-plan` (Reviewer): Response Planの評価・合意・自己訂正
5. `submit-response` (Implementer): 許可範囲内での修正提出・Evidence添付
6. `verify` (Reviewer): 独立検証・申告外変更の検出
7. `assess-risk` (Reviewer): 最終リスク評価 (Final Risk Assessment)
8. `adjudicate` (Owner): 最終裁定 (Go/No-Go/条件付き受入)
9. `status` (All): 決定論的信号機要約 (`resume.md`)・最新Handoffの取得

詳細な契約は[機能仕様](FUNCTIONAL_SPEC.md)を参照してください。

## 開発時の実行

```bash
cd quality-loop
python3 -B -m unittest discover -s tests -v
python3 -B -m quality_loop.cli --help
```

Python標準ライブラリだけを使用します。外部ライブラリへの依存はありません。

## AI Skill

- `skills/quality-review/`: 初回レビュー、Plan合意、独立検証、最終リスク評価
- `skills/quality-response/`: Response Plan提出、修正提出とEvidence添付

どちらも最初に`status`を確認し、CLIが返した次Roleとhandoffを次工程へ渡します。Skillは案件正本`case.json`を直接編集しません。
