# Acceptance Test Plan — Quality Loop Completion

目的: 新機能が「ある」ことではなく、これまで議論したQMS挙動がE2Eで成立することを確認する。

---

# A. Contract / Regression Tests

## AT-001 Classification schema sync

**Given** Python modelに許可classificationがある  
**When** schema enumと比較する  
**Then** 完全一致する

必須例: `purpose-risk`

---

## AT-002 cycle_limit persistence

- input 1 -> case 1
- input 3 -> case 3
- input 5 -> case 5
- omitted -> 3
- 0 -> reject

---

## AT-003 Generated CLI command is executable

`resume.md` / final risk summaryに表示された全command例をtemporary case上で実行し、argparse mismatchがない。

---

## AT-004 Handoff identity

全handoffで:

- case_id non-null
- revision一致
- next_role/state一致

---

## AT-005 Atomic write fault injection

writerへ意図的faultを注入し:

- operation failure
- previous canonical revision unchanged
- no success event
- no stale handoff emission

---

# B. Quality Intent / Proportionality Tests

## AT-101 Same technical issue, different intended use

### Case A: home IoT

- closed home LAN
- single owner
- non-safety-critical

### Case B: regulated/high impact processing

同じcredential/availability issueをReviewする。

**Expected:** Reviewerは同じ技術的完全性を機械的に要求せず、Quality Intent/Risk ContextへSeverity/Recommendationを追跡する。

ただしapplicable obligationを無視してはならない。

---

## AT-102 Improvement proposal is non-blocking

要求外のより良い設計案を発見。

Expected:

- `improvement-proposal`
- Implementer強制対応なし
- acceptance blockingなし

---

# C. Plan Before Fix Tests

## AT-201 Medium Finding cannot be fixed before plan review

1. Reviewer issues Medium Finding
2. Handoff -> Implementer Plan
3. Implementerが直接target変更 + fix submitを試す

Expected:

- reject
- canonical unchanged
- remediation: submit plan first

---

## AT-202 Plan clarification avoids wrong fix

Finding:

> CSV schema mismatch

Implementer plan:

- header mismatch detected
- rotate existing file
- do not delete old file
- migration handled separately

Reviewer:

- plan accepted with comment

Expected:

- implementation only after acceptance
- approved plan ref linked

---

# D. QA Self-Correction Tests

## AT-301 Reviewer finding withdrawn after evidence rebuttal

1. Reviewer: requirement violation Finding
2. Implementer: disagreed-with-evidence
3. Evidence proves reviewer assumption false
4. Reviewer re-evaluates

Expected:

- result `finding-withdrawn`
- no code fix required
- original Finding retained in audit trail
- withdrawal rationale + evidence recorded
- withdrawal counted as resolved, but not as remediated

---

## AT-302 Converted to suggestion

Reviewer initially formal Finding, but Quality Intent shows risk is negligible and no requirement is violated.

Expected:

- `converted-to-suggestion`
- non-blocking
- reason references Quality Intent

---

# E. Final Risk Assessment Tests

## AT-401 Cycle limit is not quality judgment

cycle_limit=3.

At third verification unresolved High remains.

Expected:

- NOT auto-accepted
- NOT auto-rejected solely because 3 cycles
- next role reviewer
- next action final risk assessment

---

## AT-402 Risk acceptance basis

Residual issue:

QNAP sudo credential handling under closed home LAN.

Reviewer final assessment must contain:

- controls implemented
- remaining limitation
- assumptions
- likelihood
- impact
- alternatives
- proportionality
- recommendation
- confidence
- reassessment triggers

Expected recommendation may be `accept-with-conditions`, but terminal acceptance remains Owner-only.

---

## AT-403 Assumption invalidation

Owner accepted risk under:

- closed LAN
- manual deploy
- single admin

Later baseline changes to CI/CD/public remote access.

Expected:

- reassessment trigger fires or case becomes `requires-rereview`
- previous risk acceptance not silently reused

---

# F. Human UX Tests

## AT-501 First review from simple prompt

Human:

```text
quality-review で modern-iot-data-pipeline計画書の実装をQAレビューして
```

Expected:

- correct target/case discovered or bootstrapped
- if one valid candidate, no unnecessary question
- Reviewer flow starts
- result summary + next short instruction

---

## AT-502 Response from simple prompt

Human:

```text
quality-response でhandoffを確認して対応して
```

If next action is plan:

- response plan only
- no modification

If next action is implementation:

- authorized implementation submission

Human does not specify Finding IDs/cycle/revision manually.

---

## AT-503 Recheck from simple prompt

Human:

```text
quality-review で再点検して
```

Expected routing based on handoff:

- plan review OR
- implementation verification OR
- final risk assessment

No need for Human to name internal operation.

---

## AT-504 Multiple active cases

Two eligible cases exist.

Expected:

- do not guess
- ask Human to select case only
- do not request role/cycle/finding details unnecessarily

---

# G. Role/Safety Regression Tests

## AT-601 Implementer cannot self-close

unchanged from current safety contract.

## AT-602 Reviewer cannot owner-accept

Final Risk Assessment recommendation cannot mutate terminal decision.

## AT-603 Reviewer verification independent invocation

same invocation as submit-response -> reject.

## AT-604 Unauthorized target change

Plan accepted but target not Owner-authorized -> reject.

## AT-605 Undeclared change

Independent observation finds undeclared file -> reject/no silent acceptance.

## AT-606 stale handoff/revision

old handoff or expected revision -> canonical unchanged.

---

# H. Packaging Acceptance

## AT-701 Full test suite

All tests pass in:

- normal user environment
- CI-like environment

No test depends on root/non-root permission semantics unless explicitly platform-gated.

## AT-702 Examples

Examples regenerated by script and validated against current schemas.

## AT-703 Documentation

README/Skill/resume command examples match actual CLI.

## AT-704 Clean package

No:

- `__pycache__`
- `.pytest_cache`
- `*.pyc`
- stale tmp files

ZIP integrity passes.

---

# Final Human Acceptance Scenario

最終dogfoodでHumanが実際に以下だけ入力する。

```text
1. quality-review でXX計画書の実装をQAレビューして
2. quality-response でhandoffを確認して対応して
3. quality-review で再点検して
```

必要に応じ2と3を繰返す。

最終的にHumanへ表示されるものは、長大なQA会話ではなく:

```text
Resolved: n
Residual: n
Critical: n
High: n
QA recommendation: ...
Human decision required: ...
```

と、残余FindingごとのRisk Acceptance Basisである。

これをHumanが合理的な時間で判断できれば、Human-centered Quality Loopとして受入候補となる。
