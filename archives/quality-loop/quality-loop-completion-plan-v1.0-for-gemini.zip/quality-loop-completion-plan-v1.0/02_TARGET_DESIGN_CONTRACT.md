# Target Design Contract — 完成版Quality Loop

この文書は、実装中に「どの方向へ変更してよいか」を固定する上位契約である。

---

# 1. Role Contract

## 1.1 Human Owner

Ownerだけが次を所有する。

- Quality Intentの最終承認
- baseline変更
- implementation authorization
- additional cycle authorization
- final residual risk acceptance
- terminal adjudication

Ownerは全技術詳細を読む必要はないが、最終裁定責任はAIへ委譲しない。

## 1.2 Implementer / AI-1

Implementerは、

- Findingを理解する
- Response Planを作る
- Evidence付き反証を行う
- 承認済みPlanと許可範囲内で修正する
- Evidenceを提出する

ことができる。

Implementerは、

- Finding severityを変更しない
- Reviewer resultを変更しない
- baselineを変更しない
- Risk Acceptanceを確定しない
- Finding/caseを自己クローズしない

## 1.3 Reviewer / AI-2

Reviewerは、

- baseline / Quality Intentに照らした独立Review
- Response Planの妥当性確認
- EvidenceによるFinding再評価
- Implementation effectiveness verification
- proportionality check
- Final Risk Assessment

を行う。

Reviewerは、

- Quality Requirementを勝手に増やさない
- 技術的完全性を要求しない
- OwnerのRisk Acceptanceを代行しない
- 自分のFindingに固執しない

---

# 2. Quality Intent Contract

既存baselineを壊さず、以下へ拡張することを推奨する。

```json
{
  "baseline": {
    "purpose": "...",
    "intended_use": {
      "users": "...",
      "environment": "...",
      "operational_context": "..."
    },
    "risk_context": {
      "criticality": "low|medium|high|regulated",
      "safety_impact": "...",
      "data_integrity_impact": "...",
      "security_context": "..."
    },
    "requirements": [],
    "acceptance_criteria": [],
    "constraints": [],
    "applicable_obligations": [],
    "unacceptable_failures": [],
    "exclusions": [],
    "targets": [],
    "target_revision": "..."
  }
}
```

### MUST

- `purpose`
- `intended_use`
- `risk_context`
- `requirements`
- `acceptance_criteria`
- `targets`
- `target_revision`

### SHOULD / optional

- `constraints`
- `applicable_obligations`
- `unacceptable_failures`
- `exclusions`

移行時にlegacy caseを壊さない必要がある場合、schema versionを上げ、read compatibilityを明示する。

---

# 3. Finding Contract

Findingは最低限以下を持つ。

```text
finding_id
classification
severity
requirement_ref
observed_fact
impact
expected_state
verification_method
evidence_refs
status
plan_required
```

### Finding classification

最低限:

- `requirement-violation`
- `purpose-risk`
- `evidence-gap`
- `regression`
- `unverified-claim`
- `improvement-proposal`

### `improvement-proposal`

- blocking Findingではない
- Implementer対応を強制しない
- terminal acceptanceを妨げない

### Proportionality Gate

Formal Finding化するReviewerは、少なくとも内部的に次を評価する。

- 何のQuality Requirement / Purpose / Riskを脅かすか
- 実運用条件で現実的なリスクか
- remediation burdenとrisk reductionが釣り合うか
- Suggestionで十分ではないか

---

# 4. Response Plan Contract

## 4.1 Plan required rule

原則:

- Critical: required
- High: required
- Medium: required
- Low: direct response allowed
- improvement-proposal: no mandatory response

ただしOwner Policyで変更可能にしてよい。

## 4.2 Response Plan fields

```json
{
  "finding_id": "F-001",
  "understanding": "QA指摘をImplementer自身の言葉で再述",
  "disposition_intent": "fix|disagree-with-evidence|cannot-verify|baseline-change-request",
  "proposed_actions": [],
  "not_planned": [],
  "questions": [],
  "evidence_refs": [],
  "implementation_status": "not-started"
}
```

### MUST

Response Planの提出時点では対象実装を変更しない。

例外は、Low direct responseまたはOwnerが明示した緊急修正Policyのみ。

---

# 5. Plan Review Contract

ReviewerはResponse Planへ、以下のいずれかを返す。

- `plan-accepted`
- `plan-accepted-with-comments`
- `plan-revision-required`
- `finding-withdrawn`
- `converted-to-suggestion`
- `not-applicable`
- `owner-decision-required`

### QA can be wrong rule

Implementerの反証EvidenceがFindingの前提を崩した場合、Reviewerは `finding-withdrawn` を選べるだけでなく、**選ぶ義務がある**。

Finding撤回後に、同じ内容を別表現で再発行してはいけない。新Evidenceがある場合のみ再Finding可能。

---

# 6. Implementation Response Contract

Plan accepted後、Implementerは初めて変更可能。

提出には、

- finding_id
- disposition
- approved_plan_ref
- changed_targets
- evidence_refs
- result_revision
- remaining_risk

を含める。

`fix-submitted` は修正提出であって、解決・受入・closureではない。

---

# 7. Reviewer Verification Outcome

曖昧な `verified` 一語だけに依存しない。

推奨Outcome:

- `remediated`
- `partially-remediated`
- `not-remediated`
- `unverified`
- `finding-withdrawn`
- `converted-to-suggestion`
- `not-applicable`

Finding lifecycle statusとverification resultは必要なら分離する。

### 重要

- `remediated`: Findingが正しく、修正の有効性が確認された
- `finding-withdrawn`: Finding前提が誤り/不成立だった

この2つを同じ「緑」にしてもよいが、意味は必ず区別する。

---

# 8. Final Risk Assessment Contract

Owner adjudicationへ進む前に、ReviewerがFinal Risk Assessmentを生成する。

発火条件:

- cycle limit到達
- unresolved residual findingがある
- owner risk decisionが必要
- all remediation verifiedで最終Owner acceptanceへ渡す場合（簡易版可）

残余Findingごとに最低限:

```yaml
residual_risk:
  finding_id: F-001
  current_status: partially-remediated
  implemented_controls: []
  residual_risk_description: "..."
  assumptions_supporting_acceptance: []
  likelihood: low|medium|high|unknown
  impact: low|medium|high|critical
  alternatives: []
  proportionality_assessment: "..."
  qa_recommendation: accept|accept-with-conditions|require-remediation|defer
  confidence: high|medium|low|unknown
  reassessment_triggers: []
```

Reviewerはrecommendationを出すが、`accepted`を確定しない。

---

# 9. Target State Machine

推奨状態機械:

```text
reviewer-action
  -> implementer-plan | implementer-action(low direct) | owner-adjudication

implementer-plan
  -> reviewer-plan-review

reviewer-plan-review
  -> implementer-plan              (plan revision)
  -> implementer-action            (plan accepted)
  -> owner-adjudication            (baseline/risk decision)
  -> reviewer-action/continue      (finding withdrawn only etc.)

implementer-action
  -> reviewer-verification

reviewer-verification
  -> implementer-plan              (next remediation cycle)
  -> reviewer-final-assessment     (all resolved or cycle cap/residual risk)

reviewer-final-assessment
  -> owner-adjudication

owner-adjudication
  -> implementer-plan / implementer-action
  -> held
  -> accepted
  -> accepted-with-risk
  -> rejected
```

操作名は実装上変更可能だが、**Role separationとsemantic phaseは失ってはならない**。

---

# 10. Cycle Semantics

Cycle上限は品質合格基準ではない。

> **cycle limit = 自動AI修正ループを打ち切りHuman判断へ圧縮する安全弁**

3回だからacceptする、3回だからfailする、ではない。

`cycle_limit` はOwner inputを保存し、default=3とする。

---

# 11. Handoff Contract

handoffは派生ビューだがAI間の正式なバトンである。

最低限:

```yaml
handoff_id:
case_id:
case_revision:
next_role:
next_action:
purpose:
open_items:
inputs:
expected_outputs:
issued_at:
```

### MUST

- `case_id` 非null
- current case revisionと一致
- stale handoff拒否
- next_role / next_actionがstate machineと一致
- 更新とhandoff発行を原子的に行う

---

# 12. Natural-language UX Contract

Humanは原則、内部operation名を覚えない。

### 初回

```text
quality-review で XX計画書の実装をQAレビューして
```

Skill frontendは、

- Case候補探索
- 明示対象からbaseline source抽出
- Quality Intent不足の検出
- 必要なCase bootstrap
- current stateに応じたReviewer operation

を行う。

### Response

```text
quality-response で handoffを確認して対応して
```

Skillはhandoffから、

- Response Plan phaseか
- Implementation phaseか

を自動判別する。

### 再点検

```text
quality-review で再点検して
```

Skillはhandoffから、

- Plan Review
- Implementation Verification
- Final Risk Assessment

のどれかを自動判別する。

### Ambiguity rule

- 対象Case 1件: 自動選択
- 複数Case: 人へCase選択だけ求める
- Quality Intent復元不能: 勝手に作らず不足を提示
- destructive operation: Owner authorization必須

---

# 13. Invariants to Preserve

改修後も以下は絶対に弱めない。

1. `case.json` canonical state
2. AI Skillはcase.jsonを直接編集しない
3. CAS / expected revision
4. handoff validation
5. operation idempotency
6. Role Firewall
7. Reviewer verificationはImplementer submitと別Invocation
8. unauthorized / undeclared change rejection
9. Evidence target revision integrity
10. atomic persistence and failure safety
11. terminal adjudication Owner confirm gate
12. standard library only runtime（現方針を変える明確な理由がなければ）
