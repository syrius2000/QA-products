# TODO — Quality Loop Completion Checklist

> 実装担当は作業中にこのファイルへチェックを入れる。  
> 各Phase末尾に、実行したtest command・結果・未解決事項を追記する。

---

# Phase 0 — Baseline Freeze

- [ ] 現行ファイル一覧を保存
- [ ] 現行core/schema/skillのhashを保存
- [ ] 現行test suiteを実行し結果保存
- [ ] 現行examplesをschemaと照合
- [ ] Role Firewall regression test一覧を特定
- [ ] CAS / atomic write / evidence integrity test一覧を特定
- [ ] baseline差分をGitまたはsnapshotで固定

**Checkpoint:** 新機能実装前の状態を再現できる。

---

# Phase 1 — Contract Repair [P0]

## Schema/model

- [ ] `purpose-risk` をreview schemaへ追加
- [ ] Python classification setとschema enumを完全同期
- [ ] enum drift test追加
- [ ] finding status/result enumも同期test対象にする

## cycle_limit

- [ ] create-caseがpayload `cycle_limit` を保存
- [ ] omitted default=3
- [ ] invalid value reject test

## CLI / docs

- [ ] `--input` / stdin policyを正式決定
- [ ] `resume.md` の `--input-file` 等の不一致を修正
- [ ] README_USAGEのinline JSON例を修正
- [ ] generated CLI command execution test追加

## handoff

- [ ] `case_id` をhandoff必須化
- [ ] terminal handoffにもcase_id
- [ ] handoff schema/test追加または強化

## examples

- [ ] example生成script追加
- [ ] 全exampleをengine/CLIから再生成
- [ ] case schema validation
- [ ] event revision monotonicity check
- [ ] cycle_count consistency check

## atomic test

- [ ] permission依存failure injectionを廃止
- [ ] mock/fault injectionへ変更
- [ ] root/normal user差が出ないことを確認

**Checkpoint:** 現行機能だけで全test green。Schema/CLI/exampleの既知drift 0。

---

# Phase 2 — Quality Intent [P0]

- [ ] case schema versioning方針決定
- [ ] `intended_use` 追加
- [ ] `risk_context` 追加
- [ ] `constraints` optional追加
- [ ] `applicable_obligations` optional追加
- [ ] `unacceptable_failures` optional追加
- [ ] create-case validation追加
- [ ] baseline update/adjudicateとの整合確認
- [ ] Reviewer SkillにQuality Intent優先原則追加
- [ ] Reviewer proportionality gate追加
- [ ] Implementer Skillに「品質基準を勝手に下げない」維持
- [ ] 家庭内IoT低risk eval追加
- [ ] high/regulated risk eval追加

**Checkpoint:** QAの厳格さをIntended Use/Risk Contextへ追跡できる。

---

# Phase 3 — Plan Before Fix [P0]

## State/operation

- [ ] `implementer-plan` state追加
- [ ] `reviewer-plan-review` state追加
- [ ] `submit-plan` operation追加（または同等の明確なsemantic seam）
- [ ] `review-plan` operation追加（または同等）
- [ ] transitions.py更新
- [ ] role/allowed fields更新
- [ ] schemas追加
- [ ] CLI subcommand追加

## Finding policy

- [ ] `plan_required` field追加
- [ ] critical/high/medium default true
- [ ] low default false
- [ ] improvement-proposal false
- [ ] Owner override policyを明示

## Plan payload

- [ ] `understanding`
- [ ] `disposition_intent`
- [ ] `proposed_actions`
- [ ] `not_planned`
- [ ] `questions`
- [ ] `evidence_refs`
- [ ] `implementation_status=not-started`

## Guard

- [ ] plan accepted前のMedium+ target変更を拒否
- [ ] plan operationでchanged targetを観測した場合の挙動test
- [ ] plan acceptedでもOwner authorization範囲を超えられない

**Checkpoint:** Medium Findingを誤解したAI-1が即修正できない。

---

# Phase 4 — QA Self-Correction [P0]

- [ ] Reviewer Plan Outcomeに `finding-withdrawn`
- [ ] `converted-to-suggestion`
- [ ] `not-applicable`
- [ ] verification outcomeに `remediated`
- [ ] `partially-remediated`
- [ ] `not-remediated`
- [ ] `unverified`
- [ ] Finding lifecycle statusとverification resultを必要なら分離
- [ ] withdrawalにEvidence refs必須
- [ ] withdrawal rationale必須
- [ ] original Findingを削除しない
- [ ] withdrawn Findingの再発行ルール追加
- [ ] disagreed-with-evidence → withdrawn E2E追加

**Checkpoint:** 「QAが間違っていた」を正規Outcomeとして監査可能に記録できる。

---

# Phase 5 — Final Risk Assessment [P0]

- [ ] `reviewer-final-assessment` state追加
- [ ] `assess-risk` operation追加または同等seam
- [ ] cycle cap後に直接Ownerへ行かない
- [ ] all-remediated時の簡易final assessment定義
- [ ] residual risk schema追加
- [ ] implemented controls
- [ ] assumptions supporting acceptance
- [ ] likelihood / impact
- [ ] alternatives
- [ ] proportionality assessment
- [ ] QA recommendation
- [ ] confidence
- [ ] reassessment triggers
- [ ] reviewer accepted/rejected確定語を禁止
- [ ] structured recordをcase.jsonへ保存
- [ ] `final-risk-assessment.md` 派生生成
- [ ] Human decision options表示

**Checkpoint:** Humanは全Cycleログを読まずに最終Riskを判断できる。

---

# Phase 6 — Short UX [P1]

## quality-review

- [ ] case discovery
- [ ] target plan/specからintake source探索
- [ ] bootstrap design A/BをADRで決定
- [ ] missing Quality Intentを検出
- [ ] 1 caseなら自動選択
- [ ] 複数caseなら選択だけHumanへ依頼
- [ ] `review-plan` / `verify` / `assess-risk` をhandoffから自動route

## quality-response

- [ ] `submit-plan` / `submit-response` をhandoffから自動route
- [ ] HumanにFinding ID列挙を要求しない
- [ ] Humanにcycle/revision入力を要求しない

## human output

- [ ] 各operation後に「次の一言」を表示
- [ ] 内部CLI詳細はdeveloper/debugへ下げる

**Checkpoint:** 以下だけで通常E2Eが回る。

```text
quality-review でXX計画書の実装をQAレビューして
quality-response でhandoffを確認して対応して
quality-review で再点検して
```

---

# Phase 7 — Docs / Evals / Examples [P1]

- [ ] READMEをHuman UX中心へ再編
- [ ] developer CLI reference分離
- [ ] qms-foundationsへQuality Ownership原則追記
- [ ] Plan-before-Fix philosophy追記
- [ ] QA can be wrong原則追記
- [ ] Final Risk template追記
- [ ] quality-review evals拡充
- [ ] quality-response evals拡充
- [ ] final-risk example追加
- [ ] examples自動生成をrelease stepへ追加

**Checkpoint:** 文書と実装に不一致がない。

---

# Phase 8 — Release QA

## Automated

- [ ] Python compile
- [ ] full unittest
- [ ] schema tests
- [ ] CLI contract tests
- [ ] example regeneration + validation
- [ ] Role Firewall regression
- [ ] CAS/stale handoff regression
- [ ] atomic write failure regression
- [ ] unauthorized/undeclared change regression
- [ ] plan gate E2E
- [ ] finding withdrawal E2E
- [ ] final risk E2E
- [ ] short natural-language routing eval

## Dogfood

- [ ] 低risk projectで1ケース
- [ ] 高risk/complex projectで1ケース
- [ ] AI-1/AI-2を別agent/toolで実施
- [ ] Humanが最終summaryだけで判断できるか評価
- [ ] QA過剰指摘が減ったか評価
- [ ] 誤修正サイクルが減ったか評価

## Packaging

- [ ] `__pycache__` 0
- [ ] `.pytest_cache` 0
- [ ] `*.pyc` 0
- [ ] stale generated files 0
- [ ] version/changelog更新
- [ ] ZIP integrity test
- [ ] SHA-256生成

**FINAL CHECKPOINT:** 「完全だから」ではなく、定義したIntended Useと受入基準に対して完成版Quality Loopとして合理的に十分である。

---

# 実装ログ

## Phase 0

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 1

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 2

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 3

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 4

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 5

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 6

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 7

- date:
- actor:
- revision:
- tests:
- notes:

## Phase 8

- date:
- actor:
- revision:
- tests:
- notes:
