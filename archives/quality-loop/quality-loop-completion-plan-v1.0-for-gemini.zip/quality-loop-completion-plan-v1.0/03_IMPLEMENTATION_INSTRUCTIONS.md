# 実装担当AI向け完成指示書

この文書は作業命令として使用する。説明資料ではない。

---

## 0. 作業開始前の必須事項

### 0.1 Baseline freeze

改修前に以下を記録する。

- 全ファイル一覧
- Git revision（存在する場合）
- SHA-256（主要core / schemas / skills）
- 現行test結果
- 現行example validation結果

現在の参照環境では `unittest discover` は72件実行され、71 passed / 1 failedだった。failureはpermissionベースのatomic write failure injection testである。

この結果をそのまま再現する必要はないが、改修前baselineとして記録する。

### 0.2 禁止事項

- 旧 `spec-driven-qa-*` をcoreへ戻さない
- OpenSpec依存を追加しない
- `case.json` 以外の第二正本を作らない
- Role FirewallをSkill文章だけへ後退させない
- testを削ってPASSにしない
- exampleを手編集で辻褄合わせしない
- unresolved requirementを勝手に実装者判断で緩和しない

---

# Phase 1 — 現行契約バグを先にゼロにする

新QMS機能を足す前に、現行設計の内部不整合を解消する。

## 1.1 Schema/model enum同期

対象:

- `quality_loop/model.py`
- `schemas/review.schema.json`
- 必要ならschema validation utility/test

実施:

1. Finding classificationを1箇所のcanonical constantから生成/検証できる形に寄せる。
2. `purpose-risk` を含む全classificationをSchemaと一致させる。
3. Python側・Schema側のenum drift testを追加する。

受入:

- enum差異でtest fail
- review payloadに `purpose-risk` が通る

## 1.2 `cycle_limit` 尊重

対象:

- `quality_loop/engine.py:create_case`
- intake schema
- tests

実施:

```python
cycle_limit = payload.get("cycle_limit", 3)
```

をvalidateして保存する。

受入:

- omitted -> 3
- specified 1/2/5 -> 保存値一致
- invalid 0/negative -> reject

## 1.3 CLI/document contract修復

対象:

- `quality_loop/cli.py`
- `quality_loop/markdown_report.py`
- `README.md`
- `README_USAGE.md`
- Skill内CLI例
- tests

方針:

CLIをどうするかは1つに統一する。

推奨:

- 現在の `--input <file>` を正本とする
- stdin `--input -` は維持
- `resume.md` は必ず現在のCLIで実行可能なコマンドだけを出す

必要なら利便性のためinline JSON optionを追加してもよいが、二系統を曖昧に混在させない。

受入:

- `resume.md` が生成する各commandをsubprocess contract testで実行できる
- README quickstartも同じtest fixtureから生成/検証する

## 1.4 handoff case_id必須化

対象:

- `quality_loop/handoff.py`
- engineの全 `issue_handoff` call
- terminal handoff
- case/handoff tests

受入:

- `case_id is None` のhandoffを生成できない
- status result / resume / eventsのcase_id一致

## 1.5 examplesの自動生成

対象:

- `examples/`
- test helper / scenario builder

実施:

examplesをpublic API/CLIから生成するscriptを追加する。

例:

```text
scripts/generate_examples.py
```

生成後に、

- case schema
- event revision monotonicity
- cycle count
- handoff consistency

をtestする。

## 1.6 atomic write failure testを決定論化

対象:

- `tests/test_safety.py`
- 必要に応じて`CaseStore`のwriter seam

permission変更ではなくmock/fault injectionを使用する。

受入:

- root/CI/macOSでも同じ結果
- write failure時 canonical revision不変
- success扱いしない

---

# Phase 2 — Quality Intentをbaselineへ追加

## 2.1 Schema versioning

Quality Intent追加によりcase schemaを変更する場合、`schema_version` を上げる。

推奨:

```text
case schema 1.1
```

legacy 1.0を読む必要がある場合は、

- read compatibility
- migration command
- explicit warning

を設計する。

自動で過去履歴を書換えない。

## 2.2 必須Context

新規caseでは最低限:

- purpose
- intended_use
- risk_context
- requirements
- acceptance_criteria
- targets
- target_revision

を要求する。

`applicable_obligations` は空配列可だが、regulated/high risk profileでは空の意味を明示する。

## 2.3 Reviewer proportionality logic

`quality-review` Skill / referencesへ次を入れる。

ReviewerはFinding作成前に、

1. requirement/purpose/risk reference
2. actual operating context
3. impact
4. evidence strength
5. remediation burden vs expected risk reduction
6. suggestionで十分ではないか

を評価する。

この判断を全Findingで長文出力する必要はない。必要な項目をstructured fieldまたはrationaleへ短く残す。

---

# Phase 3 — Plan Before Fixを状態機械に導入

## 3.1 新operationを明示的に追加することを推奨

推奨公開operation:

- `submit-plan` — Implementer
- `review-plan` — Reviewer
- 既存 `submit-response` — implementation submission
- 既存 `verify` — implementation verification

公開operation数増加より、semantic ambiguityを避けることを優先する。

別設計を選ぶ場合も、PlanとImplementationが同じrecord/statusに混ざらないこと。

## 3.2 `plan_required`

Finding作成時に決定する。

Default:

```text
critical/high/medium -> true
low -> false
improvement-proposal -> false
```

Owner policy override可。

## 3.3 Implementer plan

`submit-plan` は変更を伴ってはならない。

payload例:

```json
{
  "plans": [
    {
      "finding_id": "F-001",
      "understanding": "...",
      "disposition_intent": "fix",
      "proposed_actions": ["..."],
      "not_planned": ["..."],
      "questions": [],
      "evidence_refs": [],
      "implementation_status": "not-started"
    }
  ]
}
```

もし `submit-plan` と同じoperationでtarget fileが変化していれば拒否またはOwner escalationとする。

## 3.4 Reviewer plan review

`review-plan` は、

- plan-accepted
- plan-accepted-with-comments
- plan-revision-required
- finding-withdrawn
- converted-to-suggestion
- not-applicable
- owner-decision-required

を扱う。

### 特にテストするケース

Implementerの `disagree-with-evidence` によりReviewer前提が崩れた場合:

```text
finding-withdrawn
```

となり、不要なfixへ進まないこと。

## 3.5 Implementation authorization

Plan acceptedはOwnerのimplementation authorizationを拡張しない。

Ownerが許可していないtargetは、plan acceptedでも変更不可。

---

# Phase 4 — Finding lifecycleとQA自己訂正を完成

## 4.1 status/resultを意味別に分離

現状の `verified` を万能語にしない。

最低限、最終Outcomeを以下へ分ける。

- remediated
- partially-remediated
- not-remediated
- unverified
- finding-withdrawn
- converted-to-suggestion
- not-applicable

必要なら、

- lifecycle `status`
- reviewer `verification_result`

を別fieldにする。

## 4.2 Withdraw audit trail

Finding撤回時も元Findingを削除しない。

記録:

- original finding
- reviewer reassessment rationale
- evidence refs
- withdrawal revision
- previous/next state

をappend-only履歴に残す。

---

# Phase 5 — Final Risk Assessmentを追加

## 5.1 Reviewer-only operation

推奨operation:

```text
assess-risk
```

Role:

```text
reviewer
```

次:

```text
owner / adjudicate
```

## 5.2 発火条件

- cycle_count >= cycle_limit
- unresolved residual riskがある
- verified/remediated後にOwner final acceptanceへ進む
- Owner risk decisionを要する

## 5.3 Final risk fields

各残余Findingについて:

- status
- implemented_controls
- residual_risk_description
- assumptions_supporting_acceptance
- likelihood
- impact
- alternatives
- proportionality_assessment
- qa_recommendation
- confidence
- reassessment_triggers

## 5.4 Human-facing markdown

通常の `resume.md` は簡潔なまま維持する。

Final Risk phaseだけ、例えば:

```text
final-risk-assessment.md
```

を派生生成する。

これは正本ではない。正本はcase.json内structured assessment。

人間に最初に見せる内容:

1. resolved count
2. residual count
3. Critical/High残数
4. QA recommendation
5. Owner decision options
6. 残余Findingごとの短いRisk Acceptance Basis

---

# Phase 6 — Natural-language Skill UXを完成

## 6.1 `quality-review` の入口

現在の「既存caseをstatus確認」だけではなく、明示された計画書/仕様/対象実装からCaseを探索・bootstrapできるfrontendを追加する。

### 重要

ReviewerがQuality Intentを創作してはいけない。

Case bootstrap時は、

- explicit plan/spec内のPurpose/Requirements/Acceptance Criteriaをsource付きで抽出
- Intended Use/Risk Contextが明示されていれば抽出
- 足りない場合、既存Project Quality Intent artifactを探す
- それでも不足し、Finding severity/proportionalityに重大影響がある場合だけHumanへ不足点を聞く

を行う。

### Role Firewallとの整合

Case creationをOwner判断と混同しないため、次のどちらかを採用する。

**推奨A:** `bootstrap-case` を「明示Artifactの機械的intake」と定義し、Owner adjudicationとは別のadministrative operationにする。Quality Intentの創作・変更権限は持たせない。

**代替B:** 事前に `qa-intake.json` / `quality-intent.json` を開発工程で生成し、Reviewerはそれを使う。

A/Bどちらを選んだかADRへ残す。

## 6.2 `quality-response`

Human input:

```text
quality-response で handoffを確認して対応して
```

Skillは次actionを見て、

- `submit-plan`
- `submit-response`

を自動選択する。

## 6.3 `quality-review` 再点検

Human input:

```text
quality-review で再点検して
```

Skillは、

- `review-plan`
- `verify`
- `assess-risk`

をhandoffから選ぶ。

Humanに内部operation名を要求しない。

---

# Phase 7 — ドキュメント・Evals・Examples同期

## 7.1 Skill evals追加

最低限:

- Medium Findingを即修正しない
- Response Planを先に出す
- QA Finding反証でwithdrawできる
- Reviewerが改善提案をblockingにしない
- cycle limitで自動acceptせずfinal riskへ進む
- Reviewer recommendationとOwner acceptanceを分離する
- short natural-language promptから正しいphaseを選べる

## 7.2 README

READMEは「内部CLIを人に覚えさせる」文書ではなく、

- 3つの自然言語操作
- `resume.md`
- final risk human decision

を中心にする。

CLI詳細はdeveloper referenceへ下げる。

---

# Phase 8 — Release Gate

以下がすべて満たされるまでFIXしない。

- all tests green in normal user + CI-like environment
- schemas/model synchronized
- examples generated, not hand-drifted
- all generated CLI examples executable
- Plan-before-Fix E2E passes
- Finding withdrawal E2E passes
- Final Risk Assessment E2E passes
- Quality Intent proportionality scenario passes
- short UX scenario passes
- Role Firewall/CAS/atomic persistence regression tests pass
- no cache/artifact contamination in release ZIP
