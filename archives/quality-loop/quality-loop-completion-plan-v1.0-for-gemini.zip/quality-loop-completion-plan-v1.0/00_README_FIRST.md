# Quality Loop Completion Plan v1.0 — START HERE

created: 2026-08-30 (JST)  
status: Implementation instruction package  
source package evaluated: `newskill.zip` / `quality-loop`

---

## 1. この文書群の目的

このパッケージは、現行 `quality-loop` を捨てて旧 `spec-driven-qa-*` へ戻すためのものではない。

現行設計の強みである以下を**正本として維持したまま**、実運用で不足しているQMS契約を完成させるための実装指示書である。

- `case.json` を単一正本とする状態管理
- Role Firewall（Owner / Reviewer / Implementer）
- revision / handoff / operation_id によるCAS・二重更新防止
- Evidence integrity と変更範囲照合
- 原子的書込みと正本保護
- `resume.md` を派生ビューとする人間向け圧縮
- ReviewerとImplementerのSkill分離

完成版の目標は、**長いQMS文章をAIへ覚えさせることではなく、小さなSkill + executable contract + 明確なHuman Quality Intent により、安全に短い自然言語でQAループを回せること**である。

---

## 2. 最上位の品質哲学

### 2.1 Quality Ownership

> **品質はAI-1（Implementer）が決めない。AI-2（Reviewer）も完全性を押しつけて決めない。**  
> **品質要求の源泉は、人間Ownerが定めた Purpose / Intended Use / Applicable Obligations / Risk Context である。**

AI-1は、要求を満たすための合理的な実装案を作る。  
AI-2は、要求とEvidenceに照らして独立評価する。  
Human Ownerは、品質要求と残余リスク受容の最終所有者である。

### 2.2 Quality is not Perfection

品質の目的は「最大限の技術的完全性」ではない。

- 技術的に改善可能であること
- 今回のIntended Useに対して是正が必要であること

を区別する。

QAはFinding件数、Severity、Control数を最大化してはならない。合理的な解決を優先する。

### 2.3 Plan Before Fix

特にMedium以上のFindingでは、Implementerが指摘を見た直後に修正へ走らない。

> **Understand → Propose → Reviewer confirms → Implement → Verify**

とする。

### 2.4 QA can be wrong

Reviewer Findingは絶対ではない。

ImplementerがEvidenceで反証した場合、Reviewerは自分のFindingを再評価し、必要なら正式に撤回・改善提案化・非該当化する。

**Finding withdrawalはQAの失敗ではなく、健全なQA Outcomeである。**

### 2.5 Human sees compressed risk, not the whole debate

Human Ownerは原則として全Cycleログを精読しなくてもよい。

最終段階でReviewerが、残余リスク・成立仮定・Control・代替案・比例性・再評価条件を圧縮し、Ownerへ裁定材料として渡す。

---

## 3. このパッケージの読み順

1. `01_CURRENT_BASELINE_FINDINGS.md`  
   現行実装で確認された具体的な欠落・不整合。
2. `02_TARGET_DESIGN_CONTRACT.md`  
   完成版で守る状態機械・Role・データ契約。
3. `03_IMPLEMENTATION_INSTRUCTIONS.md`  
   実装担当AIへの具体的な改修指示。
4. `04_IMPROVEMENT_PLAN.md`  
   Phase・優先順位・依存関係・Definition of Done。
5. `05_TODO.md`  
   実装中にチェックを付ける進捗管理用。
6. `06_ACCEPTANCE_TEST_PLAN.md`  
   完成判定に使うE2E・negative・regression試験。

---

## 4. 実装担当AIへ渡す推奨指示

次のように、このZIPと現行 `newskill.zip` を同時に渡す。

```text
現行 quality-loop を基盤として改修してください。
旧 spec-driven-qa-* へ戻さず、Role Firewall / CAS / Evidence integrity / atomic write は弱めないでください。

最初に quality-loop-completion-plan-v1.0/00_README_FIRST.md を読み、
次に 01 → 06 の順で実装してください。

実装中は 05_TODO.md を更新し、各Phase完了時にテスト結果と変更理由を記録してください。

仕様間で矛盾を見つけた場合、勝手に契約を変更せず、02_TARGET_DESIGN_CONTRACT.md の最上位原則を優先し、未解決事項として報告してください。
```

---

## 5. 完成版のHuman UX

人間が覚える操作は原則として以下でよい。

```text
#1 quality-review で XX計画書の実装をQAレビューして
#2 quality-response で handoffを確認して対応して
#3 quality-review で再点検して
```

内部では状態に応じて、

- 初回Review
- Response Plan
- Plan Review
- Implementation Response
- Verification
- Final Risk Assessment
- Owner Adjudication

を自動判別する。

複数候補Caseが存在する、Quality Intentが復元不能、重大なOwner判断が必要、破壊的操作が必要、などの例外時だけHumanへ明示的に問い返す。

---

## 6. Non-goals

今回の完成版で以下は行わない。

- 包括的な企業QMSを構築する
- CAPA、教育管理、供給者管理、監査スケジュール管理を追加する
- ISO/GxP準拠を自動認証する
- Reviewerを「常に正しい主体」とする
- AI同士の長文議論を成果物にする
- 技術的完全性をQuality Requirementより上位に置く
- CI/CDやGitHub連携を完成条件に含める

まずローカル `quality-loop` の状態機械と2 Skillを完成させる。
