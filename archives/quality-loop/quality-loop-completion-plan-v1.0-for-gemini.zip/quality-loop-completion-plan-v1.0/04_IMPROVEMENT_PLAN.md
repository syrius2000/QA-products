# Quality Loop 改善計画書

version: 1.0  
priority model: P0 = completion blocker / P1 = UX blocker / P2 = future

---

## 1. 改善方針

今回の改修は「機能を増やすこと」が目的ではない。

現行の強いcoreを維持し、以下の4つの不足を最小追加で埋める。

1. **Plan Before Fix** — 誤解したまま修正しない
2. **Reviewer Self-Correction** — QA自身もFindingを撤回できる
3. **Final Risk Assessment** — Humanへ残余リスクを圧縮する
4. **Quality Intent Context** — QAの過剰品質を抑え、合理的品質判断を支える

同時に、現行Schema/CLI/example/testの契約不整合をゼロにする。

---

# 2. Phase別計画

## Phase 0 — Baseline / Regression Fence

### 目的

改修によって既存のRole Firewall、CAS、Evidence integrity、atomicityが壊れないようにする。

### 成果物

- baseline test report
- core file hashes
- existing state machine snapshot
- regression invariant list

### 完了条件

- 現行test結果を記録
- known failureを分類
- 変更禁止invariantをtest名へ対応付け

---

## Phase 1 — Contract Repair

### Scope

- enum/schema drift
- cycle_limit
- CLI docs
- handoff case_id
- example drift
- atomic test determinism

### 優先度

**P0**

### 理由

新機能の前に契約不整合を残すと、新Schema/state machineのQAが信用できない。

### 完了条件

- schema/model sync test
- CLI example execution test
- generated examples validation
- 72/72相当以上の既存testが環境非依存でPASS

---

## Phase 2 — Quality Intent v1.1

### Scope

baselineへ `intended_use` / `risk_context` を導入。

### 優先度

**P0**

### 理由

QAが「完全性」ではなくIntended Useに対する合理性を評価するための基準が必要。

### Design decision

- Human OwnerがQuality Intent owner
- Reviewer/Implementerは変更不可
- applicable obligationsが存在する場合、比例性を理由に無視不可

### 完了条件

家庭内IoTとregulated/high-risk exampleで同一Finding候補のSeverity/DispositionがContextにより合理的に異なることをevalで確認。

---

## Phase 3 — Response Plan Gate

### Scope

- submit-plan
- review-plan
- plan-required policy
- handoff/state追加

### 優先度

**P0**

### 理由

最も重要な実運用課題。「指摘を見たら即修正」を止める。

### 完了条件

Medium FindingでImplementerがtarget変更しようとした場合、plan accepted前は拒否される。

---

## Phase 4 — Reviewer Self-Correction / Finding Lifecycle

### Scope

- finding-withdrawn
- converted-to-suggestion
- not-applicable
- remediated / partially-remediated

### 優先度

**P0**

### 理由

QAを権威化しない。EvidenceによってReviewer自身が誤りを訂正できるQMSにする。

### 完了条件

`disagreed-with-evidence` scenarioで、Findingを修正せずwithdrawしてCycleを前進できる。

---

## Phase 5 — Final Risk Assessment

### Scope

- reviewer final assessment state/operation
- structured risk record
- human markdown summary

### 優先度

**P0**

### 理由

Human介在最小化の中核。3Cycle全文ではなく最終Risk reasoningを人へ渡す。

### 完了条件

cycle limit到達時、直接Owner adjudicationへ行かずReviewer final assessmentを必ず通る。

---

## Phase 6 — Short Natural-language UX

### Scope

- case discovery/bootstrap
- handoff-based phase auto-routing
- multiple-case ambiguity handling

### 優先度

**P1**

### 期待UX

```text
quality-review で XX計画書の実装をQAレビューして
quality-response で handoffを確認して対応して
quality-review で再点検して
```

### 完了条件

上記3種類の自然言語だけでE2Eが進む。内部operation名をHumanへ要求しない。

---

## Phase 7 — Docs / Examples / Eval Consolidation

### Scope

- README再構成
- examples自動生成
- skill evals
- final risk example

### 優先度

**P1**

### 完了条件

- docsとCLIの差異0
- examplesとschemaの差異0
- skill trigger/phase selection eval PASS

---

## Phase 8 — Release Candidate / Dogfood

### Scope

実案件2種類以上で試す。

推奨:

1. 低リスク: 家庭内IoT / utility
2. 高め: データ処理・統計・規制影響を想定したproject

### 観察項目

- QAがしゃっちょこばらないか
- ImplementerがPlan前に直さないか
- Finding withdrawalが自然に使われるか
- Human final summaryが10–30秒で判断可能か
- handoffだけでAIを切替えられるか
- 文書量が再肥大化していないか

### 完了条件

Ownerが「全QAログを読まずに流れを把握できる」と評価できる。

---

# 3. 推奨リリース単位

## v1.1-alpha

- Phase 1
- Phase 2

## v1.1-beta

- Phase 3
- Phase 4

## v1.1-rc1

- Phase 5
- Phase 6

## v1.1 FIX

- Phase 7
- Phase 8
- dogfood feedback反映

Version名は任意だが、段階検証を推奨する。

---

# 4. リスク

## Risk A: 状態機械が再び肥大化

### 対策

- case.json single source of truth
- Skillは短いfrontend
- phase-specific payload
- 長文policyをcoreへ埋め込まない

## Risk B: Plan gateで処理が重くなる

### 対策

- Lowはdirect response
- improvement-proposalは強制対応なし
- Plan本文は短いstructured form

## Risk C: Reviewer withdrawalが甘いQAにつながる

### 対策

- withdrawalにはEvidence refs必須
- applicable obligation / critical safetyを比例性だけで落とさない
- withdrawal rationale append-only

## Risk D: Quality IntentをAIが勝手に作る

### 対策

- source artifact references
- missing critical contextはHuman escalation
- baseline変更はOwnerのみ

## Risk E: Final Risk SummaryがRisk acceptance誘導になる

### 対策

- QA recommendationとOwner decisionを別field
- assumptions/confidence/alternatives/reassessment triggers必須
- accepted語はReviewer final decisionに使わない

---

# 5. Definition of Done

完成とは、単にtestsがgreenであることではない。

以下の全てを満たすこと。

### Functional

- Short UXでE2Eが流れる
- Medium以上はPlan-before-Fix
- QA自身がFinding撤回可能
- final risk assessment後にOwner adjudication

### Safety

- Role Firewall維持
- CAS維持
- stale handoff拒否
- self-close不可能
- unauthorized change拒否
- atomic write failure safe

### Quality philosophy

- AI-1が品質基準を下げない
- AI-2が品質基準を勝手に上げない
- Owner Quality Intentが最上位
- improvement proposalはblockingにしない
- risk-based proportionalityが働く

### Human usability

- 通常は全ログを読まなくてもよい
- `resume.md` は短い
- final risk summaryは意思決定に必要十分
- Humanが内部CLI/state名を覚える必要がない
