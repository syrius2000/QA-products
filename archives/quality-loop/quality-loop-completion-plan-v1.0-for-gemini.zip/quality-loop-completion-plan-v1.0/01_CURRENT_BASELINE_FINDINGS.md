# 現行 `quality-loop` の確認済み課題

created: 2026-08-30 (JST)

本書は `newskill.zip` の現行コード・Schema・Skill・example・testを確認した結果に基づく改修起点である。

---

## 1. 評価結論

現行設計は旧Skillより進歩している。

特に次は維持すべき強みである。

- `case.json` single source of truth
- Role Firewall
- revision / previous_handoff_id / operation_id による整合制御
- Evidence SHA-256 / changed target observation
- atomic persistence
- derived `resume.md`
- 小さな `quality-review` / `quality-response` Skill

一方、完成版としては以下が不足している。

---

## 2. P0: QMSワークフロー上の欠落

### QL-P0-01: Plan Before Fix が状態機械に存在しない

現状は、

```text
review → submit-response → verify
```

であり、Findingを受けたImplementerは、許可されていればその場で `fix-submitted` へ進める。

これでは、

> 「QA指摘の意味を誤解したまま修正 → QA再指摘 → 再修正」

を防げない。

**必要な改善:** Medium / High / Criticalは原則としてResponse Plan gateを通す。

---

### QL-P0-02: QAが自分のFindingを撤回する正式Outcomeがない

現行Reviewer verification結果は概ね、

- `verified`
- `not-verified`
- `unverified`

に限定される。

しかし `disagreed-with-evidence` によりImplementerの反証が正しかった場合、

- `finding-withdrawn`
- `converted-to-suggestion`
- `not-applicable`

のようなReviewer自身の再評価Outcomeが必要である。

`verified` だけでは「修正が有効だった」のか「QA指摘が誤っていた」のか区別できない。

---

### QL-P0-03: Final Risk Assessment がOwner裁定前に存在しない

現状はcycle limit到達または全verifiedで、Reviewer verificationから直接Owner adjudicationへ進む。

完成版ではOwnerへ渡す前に、Reviewerが最終的に以下を圧縮する必要がある。

- resolved findings
- unresolved/residual findings
- implemented controls
- residual risk
- assumptions supporting acceptance
- alternatives
- proportionality / remediation burden
- QA recommendation
- reassessment triggers

Humanは全Cycleログではなく、この最終圧縮を主に読む。

---

### QL-P0-04: Quality IntentがPurpose + Requirementsに寄りすぎている

現行baselineの中心は、

- `purpose`
- `requirements`
- `acceptance_criteria`
- `targets`
- `target_revision`

である。

これではReviewerが「どの程度の厳格さが妥当か」を判断するContextが不足する。

最低限、

- `intended_use`
- `risk_context`

を追加し、必要に応じて、

- `applicable_obligations`
- `constraints`
- `unacceptable_failures`

を持てるようにする。

---

## 3. P0: 実装・Schema契約の不整合

### QL-P0-05: Finding classificationのSchema drift

`quality_loop/model.py` では `purpose-risk` が有効だが、`schemas/review.schema.json` には含まれていない。

さらにmodel側には `regression`, `unverified-claim` 等があり、Schemaとの完全同期を自動テストで保証すべきである。

**受入条件:** Python enum相当とJSON Schema enumが1件でも異なればtest fail。

---

### QL-P0-06: `cycle_limit` がintake入力から反映されない

`schemas/intake.schema.json` は `cycle_limit` を受け付けるが、`create_case()` は `cycle_limit: 3` 固定で保存する。

**受入条件:** payload値を保存し、省略時のみdefault=3。

---

### QL-P0-07: `resume.md` のCLI例と実CLIが一致しない

現行CLIは更新操作に `--input <JSON file>` を要求する。

一方 `resume.md` / README_USAGE には、

- `--input-file`
- `--decision`
- `--rationale`
- inline JSONを `--input` へ直接渡す例

など、現CLIでそのまま動かない例が存在する。

**受入条件:** ドキュメントに生成される全CLI例を実際にsubprocessで実行するdoc/CLI contract testを追加する。

---

### QL-P0-08: handoffの `case_id` が発行時に欠落し得る

handoffはAI間バトンなので、`case_id` は必須でなければならない。

**受入条件:** non-terminal / terminal handoffの双方でcase_id必須。Schema/testで保証。

---

### QL-P0-09: exampleがcanonical schema / event revisionとdriftする

exampleを手書きすると、case schemaのrequired field、cycle count、events revision等とずれる。

**改善:** examplesをengineのpublic seamから生成するfixture builder / scenario runnerで再生成する。

---

### QL-P0-10: atomic write failure testが権限環境に依存

現環境で72 testを実行したところ、71 passed / 1 failed。

失敗:

```text
test_case_write_failure_keeps_previous_canonical_revision
```

テストはdirectory permission変更でwrite failureを起こそうとしており、root等では失敗注入にならない。

**改善:** `os.replace` / atomic writerをmockまたはdependency injectionして確実にfailure injectionする。

これはengine自体の欠陥と断定するものではなく、**テストの環境依存性**を除去する項目である。

---

## 4. P1: Human UX上の不足

### QL-P1-01: 「XX計画書をQAして」からの初回Case bootstrapが弱い

現Skillは既存Quality Loop caseを前提に `status` から始まる。

期待UXは、

```text
quality-review で XX計画書の実装をQAレビューして
```

だけでも、明示された計画・仕様を基にCaseを用意し初回QAへ進めること。

ただしOwner Quality IntentをReviewerが勝手に創作してはならないため、bootstrapは後述の制約付きで実装する。

---

### QL-P1-02: `resume.md` が「状態表示」中心で、最終Risk reasoningが不足

信号機表示は有用だが、Owner裁定時はRisk Acceptance Basisをより重視する。

通常状態のresumeを重くせず、**Final Risk Assessment時だけ詳細リスク要約を生成**する。

---

## 5. P2: 将来拡張（今回の完成条件ではない）

- GitHub PR / Issue adapter
- CI/CD integration
- static analysis / benchmark evidence plugin
- Web dashboard
- full QMS / CAPA management

これらはCore completion後に検討する。
