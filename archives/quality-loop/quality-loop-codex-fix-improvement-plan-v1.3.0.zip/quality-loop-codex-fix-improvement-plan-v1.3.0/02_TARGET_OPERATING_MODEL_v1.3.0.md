# Target Operating Model v1.3.0

## 1. Architectureは変えない

```text
Human Owner
    │
    ├─ Quality Intent
    └─ Final Risk Decision

AI-2 Reviewer
    │
    ├─ Review
    ├─ Plan Review when required
    ├─ Verification
    ├─ Finding Self-Correction
    └─ Final Risk Assessment

AI-1 Implementer
    │
    ├─ Response Plan when required
    ├─ Authorized Fix
    └─ Evidence Submission

Quality Loop Core
    │
    ├─ case.json canonical
    ├─ Role Firewall
    ├─ CAS / handoff / revision
    ├─ Change Observation
    ├─ Evidence integrity
    └─ Workflow contract enforcement
```

---

## 2. Plan Gateの完成形

### Critical / High

```text
Finding
  ↓
submit-plan
  ↓
review-plan
  ↓
plan-approved
  ↓
submit-response / implementation
```

**Finding単位でPlan approvalを紐付ける。**

別FindingのPlan approvalを流用しない。

### Medium

Risk/contextでAdaptive。

### Low

原則direct response。

---

## 3. Partial Plan submission

大規模caseでは、
1回で全FindingのPlanを出す必要はない。

推奨:

```text
F1 required
F2 required
F3 required

submit-plan F1
review-plan F1 accepted

submit-plan F2/F3
review-plan F2/F3 accepted

all required findings plan-approved
→ submit-response phase
```

重要なのは:

> **全required FindingのPlan承認が揃うまでimplementation-bearing actionを許可しない**

こと。

HumanがFinding IDを手で管理する必要はない。
Core/handoffがnext required findingsを提示する。

---

## 4. Planは未来形

Planの意味:

```text
What I understand
What I intend to change
What I will not change
Why
Evidence I expect to produce
```

Plan時点で:

```text
implementation_status = not-started
```

である。

Implementation後の説明はAuthor Response / Evidenceで扱う。

---

## 5. Final Risk Assessmentの完成形

Final Risk Assessmentは
「Reviewerが選んだriskだけを書く」文書ではない。

Coreが:

```text
Which material unresolved findings must be covered?
```

を決定する。

Reviewerはその全件についてRisk reasoningを提出する。

```text
Canonical unresolved set
        ↓
Coverage requirement
        ↓
AI-2 risk assessment
        ↓
Human summary
```

これによりHuman Ownerは、
全履歴を読まずsummaryを信頼できる。

---

## 6. Human burden

今回の修正によりHuman操作を増やさない。

通常:

```text
quality-review でQAして
quality-response でhandoff対応して
quality-review で再点検して
```

でよい。

複数Plan-required Findingがあっても、
Humanが1件ずつ指示しない。

Core/Skillが:

```text
remaining_plan_required_findings
```

を解決する。

---

## 7. QAの自己訂正

維持する。

- finding-withdrawn
- converted-to-suggestion
- not-applicable

これらはFinal Risk expected setから除外可能。

QAが間違ったFindingを、
Human Risk Summaryへ残し続けない。

---

## 8. Final Risk materiality

Humanへ渡す対象は:

> material unresolved quality risk

である。

単なるsuggestionやimprovement proposalを
Human裁定必須riskへ昇格させない。

ただし:

- security
- data integrity
- applicable obligation
- unacceptable failure

に関係する未解決事項を安易に除外しない。

---

## 9. Context policy

今回の修正はCore/schema/test中心。

Skill本文を長くしない。

追加する説明が必要なら:

- FUNCTIONAL_SPEC
- tests
- concise reference

へ置き、
通常Runtime promptへは積まない。

---

## 10. FIX条件

このv1.3契約を満たしたら、
設計改善は停止する。

次の変更は実案件で再現する具体的摩擦のみを根拠とする。
