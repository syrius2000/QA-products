# Baseline & Critical Fixes v1.3.0

## 1. Baseline

対象: `Codex-fix.zip`

確認済み:

```text
98 tests passed
25 subtests passed
compileall success
AppleDouble 0
```

また以下は良好。

- Role Firewall
- CAS / stale revision / stale handoff
- atomic write
- Change Observation
- Adaptive Plan Gateの基本構造
- Finding withdrawal
- Early Final Risk Assessment
- JSON Schema
- Human-facing resume
- Runtime Context軽量性

---

# P0-1: Plan-required FindingのPlan Gate bypass

## 再現した問題

複数Findingがあるケース:

```text
F-HIGH   severity=High   plan_required=true
F-LOW    severity=Low    plan_required=false
```

初回review後:

```text
next_action = submit-plan
```

ここまでは正しい。

しかしImplementerが `F-LOW` のみをPlan提出し、
ReviewerがそのPlanをacceptすると、
Coreが `submit-response` へ進める。

その後、`F-HIGH` に対して
Plan承認なしで `fix-submitted` を提出できる。

## なぜ重大か

これはQMS哲学の中核:

```text
重要Finding
→ 理解
→ Response Plan
→ QA確認
→ 実装
```

をPromptではなくCoreが保証する、という設計に反する。

## 必須修正

### Rule A — submit-plan coverage

`next_action=submit-plan` の状態で、
未解決かつ `plan_required=true` のFindingを列挙する。

提出Planが必要Findingをcoverageしているか検査する。

#### 選択肢

A. 1回のsubmit-planで全required findingを必須にする  
B. 部分submit-planを許すが、全required findingがplan-approvedになるまで`submit-response`へ進ませない

**推奨はB。**

理由:
- 大きいcaseでも逐次Plan可能
- Human/AI payloadを巨大化しない
- Coreで未承認Findingを残せる

### Rule B — submit-response guard

`plan_required=true` Findingについて:

```text
fix-submitted
accepted
remediation action
```

等のimplementation-bearing dispositionを提出する場合、
そのFinding自身に `plan-approved` Evidence/stateが必要。

Plan未承認ならreject。

## Acceptance

- High FindingをPlanなしでfix-submittedできない
- 別FindingのPlan承認を流用できない
- Low Findingは従来通り直接Response可能
- partial Plan submissionは許容してもよい
- 全required Findingが承認されるまで実装phaseへ進まない

---

# P0-2: submit-planで`implementation_status=completed`を許している

## 再現

High Findingに対して:

```json
{
  "implementation_status": "completed"
}
```

でsubmit-planすると受理される。

## 問題

これは:

> 「もう実装した後ですが、これをPlanとして承認してください」

を許す。

Plan Before Fixの意味が失われる。

## 必須修正

### 推奨

submit-plan schemaを:

```text
implementation_status = "not-started"
```

固定にする。

もし既存互換のためenumを残すならCoreで:

```text
if action == submit-plan:
    implementation_status must equal not-started
```

を強制。

## Acceptance

- `not-started` → accept
- `in-progress` → reject
- `completed` → reject
- `fixed` 相当 → reject

### 追加原則

Plan fileはImplementation Reportではない。

---

# P0-3: Final Risk Assessmentのcoverage gap

## 再現

未解決Finding:

```text
F1
F2
```

の2件がある。

AI-2がFinal Risk Assessmentへ:

```json
{
  "residual_risks": [
    {"finding_id": "F1", ...}
  ]
}
```

だけ提出してもCoreが受理する。

Human-facing final risk summaryにはF2が出ない。

## なぜ重大か

Final Risk SummaryはHuman Ownerに渡す圧縮層。

ここから未解決Findingが欠落すると、

> Humanは「残った問題はF1だけ」

と誤認する可能性がある。

これはHuman介在最小化の前提を壊す。

## 必須修正

### Expected residual set

Final Risk Assessment時点でCoreが:

```text
material unresolved findings
```

を計算する。

最低限除外候補:

- remediated
- finding-withdrawn
- converted-to-suggestion
- not-applicable
- pure improvement-proposal

含める候補:

- partially-remediated
- not-remediated
- unverified
- disputed
- accepted residual risk candidate

### Coverage rule

```text
submitted residual_risk finding IDs
==
expected material unresolved finding IDs
```

を原則とする。

必要なら追加risk entryは許可してよいが、
expected findingの欠落は禁止。

### Status consistency

submitted:

```text
current_status
severity
```

を単なるAI自己申告にしない。

Core canonical Finding stateと一致確認する。

## Acceptance

- F1/F2のうちF2を落とすとreject
- withdrawn findingをrisk summaryへ強制しない
- suggestionをmaterial residualとして強制しない
- current_status mismatch reject
- severity mismatch rejectまたはcanonical値でoverride

---

# P1-1: Broken QMS reference

`qms-foundations.md` から参照される:

```text
docs/Artifacts/qms_quality_reference_001_0827.md
```

がbundleに存在しない場合、
削除を推奨。

理由:
- Runtime Contextを増やさない
- AIが不存在file探索をしない

同梱追加より削除を優先。

---

# P1-2: FUNCTIONAL_SPECのPlan Gate表現

古い/曖昧な:

```text
Medium以上はPlan
```

に見える表現があれば更新。

現行契約:

```text
Critical / High
→ Plan原則必須

Medium
→ risk/context adaptive

Low
→ direct response原則
```

へ統一。

---

# P0 Checkpoint

- [ ] Plan bypass不可能
- [ ] completed-plan不可能
- [ ] Final Risk omission不可能
- [ ] Human操作増加なし
- [ ] Runtime Context増加なし
