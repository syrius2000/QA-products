# Acceptance Test Plan v1.3.0

## A. Plan Gate

### A-01 High + Low bypass

Given:
- F-HIGH plan_required=true
- F-LOW plan_required=false

Submit/approve plan only for F-LOW.

Attempt fix-submitted for F-HIGH.

Expect:
- reject
- error code equivalent to `plan-approval-required`

---

### A-02 Partial High Plan

Given:
- F1 High
- F2 High

Approve F1 only.

Expect:
- F1 implementation may proceed only if workflow supports per-finding response
- F2 cannot implementation-submit
- case must still expose F2 as plan-required pending

If implementation phase is global rather than per-finding:
- do not enter global submit-response until both approved

Choose one model and test consistently.

---

### A-03 Low unaffected

Low finding direct response remains allowed.

---

## B. Plan Status

### B-01

`implementation_status=not-started` → PASS

### B-02

`implementation_status=in-progress` → reject

### B-03

`implementation_status=completed` → reject

---

## C. Final Risk Coverage

### C-01 Missing residual

Canonical unresolved:
- F1
- F2

Submitted:
- F1 only

Expect reject.

---

### C-02 Complete residual

Submitted F1 + F2.

Expect pass.

---

### C-03 Withdrawn excluded

F1 = finding-withdrawn
F2 = unresolved

Expect F2 only required.

---

### C-04 Suggestion excluded

Finding converted-to-suggestion.

Expect not mandatory for material residual risk unless project policy explicitly marks material.

---

### C-05 Status mismatch

Canonical F1=partially-remediated.
Submitted current_status=remediated.

Expect reject or canonical overwrite with explicit warning.

Prefer reject for deterministic contract.

---

### C-06 Severity mismatch

Canonical High.
Submitted Medium.

Expect reject or canonical overwrite.

Prefer reject.

---

## D. Regression

Must pass:

- Role Firewall
- CAS
- stale revision
- stale handoff
- duplicate op
- atomic write
- Change Observation
- manifest boundary
- unauthorized change
- undeclared change
- Adaptive Medium Plan Gate
- finding withdrawal
- Early Final Risk
- Human owner adjudication
- active case resolution
- JSON Schema
- compileall
- packaging hygiene

---

## E. Efficiency

No additional Human action required for:
- enumerating required plan Finding IDs
- checking which residual Finding is missing
- maintaining cycle/revision manually

Core/Skill provides these.

Acceptance failure if:
- Human must reconcile plan coverage manually
- Human must audit final risk coverage manually
