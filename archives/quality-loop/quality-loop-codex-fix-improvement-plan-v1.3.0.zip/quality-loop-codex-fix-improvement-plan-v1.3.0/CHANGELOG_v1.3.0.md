# Completion Plan Changelog v1.3.0

## Source

Target branch: `Codex-fix.zip`

## Why v1.3.0

Codex-fix improved:

- Packaging
- compileall
- test coverage
- concurrency locking
- Git/change observation
- resume visibility
- schema validation

Independent review found three remaining Core contract gaps:

1. Plan-required Finding can bypass Plan approval via another Finding's Plan
2. submit-plan accepts implementation_status=completed/in-progress
3. Final Risk Assessment can omit unresolved Finding

v1.3.0 addresses only these contract gaps plus small stale-doc cleanup.

## Stop Rule

After these gates pass:
- FIX architecture
- move to real-operation feedback
- do not add speculative QMS features
