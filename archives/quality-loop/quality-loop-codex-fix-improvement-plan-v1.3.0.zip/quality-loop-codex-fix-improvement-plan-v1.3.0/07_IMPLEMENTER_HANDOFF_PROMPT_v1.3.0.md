# Implementer Handoff Prompt v1.3.0

```text
Codex-fix.zip を基盤として、Improvement Plan v1.3.0 に従い、
正式FIX候補へ仕上げてください。

今回の作業はarchitecture追加ではなくCore contract hardeningです。

最優先3項目:
1. plan_required FindingをFinding単位でPlan approvalなしに修正提出できないようにする
2. submit-planではimplementation_status=not-startedを強制する
3. Final Risk Assessmentで全material unresolved Findingのcoverageを強制する

維持するもの:
- Role Firewall
- CAS / stale revision / stale handoff
- atomic write
- Change Observation
- Evidence integrity
- Adaptive Medium Plan Gate
- QA self-correction
- Early Final Risk Assessment
- Owner-only final adjudication
- active case resolution
- compact Skill Context

追加しない:
- 第3 Skill
- 新Role
- 新Risk matrix
- Human approval point
- verbose QMS docs
- scoring system

特に重要:
- 別FindingのPlan approvalを流用させない
- Planは未来形であり、completed/in-progressを受けない
- Human Final Risk Summaryから未解決Findingが欠落しない
- withdrawn/suggestionまでHuman裁定対象へ過剰昇格しない

読む順序:
01_BASELINE_AND_CRITICAL_FIXES_v1.3.0.md
02_TARGET_OPERATING_MODEL_v1.3.0.md
03_IMPLEMENTATION_INSTRUCTIONS_v1.3.0.md
05_TODO_v1.3.0.md
06_ACCEPTANCE_TEST_PLAN_v1.3.0.md

05_TODOを進捗正本として更新してください。

各Phase後:
- changed files
- test results
- contract impact
- human burden impact
- runtime context impact
- remaining risks
を記録してください。

完了後はarchitecture polishingを停止し、
実案件dogfoodへ移行してください。
```
