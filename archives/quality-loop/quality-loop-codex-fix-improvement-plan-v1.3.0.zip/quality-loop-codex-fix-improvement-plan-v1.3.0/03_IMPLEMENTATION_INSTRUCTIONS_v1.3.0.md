# Implementation Instructions v1.3.0

## Phase 1 — Plan Gate per Finding

### 1. Data model

各Findingについて、
Plan approval状態をFinding IDへ紐付ける。

既存 `plans` / `plan_reviews` を活用し、
新しい大規模stateを作らない。

Helper例:

```python
def approved_plan_finding_ids(case) -> set[str]:
    ...
```

### 2. Required set

```python
required = {
    finding.id
    for finding in unresolved_findings
    if finding.plan_required
}
```

### 3. submit-plan

部分提出を許す場合:

- finding_id exists
- plan_required true or explicitly accepted plan case
- duplicate/mismatched plan guard
- `implementation_status == "not-started"`

### 4. review-plan

accepted/revision-required等の結果をFinding ID単位で記録。

### 5. next_action

未承認required planが残る:

```text
next_action = submit-plan / review-plan
```

全required planがapproved:

```text
next_action = submit-response
```

### 6. submit-response hard guard

Implementation-bearing dispositionの場合:

```python
if finding.plan_required and finding_id not in approved_plan_ids:
    reject("plan-approval-required")
```

このguardはnext_actionだけに依存しないこと。

---

## Phase 2 — Plan status lock

対象schema/model:

`submit-plan` inputの `implementation_status` を
`not-started` 固定。

可能ならSchema:

```json
{
  "const": "not-started"
}
```

を使う。

Runtimeでもdefense-in-depth validation可。

---

## Phase 3 — Final Risk Coverage

### 1. expected set helper

```python
def material_unresolved_finding_ids(case) -> set[str]:
    ...
```

除外status/classificationを明示。

### 2. assess-risk validation

```python
submitted_ids = {...}
expected_ids = material_unresolved_finding_ids(case)

missing = expected_ids - submitted_ids

if missing:
    reject("residual-risk-coverage-incomplete")
```

必要ならunexpected extra risk entryは別validation。

### 3. Canonical consistency

各risk item:

- finding_id
- current_status
- severity

をcanonical Findingと照合。

Human-facing labelはcanonical値を使う方が安全。

---

## Phase 4 — Small doc cleanup

### qms-foundations

broken reference削除。

### FUNCTIONAL_SPEC

Adaptive Plan Gate表現へ更新。

### README

必要な場合だけ修正。
新しい長文QMS説明を追加しない。

---

## Phase 5 — Tests

既存:

```text
98 tests
25 subtests
```

を維持。

新規contract tests:

1. High Plan bypass reject
2. Partial Plan until all approved
3. Low direct response remains allowed
4. submit-plan completed reject
5. submit-plan in-progress reject
6. final risk missing unresolved finding reject
7. withdrawn finding need not be included
8. suggestion need not be included
9. final risk status mismatch reject
10. final risk severity mismatch reject/normalize

---

## Phase 6 — E2E

### Case A

High + Low.

Expect:

```text
High requires approved plan
Low may direct response
```

Low Planを承認してもHigh bypass不可。

### Case B

2 High Findings.

Plan one first.
Still cannot implementation-submit second.

### Case C

Residual F1/F2.
assess-risk only F1 → reject.

### Case D

F1 withdrawn, F2 residual.
Risk summary requires only F2.

---

## Phase 7 — Release

- pytest
- compileall
- real jsonschema
- packaging hygiene
- archive integrity
- SHA-256

新architectureは追加しない。
