# Release Criteria v1.3.0

## Core Contract

- [ ] Plan-required FindingはFinding単位でPlan approval必須
- [ ] 別FindingのPlan approvalを流用不可
- [ ] partial Planは許可しても全required approvalまでimplementation不可
- [ ] submit-plan=`not-started`のみ
- [ ] Final Risk Assessmentは全material unresolved Findingをcoverage
- [ ] withdrawn/suggestionは適切に除外
- [ ] canonical status/severityとrisk itemが一致

## Regression

- [ ] Role Firewall
- [ ] CAS
- [ ] stale handoff
- [ ] stale revision
- [ ] atomic write
- [ ] Change Observation
- [ ] unauthorized change
- [ ] undeclared change
- [ ] Adaptive Medium Plan Gate
- [ ] QA withdrawal
- [ ] Early Final Risk
- [ ] Owner-only adjudication
- [ ] active case resolution

## Efficiency

- [ ] Low Findingのdirect responseを壊していない
- [ ] simple Mediumを重くしていない
- [ ] HumanがFinding IDを手動管理しない
- [ ] 第3Skillなし
- [ ] new Human gateなし
- [ ] Skill Context大幅増加なし

## Packaging

- [ ] AppleDouble 0
- [ ] compileall success
- [ ] cache/pyc 0
- [ ] archive integrity
- [ ] SHA-256

## FIX

全Release Gate通過後:
- architecture FIX
- dogfoodへ移行
- 実運用evidenceのない追加機能を停止
