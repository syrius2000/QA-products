# Quality Loop Codex-fix Improvement Plan v1.3.0 — START HERE

created: 2026-08-31 (JST)  
status: Final contract-hardening plan  
target: `Codex-fix.zip`

---

## 1. このv1.3.0の目的

`Codex-fix` は、現行のQuality Loop系ブランチの中で非常に完成度が高い。

確認済みの長所:

- AppleDouble `._*` = 0
- `compileall` 成功
- `98 tests passed`
- `25 subtests passed`
- Role Firewall維持
- CAS / revision / handoff維持
- Change Observation改善
- Git manifest / untracked / deleted path観測改善
- Human-facing resume改善
- Skill Contextは軽量のまま
- Draft 2020-12 JSON Schema検証も良好

したがって、この計画は新しいQMS機能を追加するためのものではない。

> **Codex-fixに残る3つのCore contract gapを閉じて、正式FIX候補にすること**

が目的である。

---

## 2. 今回のP0

1. Plan-required FindingのPlan Gate bypassを禁止
2. `submit-plan` 時点では implementation_status=`not-started` を強制
3. Final Risk Assessmentで全material unresolved Findingを必ずcoverage

これらはHuman操作を増やすための機能ではない。

> **既に設計したルールをCoreで本当に強制するための修正**

である。

---

## 3. 今回のP1

- broken QMS reference削除
- FUNCTIONAL_SPECのMedium Plan Gate表現をAdaptive実装へ合わせる
- 必要ならテスト名/例の表現を現行語彙へ整理

---

## 4. 今回は追加しない

- 第3 Skill
- 新Role
- Risk matrix
- scoring system
- Human approval point
- CAPA
- QMS文書大量追加
- Contextを増やす説明
- 新しいworkflow phase

---

## 5. 実装担当AIの読み順

1. `01_BASELINE_AND_CRITICAL_FIXES_v1.3.0.md`
2. `02_TARGET_OPERATING_MODEL_v1.3.0.md`
3. `03_IMPLEMENTATION_INSTRUCTIONS_v1.3.0.md`
4. `05_TODO_v1.3.0.md`
5. `06_ACCEPTANCE_TEST_PLAN_v1.3.0.md`

---

## 6. Doneの意味

以下を満たしたらFIX候補とする。

- High/Critical Plan GateをCoreで迂回できない
- Plan提出前に実装済み状態を偽装できない
- Final Risk Summaryから未解決Findingを落とせない
- Human操作数は増えていない
- Skill Contextは増えていない
- 既存98 tests + 25 subtestsが維持される
- 新しいcontract testsが成功
- Packaging clean / compileall成功

> **Fix the contract, not the architecture.**
