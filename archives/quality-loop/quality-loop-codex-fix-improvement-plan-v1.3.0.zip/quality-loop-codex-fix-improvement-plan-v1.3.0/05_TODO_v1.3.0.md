# TODO — Codex-fix Final Contract Hardening v1.3.0

> このTODOを実装進捗の正本として使用する。

---

# Phase 0 — Baseline

- [ ] Codex-fix SHA-256記録
- [ ] full file inventory
- [ ] 98 tests確認
- [ ] 25 subtests確認
- [ ] compileall確認
- [ ] AppleDouble 0確認
- [ ] Skill行数記録

### Log

```text
Date:
Agent:
Baseline:
Notes:
```

---

# Phase 1 — Plan Gate Coverage

- [ ] unresolved plan-required Finding helper
- [ ] approved plan Finding helper
- [ ] partial Plan submission仕様決定
- [ ] `submit-plan` finding existence check
- [ ] `review-plan` Finding単位approval
- [ ] all required approvedまでsubmit-response phaseへ進ませない
- [ ] submit-response hard guard追加
- [ ] 別Finding Plan流用reject

### Tests

- [ ] High+Low bypass reproductionがFAILする
- [ ] Low direct responseはPASS
- [ ] 2 Highの部分Planは適切に待機
- [ ] all High plans approved後のみimplementation可能

### Checkpoint

- [ ] Plan Before FixをCoreが本当に保証

---

# Phase 2 — Plan Status Lock

- [ ] schemaを`not-started`固定
- [ ] runtime validation
- [ ] `in-progress` reject
- [ ] `completed` reject
- [ ] error code/documentation

### Checkpoint

- [ ] “修正済みPlan”を提出できない

---

# Phase 3 — Final Risk Coverage

- [ ] material unresolved helper
- [ ] withdrawn除外
- [ ] converted-to-suggestion除外
- [ ] not-applicable除外
- [ ] improvement-proposal除外方針確認
- [ ] residual risk submitted IDs抽出
- [ ] missing coverage reject
- [ ] canonical status一致
- [ ] canonical severity一致
- [ ] human summaryがexpected set全件表示

### Tests

- [ ] F1/F2でF1のみ → reject
- [ ] withdrawn F1 + residual F2 → F2のみでPASS
- [ ] status mismatch → reject
- [ ] severity mismatch → reject/normalize

### Checkpoint

- [ ] Human Final Risk Summaryから未解決問題が消えない

---

# Phase 4 — Small Documentation Cleanup

- [ ] broken qms reference確認
- [ ] 存在しなければ削除
- [ ] FUNCTIONAL_SPECのMedium表現更新
- [ ] README必要最小限更新
- [ ] stale terminology 0
- [ ] Skill本文を長文化していない

---

# Phase 5 — Full Regression

- [ ] previous 98 tests green
- [ ] previous 25 subtests green
- [ ] new Plan coverage tests
- [ ] new status lock tests
- [ ] new risk coverage tests
- [ ] Role Firewall green
- [ ] CAS green
- [ ] Change Observation green
- [ ] schema tests green
- [ ] compileall green

---

# Phase 6 — E2E Dogfood

## Scenario A: High + Low

- [ ] Low Plan approvalでHigh bypass不可
- [ ] High approved後にfix可能
- [ ] Human追加操作なし

## Scenario B: Multiple High

- [ ] partial Plan possible
- [ ] all approvedまでimplementation block
- [ ] handoff/resumeが残件を提示

## Scenario C: Final Risk omission

- [ ] unresolved 2件
- [ ] 1件のみassessment → reject
- [ ] 2件coverage → pass

## Scenario D: QA withdrawal

- [ ] withdrawn Findingはfinal riskから除外
- [ ] historyは保持

---

# Phase 7 — Packaging

- [ ] `._*` 0
- [ ] `__pycache__` 0
- [ ] `.pytest_cache` 0
- [ ] `*.pyc` 0
- [ ] compileall success
- [ ] zip/tar integrity
- [ ] SHA-256

---

# FINAL CHECKPOINT

- [ ] Plan bypass = impossible
- [ ] completed-plan = impossible
- [ ] Final Risk omission = impossible
- [ ] Human burden増加なし
- [ ] Skill Context増加なし
- [ ] no third Skill
- [ ] no new QMS ceremony
- [ ] existing strengths preserved
- [ ] formal FIX candidate

> **After this, stop architecture polishing and learn from real operation.**
